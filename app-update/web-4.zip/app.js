'use strict';
/* ================= helpers ================= */
const $ = (s, r = document) => r.querySelector(s);
const uid = () => Math.random().toString(36).slice(2, 10);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayStr = () => iso(new Date());
const dayDiff = s => Math.round((new Date(s + 'T00:00') - new Date(todayStr() + 'T00:00')) / 864e5);
const dow = (d = new Date()) => (d.getDay() + 6) % 7;
const mins = t => +t.slice(0, 2) * 60 + +t.slice(3, 5);
const ls = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };

let state, rev = -1, dirty = false, saveTimer = null;
let edit = false, curTab = ls.get('dash-tab'), refocus = null;
const view = {};   // per-widget, per-device UI state (not synced)
const timers = {}; // focus timers
const wx = {};     // weather cache

/* language (tables live in i18n.js) */
const lang = () => state?.settings.lang === 'en' ? 'en' : 'nl';
const loc = () => lang() === 'nl' ? 'nl-NL' : 'en-GB';
const T = (s, ...a) => { let r = lang() === 'nl' ? NL[s] ?? s : s; a.forEach((v, i) => { r = r.replace(`{${i}}`, v); }); return r; };
const days = () => DAYNAMES[lang()];
const niceDay = s => { const n = dayDiff(s); return n === 0 ? T('Today') : n === 1 ? T('Tomorrow') : new Date(s + 'T00:00').toLocaleDateString(loc(), { weekday: 'long', day: 'numeric', month: 'short' }); };
const nDays = n => n === 1 ? T('1 day') : T('{0} days', n);

/* ================= phone app (Android): data goes through Firebase instead of the laptop server ================= */
// Firestore REST (no SDK). users/{uid}/dash/main = the whole dashboard (last write wins), users/{uid}/dash/ext = calendar
// events the laptop uploads for the phone (read-only here). Login: the native Google account picker (Capacitor plugin).
const APP = !!window.Capacitor?.isNativePlatform?.();
const cloud = { cfg: null, auth: null, tok: null, seen: 0, ready: false, fromDefault: false };
try { cloud.auth = JSON.parse(ls.get('dash-auth')); } catch {}
const devId = ls.get('dash-dev') || (() => { const d = 'phone-' + uid(); ls.set('dash-dev', d); return d; })();
async function cloudCfg() { return cloud.cfg ||= await (await fetch('firebase-config.json')).json(); }
async function cloudPost(url, body, form) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': form ? 'application/x-www-form-urlencoded' : 'application/json' }, body: form ? new URLSearchParams(body) : JSON.stringify(body) });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j?.error?.message || 'http'), { status: r.status }); return j;
}
async function cloudSignIn() {
  const c = await cloudCfg(), FA = window.Capacitor.Plugins.FirebaseAuthentication;
  const r = await FA.signInWithGoogle(), id = r?.credential?.idToken; if (!id) throw new Error('no token');
  const j = await cloudPost(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${c.apiKey}`, { postBody: `id_token=${id}&providerId=google.com`, requestUri: 'http://localhost', returnSecureToken: true });
  cloud.auth = { rt: j.refreshToken, uid: j.localId, email: j.email || '' }; ls.set('dash-auth', JSON.stringify(cloud.auth));
  cloud.tok = { t: j.idToken, exp: Date.now() + (+j.expiresIn || 3600) * 1000 };
}
function cloudSignOut() {
  cloud.auth = cloud.tok = null; cloud.seen = 0; cloud.ready = false; ls.set('dash-auth', ''); ls.set('dash-state', '');
  window.Capacitor?.Plugins.FirebaseAuthentication?.signOut().catch(() => {}); state = null; loginScreen();
}
async function cloudToken() {
  if (cloud.tok && cloud.tok.exp > Date.now() + 60e3) return cloud.tok.t;
  const c = await cloudCfg();
  try {
    const j = await cloudPost(`https://securetoken.googleapis.com/v1/token?key=${c.apiKey}`, { grant_type: 'refresh_token', refresh_token: cloud.auth.rt }, true);
    cloud.tok = { t: j.id_token, exp: Date.now() + (+j.expires_in || 3600) * 1000 }; return cloud.tok.t;
  } catch (e) { if (e.status === 400) cloudSignOut(); throw e; }
}
const docUrl = async n => `https://firestore.googleapis.com/v1/projects/${(await cloudCfg()).projectId}/databases/(default)/documents/users/${cloud.auth.uid}/dash/${n}`;
async function cloudGet(n) {
  const r = await fetch(await docUrl(n), { headers: { Authorization: 'Bearer ' + await cloudToken() }, cache: 'no-store' });
  if (r.status === 404) return null; const j = await r.json(); if (!r.ok) throw new Error(j?.error?.message || 'firestore');
  const f = j.fields || {}; return { data: f.data?.stringValue || '', updatedAt: +(f.updatedAt?.integerValue || 0) };
}
async function cloudSet(n, data, t) {
  const r = await fetch(await docUrl(n), { method: 'PATCH', headers: { Authorization: 'Bearer ' + await cloudToken(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields: { data: { stringValue: data }, updatedAt: { integerValue: String(t) }, device: { stringValue: devId } } }) });
  if (!r.ok) throw new Error('firestore ' + r.status);
}
function loginScreen() {
  $('#login')?.remove();
  const d = document.createElement('div'); d.id = 'login';
  d.innerHTML = `<div class="lcard"><img src="icon.svg" alt="" width="72" height="72"><h1>My Dashboard</h1>
    <p>${T('Sign in with the same Google account as on your laptop. Your to-dos, notes and timetable then stay in sync.')}</p>
    <button id="loginBtn">${T('Sign in with Google')}</button><div class="sub err" id="loginErr"></div></div>`;
  document.body.append(d);
  $('#loginBtn').onclick = async () => {
    $('#loginErr').textContent = ''; $('#loginBtn').disabled = true;
    try { await cloudSignIn(); d.remove(); state = null; await load(); }
    catch (e) { $('#loginErr').textContent = /cancel/i.test(e?.message || '') ? '' : T('Signing in did not work. Check your internet connection and try again.'); }
    finally { const b = $('#loginBtn'); if (b) b.disabled = false; }
  };
}
async function loadCloud() {
  if (!cloud.auth) { if (!$('#login')) loginScreen(); return; }
  if (!state) { try { state = JSON.parse(ls.get('dash-state')); } catch {} if (!state) { state = defaultState(); cloud.fromDefault = true; } normalize(state); render(); }
  try {
    const d = await cloudGet('main');
    if (!cloud.ready) { // first answer from the cloud: it wins over a fresh phone, our offline edits win over it
      cloud.ready = true;
      if (!d) { dirty = true; cloud.fromDefault = false; return flush(); }
      if (cloud.fromDefault || !dirty) { dirty = false; cloud.fromDefault = false; }
      else return flush();
    }
    setSync(dirty ? 'busy' : '', dirty ? 'Saving…' : 'Synced');
    if (!d || dirty || d.updatedAt === cloud.seen) return;
    const a = document.activeElement;
    if (pk || (a && /INPUT|TEXTAREA/.test(a.tagName) && a.value)) return;
    cloud.seen = d.updatedAt; state = JSON.parse(d.data); normalize(state);
    ls.set('dash-state', JSON.stringify(state)); if ($('#modal').classList.contains('hidden')) render(); loadExt();
  } catch { setSync('off', 'Offline'); }
}
async function flushCloud() {
  if (!cloud.ready) { setSync('busy', 'Saving…'); return; } // never upload before we have seen what is already in the cloud
  const t = Date.now();
  try { await cloudSet('main', JSON.stringify(state), t); cloud.seen = t; dirty = false; setSync('', 'Synced'); }
  catch { setSync('off', 'Offline'); saveTimer = setTimeout(flush, 8000); }
}
async function loadExtCloud() {
  if (!cloud.auth) return;
  try {
    const d = await cloudGet('ext'); if (!d) return;
    const x = JSON.parse(d.data), events = (x.events || []).map(e => ({ ...e, ext: true, rw: false }));
    const changed = JSON.stringify(events) !== JSON.stringify(ext.events);
    ext = { events, status: {}, g: null, t: x.t };
    if (changed && !typingNow() && $('#modal').classList.contains('hidden')) render();
  } catch {}
}

/* events: your own (editable) plus events from linked calendars (read-only, never saved in your data) */
let ext = { events: [], status: {}, g: null }, extSeq = 0;
const allEvents = () => [...state.events, ...ext.events];
const CAL_COLORS = ['#ef4444', '#f59e0b', '#22c55e', '#06b6d4', '#a855f7', '#ec4899'];
const typingNow = () => { if (pk) return true; const a = document.activeElement; return a && /INPUT|TEXTAREA/.test(a.tagName) && a.value; };
const TZ = Intl.DateTimeFormat().resolvedOptions().timeZone;
// Reads both kinds of linked calendars: .ics links (read-only) and the Google connection (two-way).
async function loadExt(force) {
  if (APP) return loadExtCloud();
  const cals = state?.settings.calendars || [], seq = ++extSeq;
  const [ics, goo] = await Promise.all([
    cals.length ? fetch('/api/calendars' + (force ? '?refresh=1' : ''), { cache: 'no-store' }).then(r => r.json()).catch(() => null) : { calendars: [] },
    fetch('/api/google/events?tz=' + encodeURIComponent(TZ) + (force ? '&refresh=1' : ''), { cache: 'no-store' }).then(r => r.json()).catch(() => null),
  ]);
  if (seq !== extSeq || (!ics && !goo)) return; // a newer request is in flight, or we are offline: keep what we have
  const events = [], status = {};
  if (ics) for (const r of ics.calendars) {
    const c = cals.find(x => x.id === r.id); if (!c) continue;
    status[r.id] = { ok: r.ok, error: r.error, t: r.t, n: r.events.length };
    r.events.forEach(e => events.push({ ...e, ext: true, color: c.color, calName: c.name }));
  } else { ext.events.filter(e => !e.g).forEach(e => events.push(e)); Object.assign(status, ext.status); }
  const g = goo ? { connected: !!goo.connected, needsLogin: !!goo.needsLogin, error: goo.error || '', primary: goo.primary || '' } : ext.g;
  if (goo?.connected) goo.events.forEach(e => events.push({ ...e, ext: true })); else if (!goo) ext.events.filter(e => e.g).forEach(e => events.push(e));
  const changed = JSON.stringify([events, status, g]) !== JSON.stringify([ext.events, ext.status, ext.g]);
  ext = { events, status, g };
  const el = $('#calList'); if (el) el.innerHTML = calListHtml();
  if (changed && !typingNow() && $('#modal').classList.contains('hidden')) render();
}

const ACCENTS = ['#6366f1', '#8b5cf6', '#ec4899', '#ea580c', '#16a34a', '#0d9488', '#2563eb'];
const WALLS = [['aurora', 'Aurora'], ['sunset', 'Sunset'], ['ocean', 'Ocean'], ['forest', 'Forest'], ['plain', 'Plain']];
const EMOJI = ['🏠', '📅', '🎯', '📝', '📚', '💼', '🎓', '💡', '🧠', '💪', '🎨', '🎮', '🎵', '💰', '🛒', '✈️', '❤️', '⭐', '🔬', '💻'];

/* ================= widgets ================= */
const allTodos = () => Object.values(state.widgets).filter(w => w.type === 'todo').flatMap(w => w.data.items);
const dueTag = due => {
  if (!due) return '';
  const d = dayDiff(due);
  return `<span class="tag ${d < 0 ? 'late' : d <= 1 ? 'soon' : ''}">${d < 0 ? T('{0}d late', -d) : d === 0 ? T('today') : d === 1 ? T('tomorrow') : due.slice(8) + '/' + due.slice(5, 7)}</span>`;
};
// Your own events and writable Google events can be edited/deleted; .ics-link events are read-only.
const evRow = e => {
  const att = e.g ? `data-gcal="${esc(e.gcal)}" data-gid="${esc(e.id)}"` : `data-id="${e.id}"`, canEdit = !e.ext || (e.g && e.rw);
  const del = e.g ? (e.rw ? `<button class="x" data-act="gev.del" ${att}>×</button>` : '') : e.ext ? '' : `<button class="x" data-act="ev.del" ${att}>×</button>`;
  return `<div class="ev"${e.color ? ` style="border-left-color:${esc(e.color)}" title="${esc(e.calName || '')}"` : ''}><span class="tm">${e.time ? e.time + (e.end ? '–' + e.end : '') : T('all day')}</span><span class="t${canEdit ? ' clk' : ''}"${canEdit ? ` data-act="ev.edit" ${att}` : ''}>${esc(e.title || T('(no title)'))}${e.loc ? ` <span class="sub">· ${esc(e.loc)}</span>` : ''}</span>${del}</div>`;
};
const dlRow = d => `<div class="ev dl"><span class="tm">⏰</span><span class="t">${esc(d.title)}</span></div>`;
const color = s => `hsl(${[...s].reduce((a, c) => a + c.charCodeAt(0) * 7, 0) % 360} 65% 52%)`;
const chips = (act, cur, opts) => opts.map(([k, l]) => `<button class="${cur === k ? 'on' : ''}" data-act="${act}" data-v="${k}">${T(l)}</button>`).join('');
const calChips = w => `<div class="chips">${chips('cal.mode', w.data.mode || 'month', [['month', 'Month'], ['list', 'Upcoming']])}</div>`;

function upcomingList() {
  const t0 = todayStr(), g = {};
  allEvents().filter(e => e.date >= t0).sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || ''))).forEach(e => (g[e.date] ||= []).push(e));
  const keys = Object.keys(g).slice(0, 7); if (!g[t0]) keys.unshift(t0);
  return `<form class="row" data-form="ev.add"><input name="title" placeholder="${T('Event, class, meeting…')}" required autocomplete="off">
    ${dateIn('date', t0, { req: true })}${timeIn('time', '', { ph: 'Time' })}<button>+</button></form>
    ${keys.map(d => `<div class="day ${d === t0 ? 'today' : ''}"><h3>${niceDay(d)}</h3>${(g[d] || []).map(evRow).join('') || `<div class="empty">${T('Nothing planned')}</div>`}</div>`).join('')}`;
}

/* notes: a list of separate notes; the open note (per device) is edited in place and saved while you type */
function notesOf(w) { // older dashboards had one big text: that becomes the first note
  if (!Array.isArray(w.data.notes)) { w.data.notes = w.data.text?.trim() ? [{ id: uid(), text: w.data.text, t: Date.now() }] : []; delete w.data.text; }
  return w.data.notes;
}
const ago = t => {
  const m = Math.round((Date.now() - t) / 60e3);
  if (m < 1) return T('just now'); if (m < 60) return T('{0} min ago', m);
  const d = new Date(t); return dayDiff(iso(d)) === 0 ? d.toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString(loc(), { day: 'numeric', month: 'short' });
};
const noteTitle = n => n.text.trim().split('\n')[0].slice(0, 80) || T('New note');
function notesRender(w, id) {
  const v = view[id] ||= {}, list = notesOf(w), open = list.find(n => n.id === v.note);
  if (open) return `<div class="nbar"><button class="ghost small" data-act="note.back">← ${T('All notes')}</button><span class="sub">${T('Saved')} · ${ago(open.t)}</span>
      <button class="ghost small${open.pin ? ' on' : ''}" data-act="note.pin" title="${T('Pin to the top')}">📌</button><button class="ghost small" data-act="note.del" title="${T('Delete')}">🗑</button></div>
    <textarea class="ntext" data-inp="note" data-id="${open.id}" placeholder="${T('Start typing… The first line becomes the title.')}">${esc(open.text)}</textarea>`;
  const q = (v.q || '').toLowerCase(), shown = list.filter(n => !q || n.text.toLowerCase().includes(q)).sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || b.t - a.t);
  return `<div class="row" style="margin-bottom:10px"><button data-act="note.new">＋ ${T('New note')}</button>${list.length > 4 ? `<input data-inp="note.q" value="${esc(v.q || '')}" placeholder="🔎 ${T('Search notes')}" autocomplete="off">` : ''}</div>
    <div class="nlist">${shown.map(n => { const body = n.text.trim().split('\n').slice(1).join(' ').trim();
      return `<button class="nitem" data-act="note.open" data-id="${n.id}"><b>${n.pin ? '📌 ' : ''}${esc(noteTitle(n))}</b>${body ? `<span>${esc(body.slice(0, 140))}</span>` : ''}<small>${ago(n.t)}</small></button>`; }).join('')
      || `<div class="empty">${T(list.length ? 'No notes match your search.' : 'No notes yet. Press “New note” to write one.')}</div>`}</div>`;
}

const slotColor = s => s.color || color(s.title);
// Overlapping blocks get their own lane, so they sit side by side (each a bit narrower) instead of on top of each other.
function lanes(list) {
  const out = [...list].sort((a, b) => mins(a.start) - mins(b.start) || mins(b.end) - mins(a.end));
  let group = [], ends = [], gEnd = -1;
  const close = () => { group.forEach(x => { x.n = ends.length; }); group = []; ends = []; };
  for (const x of out) {
    const a = mins(x.start), b = Math.max(a + 15, mins(x.end));
    if (a >= gEnd) { close(); gEnd = -1; }
    let i = ends.findIndex(e => e <= a); if (i < 0) { i = ends.length; ends.push(b); } else ends[i] = b;
    x.lane = i; group.push(x); gEnd = Math.max(gEnd, b);
  }
  close(); return out;
}
function ttRender(w, id) {
  const v = view[id] ||= {}, mode = w.data.mode || 'week', today = dow(), D = days();
  const slots = w.data.slots.map(s => ({ ...s, end: s.end || pad(Math.min(23, +s.start.slice(0, 2) + 1)) + s.start.slice(2) }));
  let body;
  if (mode === 'day') {
    body = slots.filter(s => s.day === today).sort((a, b) => a.start.localeCompare(b.start)).map(s => `<div class="ev clk" data-act="tt.open" data-id="${s.id}" style="border-left-color:${esc(slotColor(s))}"><span class="tm">${s.start}–${s.end}</span><span class="t">${esc(s.title)}${s.room ? ` <span class="sub">· ${esc(s.room)}</span>` : ''}</span></div>`).join('') || `<div class="empty">${T('Nothing scheduled today.')}</div>`;
  } else {
    const cols = [0, 1, 2, 3, 4, 5, 6].filter(d => d < 5 || slots.some(s => s.day === d));
    const h0 = slots.length ? Math.floor(Math.min(...slots.map(s => mins(s.start))) / 60) : 8;
    const h1 = Math.max(h0 + 1, slots.length ? Math.ceil(Math.max(...slots.map(s => mins(s.end))) / 60) : 17);
    const PX = 46, H = (h1 - h0) * PX, y = t => (mins(t) - h0 * 60) / 60 * PX;
    let hrs = ''; for (let h = h0; h <= h1; h++) hrs += `<span style="top:${(h - h0) * PX}px">${pad(h)}:00</span>`;
    body = `<div class="ttw"><div class="tt" style="grid-template-columns:40px repeat(${cols.length},minmax(0,1fr))"><div></div>
      ${cols.map(d => `<div class="dh ${d === today ? 'today' : ''}">${D[d]}</div>`).join('')}<div class="tth" style="height:${H}px">${hrs}</div>
      ${cols.map(d => `<div class="ttc ${d === today ? 'today' : ''}" style="height:${H}px">${lanes(slots.filter(s => s.day === d)).map(s =>
        `<div class="ttb clk${s.n > 1 ? ' nar' : ''}" data-act="tt.open" data-id="${s.id}" style="top:${y(s.start)}px;height:${Math.max(20, y(s.end) - y(s.start) - 2)}px;left:calc(${s.lane * 100 / s.n}% + 2px);width:calc(${100 / s.n}% - 4px);background:${esc(slotColor(s))}" title="${esc(s.title)} ${s.start}–${s.end}${s.room ? ' · ' + esc(s.room) : ''}"><b>${esc(s.title)}</b><small>${s.start}–${s.end}${s.room ? ' · ' + esc(s.room) : ''}</small></div>`).join('')}</div>`).join('')}
      </div></div>${slots.length ? '' : `<div class="empty" style="margin-top:8px">${T('Press “+ Add” to add your classes or shifts.')}</div>`}`;
  }
  return `<div class="chips">${chips('tt.mode', mode, [['week', 'Week'], ['day', 'Today']])}
    <button data-act="tt.new" class="ttadd">${T('+ Add')}</button></div>${body}`;
}
// Add / edit a class or shift: several days at once, 5-minute times, and a colour from your palette.
function slotModal(wid, sid) {
  const w = state.widgets[wid], s = w.data.slots.find(x => x.id === sid), D = days();
  const titles = [...new Set(Object.values(state.widgets).filter(x => x.type === 'timetable').flatMap(x => x.data.slots.map(y => y.title)))];
  const used = w.data.slots.map(slotColor), pal = palette();
  const col = s ? slotColor(s) : pal.find(c => !used.includes(c)) || pal[w.data.slots.length % pal.length];
  const day0 = s ? s.day : (view[wid]?.day ?? Math.min(dow(), 4));
  openModal(`<h2>${T(s ? 'Edit class' : 'Add class')}</h2><form data-form="tt.save" data-wid="${wid}">
    <input type="hidden" name="sid" value="${s ? s.id : ''}">
    <h3>${T('Name')}</h3><input name="title" value="${esc(s?.title || '')}" placeholder="${T('Class / shift')}" required autocomplete="off" list="ttNames" data-inp="tt.title" style="width:100%">
    <datalist id="ttNames">${titles.map(t => `<option value="${esc(t)}">`).join('')}</datalist>
    <h3>${T(s ? 'Day' : 'Day(s)')}</h3><div class="daypick">${D.map((d, i) => `<label><input type="checkbox" name="day" value="${i}" ${i === day0 ? 'checked' : ''}><span>${d}</span></label>`).join('')}</div>
    <h3>${T('Time')}</h3><div class="row">${timeIn('start', s?.start || '', { req: true, ph: 'Start' })}<span class="sub" style="align-self:center">–</span>${timeIn('end', s?.end || '', { ph: 'End' })}</div>
    <h3>${T('Room')}</h3><input name="room" value="${esc(s?.room || '')}" placeholder="${T('Optional')}" autocomplete="off" style="width:100%">
    <h3>${T('Colour')}</h3><div class="cpal" id="cpal">${palHtml(col)}</div>
    <div class="hueRow"><input type="range" class="hue" min="0" max="359" value="200" data-inp="pal.hue" aria-label="${T('Your own colour')}"><i id="huePrev" style="background:${hsl2hex(200)}"></i><button type="button" class="soft" data-act="pal.add">${T('Add to palette')}</button></div>
    <label class="fl" style="margin-top:12px;white-space:normal"><input type="checkbox" name="same" checked> ${T('Use this colour for everything with the same name')}</label>
    <div class="mfoot">${s ? `<button type="button" class="danger" data-act="tt.rm" data-id="${s.id}">${T('Delete')}</button>` : '<span></span>'}<span style="display:flex;gap:8px"><button type="button" class="ghost" data-act="modal.close">${T('Cancel')}</button><button>${T('Save')}</button></span></div></form>`);
}
const PALETTE = ['#ef4444', '#f97316', '#f59e0b', '#84cc16', '#22c55e', '#14b8a6', '#06b6d4', '#3b82f6', '#6366f1', '#8b5cf6', '#d946ef', '#ec4899', '#64748b'];
const palette = () => [...PALETTE, ...(state.settings.palette || [])];
const palHtml = sel => palette().map(c => `<label class="${PALETTE.includes(c) ? '' : 'cus'}" title="${c}"><input type="radio" name="color" value="${c}" ${c === sel ? 'checked' : ''}><span style="background:${c}"></span>${PALETTE.includes(c) ? '' : `<b data-act="pal.del" data-c="${c}" title="${T('Remove from palette')}">×</b>`}</label>`).join('')
  + (palette().includes(sel) ? '' : `<label title="${esc(sel)}"><input type="radio" name="color" value="${esc(sel)}" checked><span style="background:${esc(sel)}"></span></label>`);
function hsl2hex(h, s = 70, l = 52) {
  s /= 100; l /= 100; const a = s * Math.min(l, 1 - l);
  const f = n => { const k = (n + h / 30) % 12; return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)))).toString(16).padStart(2, '0'); };
  return '#' + f(0) + f(8) + f(4);
}

/* ================= pickers: date and time (5-minute steps) ================= */
let pk = null; // the open picker: { wrap, input, kind, ym, h }
const shortDate = s => {
  const n = dayDiff(s); if (n === 0) return T('Today'); if (n === 1) return T('Tomorrow'); if (n === -1) return T('Yesterday');
  return new Date(s + 'T00:00').toLocaleDateString(loc(), { weekday: 'short', day: 'numeric', month: 'short', ...(s.slice(0, 4) !== todayStr().slice(0, 4) ? { year: 'numeric' } : {}) });
};
const pickLabel = (kind, v, ph) => v ? esc(kind === 'date' ? shortDate(v) : v) : `<span class="ph">${T(ph || (kind === 'date' ? 'Pick a date' : 'Time'))}</span>`;
function pickIn(kind, name, value = '', { req = false, ph = '' } = {}) {
  return `<span class="pk ${kind}"${req ? ' data-req' : ''} data-ph="${esc(ph)}"><input type="hidden" name="${name}" value="${esc(value)}" data-def="${esc(value)}"><button type="button" class="pkb" data-pick>${kind === 'date' ? '📅' : '🕑'} <span>${pickLabel(kind, value, ph)}</span></button></span>`;
}
const timeIn = (n, v, o) => pickIn('time', n, v, o), dateIn = (n, v, o) => pickIn('date', n, v, o);
const popEl = () => $('#pop') || document.body.appendChild(Object.assign(document.createElement('div'), { id: 'pop', className: 'pop' }));
function pickOpen(wrap) {
  const input = wrap.querySelector('input'), kind = wrap.classList.contains('date') ? 'date' : 'time', v = input.value;
  pk = { wrap, input, kind, ym: (v || todayStr()).slice(0, 7), h: v ? v.slice(0, 2) : '' };
  document.querySelectorAll('.pk.open').forEach(x => x.classList.remove('open')); wrap.classList.add('open');
  pickDraw();
}
function pickClose() { pk?.wrap.classList.remove('open'); pk = null; $('#pop')?.remove(); }
function pickDraw() {
  const p = popEl(), v = pk.input.value, opt = !pk.wrap.hasAttribute('data-req');
  const foot = extra => `<div class="pfoot">${extra}${opt && v ? `<button type="button" data-pk="clear">${T('Clear field')}</button>` : ''}<button type="button" class="ghost" data-pk="close">${T('Done')}</button></div>`;
  if (pk.kind === 'time') {
    const m = v ? v.slice(3, 5) : '', hrs = Array.from({ length: 24 }, (_, i) => pad(i)), mns = Array.from({ length: 12 }, (_, i) => pad(i * 5));
    p.innerHTML = `<h4>${T('Hour')}</h4><div class="pg" style="grid-template-columns:repeat(6,1fr)">${hrs.map(h => `<button type="button" class="${h === pk.h ? 'on' : ''}${+h < 7 || +h > 22 ? ' out' : ''}" data-pk="h" data-v="${h}">${h}</button>`).join('')}</div>
      <h4>${T('Minutes')}</h4><div class="pg" style="grid-template-columns:repeat(6,1fr)">${mns.map(x => `<button type="button" class="${x === m ? 'on' : ''}" data-pk="m" data-v="${x}">:${x}</button>`).join('')}</div>${foot('')}`;
  } else {
    const [y, mo] = pk.ym.split('-').map(Number), first = new Date(y, mo - 1, 1), start = new Date(y, mo - 1, 1 - dow(first)), t0 = todayStr();
    let cells = ''; for (let i = 0; i < 42; i++) { const d = new Date(start); d.setDate(start.getDate() + i); const s = iso(d); cells += `<button type="button" class="${s === v ? 'on' : ''}${s === t0 ? ' today' : ''}${d.getMonth() !== mo - 1 ? ' out' : ''}" data-pk="d" data-v="${s}">${d.getDate()}</button>`; }
    const plus = n => { const d = new Date(); d.setDate(d.getDate() + n); return iso(d); };
    p.innerHTML = `<div class="pnav"><button type="button" data-pk="nav" data-v="-1">‹</button><b>${first.toLocaleDateString(loc(), { month: 'long', year: 'numeric' })}</b><button type="button" data-pk="nav" data-v="1">›</button></div>
      <div class="pg" style="grid-template-columns:repeat(7,1fr)">${days().map(d => `<span>${d}</span>`).join('')}${cells}</div>
      ${foot(`<button type="button" data-pk="d" data-v="${plus(0)}">${T('Today')}</button><button type="button" data-pk="d" data-v="${plus(1)}">${T('Tomorrow')}</button><button type="button" data-pk="d" data-v="${plus(7)}">${T('In a week')}</button>`)}`;
  }
  // place it under the field (or above it when there is no room), inside the window
  const r = pk.wrap.getBoundingClientRect(), pw = p.offsetWidth, ph = p.offsetHeight;
  const left = Math.max(8, Math.min(r.left, innerWidth - pw - 8)), top = r.bottom + 6 + ph > innerHeight && r.top - 6 - ph > 0 ? r.top - 6 - ph : Math.min(r.bottom + 6, innerHeight - ph - 8);
  p.style.left = left + 'px'; p.style.top = Math.max(8, top) + 'px';
}
function pickSet(v) {
  const { input, wrap, kind } = pk, old = input.value; input.value = v;
  wrap.querySelector('.pkb span').innerHTML = pickLabel(kind, v, wrap.dataset.ph);
  // moving the start time moves the end time along (same length; one hour when there was none yet)
  if (kind === 'time' && v && /^(start|time)$/.test(input.name)) {
    const endW = wrap.closest('form')?.querySelector('.pk input[name="end"]');
    if (endW) {
      const len = endW.value && old && endW.value > old ? mins(endW.value) - mins(old) : endW.value > v ? 0 : 60;
      if (len) { const m = Math.min(mins(v) + len, 23 * 60 + 55); endW.value = pad(Math.floor(m / 60)) + ':' + pad(m % 60); endW.closest('.pk').querySelector('.pkb span').innerHTML = pickLabel('time', endW.value); }
    }
  }
}
function pickAct(k, v) {
  if (!pk) return;
  if (k === 'close') return pickClose();
  if (k === 'clear') { pickSet(''); return pickClose(); }
  if (k === 'nav') { const [y, m] = pk.ym.split('-').map(Number); pk.ym = iso(new Date(y, m - 1 + +v, 1)).slice(0, 7); return pickDraw(); }
  if (k === 'd') { pickSet(v); return pickClose(); }
  if (k === 'h') { pk.h = v; pickSet(v + ':' + (pk.input.value.slice(3, 5) || '00')); return pickDraw(); }
  if (k === 'm') { pickSet((pk.h || '08') + ':' + v); return pickClose(); }
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-pick]');
  if (b) { const w = b.closest('.pk'); return pk?.wrap === w ? pickClose() : pickOpen(w); }
  const p = e.target.closest('[data-pk]'); if (p) return pickAct(p.dataset.pk, p.dataset.v);
  if (pk && !e.target.closest('#pop')) pickClose();
}, true);
document.addEventListener('reset', e => setTimeout(() => e.target.querySelectorAll?.('.pk').forEach(w => {
  const i = w.querySelector('input'); i.value = i.dataset.def; w.querySelector('.pkb span').innerHTML = pickLabel(w.classList.contains('date') ? 'date' : 'time', i.value, w.dataset.ph);
})));
addEventListener('resize', () => pk && pickClose());
addEventListener('scroll', e => { if (pk && !e.target.closest?.('#pop')) pickClose(); }, true); // don't leave it floating away from its field

const WIDGETS = {
  today: {
    name: 'Today', icon: '☀️', desc: 'Your day at a glance', w: 8,
    render() {
      const t = todayStr(), todos = allTodos().filter(x => !x.done);
      const due = todos.filter(x => x.due && x.due <= t);
      const evs = allEvents().filter(e => e.date === t).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
      const next = state.deadlines.filter(d => d.date >= t).sort((a, b) => a.date.localeCompare(b.date))[0];
      return `<div class="stats">
        <div class="stat"><b>${todos.length}</b><span>${T('open tasks')}</span></div>
        <div class="stat"><b>${due.length}</b><span>${T('due today')}</span></div>
        <div class="stat"><b>${evs.length}</b><span>${T('events today')}</span></div>
        <div class="stat"><b>${next ? dayDiff(next.date) + 'd' : '–'}</b><span>${next ? esc(next.title) : T('no deadlines')}</span></div></div>
        ${evs.map(evRow).join('')}
        ${due.map(x => `<div class="ev dl"><span class="tm">☑</span><span class="t">${esc(x.text)}</span>${dueTag(x.due)}</div>`).join('')}
        ${evs.length + due.length ? '' : `<div class="empty">${T('Nothing urgent today. Nice. 🌿')}</div>`}`;
    },
  },
  todo: {
    name: 'To-do', icon: '✅', desc: 'Tasks with priority and due dates', init: () => ({ items: [] }),
    render(w) {
      const it = w.data.items, done = it.filter(x => x.done).length;
      const sorted = [...it].sort((a, b) => (a.done - b.done) || (a.prio - b.prio) || ((a.due || '9') < (b.due || '9') ? -1 : 1));
      return `${it.length ? `<div class="bar"><i style="width:${done / it.length * 100}%"></i></div>` : ''}
      <form class="row" data-form="todo.add">
        <input name="text" placeholder="${T('Add a task…')}" required autocomplete="off">
        <select name="prio" title="${T('How important is it? High goes to the top of the list.')}"><option value="2">${T('Normal priority')}</option><option value="1">${T('High priority')}</option><option value="3">${T('Low priority')}</option></select>
        <label class="fl">${T('Due on')} ${dateIn('due', '', { ph: 'Optional' })}</label><button>+</button></form>
      <ul class="list">${sorted.map(x => `<li class="${x.done ? 'done' : ''}">
        <button class="chk p${x.prio} ${x.done ? 'on' : ''}" data-act="todo.toggle" data-id="${x.id}">✓</button>
        <span class="t">${esc(x.text)}</span>${x.done ? '' : (x.prio === 1 ? `<span class="tag hi">${T('High')}</span>` : x.prio === 3 ? `<span class="tag">${T('Low')}</span>` : '') + dueTag(x.due)}
        <button class="x" data-act="todo.del" data-id="${x.id}">×</button></li>`).join('') || `<li class="empty">${T('All clear. Add your first task above.')}</li>`}</ul>
      ${done ? `<button class="ghost small" data-act="todo.clear" style="margin-top:10px">${T('Clear {0} completed', done)}</button>` : ''}`;
    },
  },
  calendar: {
    name: 'Calendar', icon: '📆', desc: 'Your events as a month or an upcoming list', init: () => ({ mode: 'month' }),
    render(w, id) {
      if (w.data.mode === 'list') return calChips(w) + upcomingList();
      const v = view[id] ||= { ym: todayStr().slice(0, 7), sel: todayStr() };
      const [y, m] = v.ym.split('-').map(Number), off = dow(new Date(y, m - 1, 1)), n = new Date(y, m, 0).getDate(), t = todayStr();
      const ev = new Set(allEvents().map(e => e.date)), dl = new Set(state.deadlines.map(d => d.date));
      let cells = days().map(d => `<span>${d[0]}</span>`).join('') + '<i></i>'.repeat(off);
      for (let i = 1; i <= n; i++) {
        const k = `${v.ym}-${pad(i)}`;
        cells += `<button class="${k === t ? 'today' : ''} ${k === v.sel ? 'sel' : ''} ${dl.has(k) ? 'has hasdl' : ev.has(k) ? 'has' : ''}" data-act="cal.sel" data-day="${k}">${i}</button>`;
      }
      const items = allEvents().filter(e => e.date === v.sel).sort((a, b) => (a.time || '').localeCompare(b.time || '')).map(evRow).join('')
        + state.deadlines.filter(d => d.date === v.sel).map(dlRow).join('');
      return calChips(w) + `<div class="calh"><button class="ghost small" data-act="cal.nav" data-n="-1">‹</button>
        <span>${new Date(y, m - 1, 1).toLocaleDateString(loc(), { month: 'long', year: 'numeric' })}</span>
        <button class="ghost small" data-act="cal.nav" data-n="1">›</button></div>
        <div class="cal">${cells}</div>
        <div class="day"><h3>${niceDay(v.sel)}</h3>${items || `<div class="empty">${T('Nothing planned')}</div>`}</div>
        <form class="row" data-form="cal.add"><input name="title" placeholder="${T('Add event on this day…')}" required autocomplete="off">${timeIn('time', '', { ph: 'Time' })}<button>+</button></form>`;
    },
  },
  deadlines: {
    name: 'Deadlines', icon: '⏰', desc: 'Countdown to exams and assignments',
    render() {
      const list = [...state.deadlines].sort((a, b) => a.date.localeCompare(b.date));
      return `<form class="row" data-form="dl.add"><input name="title" placeholder="${T('Exam, assignment, project…')}" required autocomplete="off"><label class="fl">${T('Due on')} ${dateIn('date', '', { req: true })}</label><button>+</button></form>
      <ul class="list">${list.map(d => { const n = dayDiff(d.date); return `<li><span class="t">${esc(d.title)}<br><span class="sub">${niceDay(d.date)}</span></span>
        <span class="tag ${n < 0 ? 'late' : n <= 3 ? 'soon' : 'acc'}">${n < 0 ? T('{0}d overdue', -n) : n === 0 ? T('today!') : nDays(n)}</span>
        <button class="x" data-act="dl.del" data-id="${d.id}">×</button></li>`; }).join('') || `<li class="empty">${T('No deadlines yet.')}</li>`}</ul>`;
    },
  },
  timetable: { name: 'Timetable', icon: '🏫', desc: 'Weekly class or work schedule', w: 8, init: () => ({ slots: [] }), render: ttRender },
  links: {
    name: 'Quick links', icon: '🔗', desc: 'Tiles for your most used places',
    init: () => ({ links: [['Gmail', 'https://mail.google.com'], ['Calendar', 'https://calendar.google.com'], ['Drive', 'https://drive.google.com'], ['YouTube', 'https://www.youtube.com']].map(([name, url]) => ({ id: uid(), name, url })) }),
    render(w, id) {
      const ed = view[id]?.edit;
      return `<div class="links">${w.data.links.map(l => `<a href="${esc(l.url)}" target="_blank" rel="noopener">
        <span class="av" style="background:${color(l.name)}">${esc(l.name[0]?.toUpperCase() || '?')}</span>${esc(l.name)}
        ${ed ? `<button class="x" data-act="link.del" data-id="${l.id}">×</button>` : ''}</a>`).join('')}</div>
        ${ed ? `<form class="row" data-form="link.add"><input name="name" placeholder="${T('Name')}" required autocomplete="off"><input name="url" placeholder="website.nl" required autocomplete="off"><button>+</button></form>` : ''}
        <button class="ghost small" data-act="link.edit">${T(ed ? 'Done' : '+ Add / edit links')}</button>`;
    },
  },
  pomodoro: {
    name: 'Focus timer', icon: '🍅', desc: 'Pomodoro timer with breaks', init: () => ({ log: {} }),
    render(w, id) {
      const t = timer(id);
      return `<div class="pomo"><div class="ring"><svg width="170" height="170"><circle cx="85" cy="85" r="72"/><circle class="pr" cx="85" cy="85" r="72" stroke-dasharray="452.4"/></svg>
        <div><span class="pt"></span><span class="sub pm"></span></div></div>
        <div class="row center"><button data-act="pomo.go" class="pgo"></button><button class="ghost" data-act="pomo.reset">Reset</button></div>
        <div class="chips" style="justify-content:center">${[[25, 0, '25 min'], [50, 0, '50 min'], [5, 1, T('Break {0}', 5)], [15, 1, T('Break {0}', 15)]].map(([m, b, l]) =>
          `<button class="${t.mins === m && +t.brk === b ? 'on' : ''}" data-act="pomo.set" data-m="${m}" data-b="${b}">${l}</button>`).join('')}</div>
        <div class="sub">${T('Sessions today:')} <b>${w.data.log?.[todayStr()] || 0}</b> 🍅</div></div>`;
    },
  },
  habits: {
    name: 'Habits', icon: '🌱', desc: 'Tick off daily habits, build streaks', init: () => ({ habits: [] }),
    render(w) {
      const now = new Date(), t = todayStr(), D = days();
      const wk = D.map((_, i) => { const x = new Date(now); x.setDate(now.getDate() - dow(now) + i); return iso(x); });
      const streak = h => { let n = 0; const d = new Date(); if (!h.days[iso(d)]) d.setDate(d.getDate() - 1); while (h.days[iso(d)]) { n++; d.setDate(d.getDate() - 1); } return n; };
      return `<form class="row" data-form="habit.add"><input name="name" placeholder="${T('New habit (study, gym, read…)')}" required autocomplete="off"><button>+</button></form>
        ${w.data.habits.map(h => `<div class="habit"><span class="n">${esc(h.name)} ${streak(h) > 1 ? `<span class="tag acc">🔥 ${streak(h)}</span>` : ''}</span>
        ${wk.map((k, i) => `<button class="d ${h.days[k] ? 'on' : ''} ${k === t ? 'today' : ''}" data-act="habit.tick" data-id="${h.id}" data-day="${k}">${D[i][0]}</button>`).join('')}
        <button class="x" data-act="habit.del" data-id="${h.id}">×</button></div>`).join('') || `<div class="empty">${T('Track something you want to do every day.')}</div>`}`;
    },
  },
  notes: { name: 'Notes', icon: '📝', desc: 'Your notes: as many as you like, saved automatically', w: 8, init: () => ({ notes: [] }), render: notesRender },
  countdown: {
    name: 'Countdown', icon: '🎉', desc: 'Days until something you look forward to', init: () => ({ title: '', date: '' }),
    render(w, id) {
      const d = w.data;
      if (!d.date || view[id]?.edit) return `<form class="row" data-form="cd.set"><input name="title" placeholder="${T('Holiday, birthday, trip…')}" value="${esc(d.title)}" required autocomplete="off">${dateIn('date', d.date || '', { req: true })}<button>${T('Save')}</button></form>`;
      const n = dayDiff(d.date);
      return `<div class="ctr"><div class="huge">${Math.abs(n)}</div><div>${n === 0 ? `<b>${esc(d.title)}</b> ${T('is today! 🎉')}` : `${T(Math.abs(n) === 1 ? 'day' : 'days')} ${T(n > 0 ? 'until' : 'since')} <b>${esc(d.title)}</b>`}</div>
        <button class="ghost small" data-act="cd.edit" style="margin-top:12px">${T('Change')}</button></div>`;
    },
  },
  weather: {
    name: 'Weather', icon: '🌤️', desc: 'Current weather and 3-day forecast', init: () => ({}),
    render(w, id) {
      const d = w.data;
      if (!d.lat) return `<form class="row" data-form="wx.set"><input name="city" placeholder="${T('Your city')}" required autocomplete="off"><button>${T('Set')}</button></form><div class="empty">${esc(view[id]?.msg || T('Uses the free Open-Meteo service.'))}</div>`;
      const c = wx[id];
      if (!c || Date.now() - c.t > 18e5) { loadWx(id, d); if (!c) return `<div class="empty">${T('Loading weather…')}</div>`; }
      if (c.err) return `<div class="empty">${T("Couldn't load the weather.")}</div><button class="ghost small" data-act="wx.retry">${T('Try again')}</button>`;
      const [e, label] = wxCode(c.cur.weather_code), D = days();
      return `<div class="wx"><span class="e">${e}</span><div><div class="huge" style="font-size:2.4rem">${Math.round(c.cur.temperature_2m)}°</div><div class="sub">${T(label)} · ${esc(d.city)}</div></div></div>
        <div class="wxd">${c.daily.time.slice(1, 4).map((t, i) => `<div><b>${D[dow(new Date(t + 'T00:00'))]}</b><br>${wxCode(c.daily.weather_code[i + 1])[0]}<br>${Math.round(c.daily.temperature_2m_max[i + 1])}° / ${Math.round(c.daily.temperature_2m_min[i + 1])}°</div>`).join('')}</div>
        <button class="ghost small" data-act="wx.clear" style="margin-top:10px">${T('Change city')}</button>`;
    },
  },
  quote: {
    name: 'Motivation', icon: '💬', desc: 'A new quote every day', w: 12,
    render(w, id) {
      const i = (view[id]?.i ?? Math.floor(Date.now() / 864e5)) % QUOTES.length;
      return `<div class="quote">${QUOTES[i]}</div><div class="qf"><button class="ghost small" data-act="quote.next">${T('↻ Another one')}</button><span>${T('Quote {0} of {1} · a new one every day', i + 1, QUOTES.length)}</span></div>`;
    },
  },
  search: {
    name: 'Web search', icon: '🔎', desc: 'Search the web from your dashboard',
    render: () => `<form class="row" action="https://www.google.com/search" target="_blank" style="margin:0"><input name="q" placeholder="${T('Search the web…')}" required autocomplete="off"><button>${T('Go')}</button></form>`,
  },
};

function wxCode(c) {
  if (c === 0) return ['☀️', 'Clear']; if (c <= 2) return ['🌤️', 'Partly cloudy']; if (c === 3) return ['☁️', 'Cloudy'];
  if (c <= 48) return ['🌫️', 'Fog']; if (c <= 57) return ['🌦️', 'Drizzle']; if (c <= 67) return ['🌧️', 'Rain'];
  if (c <= 77) return ['🌨️', 'Snow']; if (c <= 82) return ['🌧️', 'Showers']; if (c <= 86) return ['🌨️', 'Snow showers']; return ['⛈️', 'Thunderstorm'];
}
async function loadWx(id, d) {
  if (wx[id]?.busy) return;
  wx[id] = { ...(wx[id] || {}), busy: true };
  try {
    const r = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${d.lat}&longitude=${d.lon}&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=4`)).json();
    wx[id] = { t: Date.now(), cur: r.current, daily: r.daily };
  } catch { wx[id] = { t: Date.now(), err: true }; }
  redraw(id);
}

/* ================= state, storage, sync ================= */
// Default widget titles and tab names are stored in English and translated when shown.
function mk(type) { const d = WIDGETS[type]; return { type, title: d.name, w: d.w || 4, data: d.init ? d.init() : {} }; }
// Upgrades older saved layouts: sizes become free widths, Agenda merges into Calendar, the quote moves up front.
function normalize(s) {
  let ch = false;
  for (const t of s.tabs) {
    const hasCal = t.widgets.some(id => s.widgets[id]?.type === 'calendar');
    t.widgets = t.widgets.filter(id => {
      const w = s.widgets[id]; if (!w) return false;
      if (w.type !== 'agenda' && !WIDGETS[w.type]) { ch = true; delete s.widgets[id]; return false; } // widget types that no longer exist (e.g. grades)
      if (w.type === 'agenda') { ch = true; if (hasCal) { delete s.widgets[id]; return false; } Object.assign(w, { type: 'calendar', title: 'Calendar', data: { mode: 'list' } }); }
      return true;
    });
    const q = t.widgets.find(id => s.widgets[id].type === 'quote' && s.widgets[id].w == null);
    if (q) t.widgets = [q, ...t.widgets.filter(x => x !== q)];
  }
  const used = new Set(s.tabs.flatMap(t => t.widgets));
  for (const id of Object.keys(s.widgets)) if (!used.has(id)) { delete s.widgets[id]; ch = true; }
  for (const w of Object.values(s.widgets)) if (w.w == null) { w.w = WIDGETS[w.type]?.w || [4, 4, 8, 12][w.size || 1]; delete w.size; ch = true; }
  return ch;
}
function defaultState(old) {
  const s = { v: 2, settings: { name: '', lang: 'nl', accent: ACCENTS[0], wall: 'aurora', mode: old?.theme === 'dark' ? 'dark' : 'auto' }, tabs: [], widgets: {}, events: old?.events || [], deadlines: old?.deadlines || [] };
  const tab = (name, icon, ...types) => {
    const t = { id: uid(), name, icon, widgets: [] }; s.tabs.push(t);
    types.forEach(([type, data]) => { const id = uid(); s.widgets[id] = mk(type); if (data) Object.assign(s.widgets[id].data, data); t.widgets.push(id); });
  };
  tab('Home', '🏠', ['quote'], ['today'], ['todo', old?.todos && { items: old.todos }], ['links', old?.links && { links: old.links }]);
  tab('Planner', '📅', ['calendar'], ['timetable'], ['deadlines']);
  tab('Focus', '🎯', ['pomodoro'], ['habits', old?.habits && { habits: old.habits }], ['countdown']);
  tab('Notes', '📝', ['notes', old?.notes && { text: old.notes }]);
  return s;
}
function setSync(cls, txt) { $('#sync').className = 'sync ' + cls; $('#syncTxt').textContent = T(txt); }

function load() { return APP ? loadCloud() : loadServer(); }
async function loadServer() {
  try {
    const d = await (await fetch('/api/data', { cache: 'no-store' })).json();
    setSync(dirty ? 'busy' : '', dirty ? 'Saving…' : 'Synced');
    if (d.rev === rev || dirty) return;
    const a = document.activeElement;
    if (rev !== -1 && (pk || (a && /INPUT|TEXTAREA/.test(a.tagName) && a.value))) return; // don't interrupt typing or an open picker
    rev = d.rev;
    if (d.state?.v === 2) { state = d.state; if (normalize(state)) save(); } else { state = defaultState(d.state); save(); }
    ls.set('dash-state', JSON.stringify(state)); render(); loadExt();
  } catch {
    setSync('off', 'Offline');
    if (rev === -1 && !state) { try { state = JSON.parse(ls.get('dash-state')); } catch {} state ||= defaultState(); normalize(state); render(); }
  }
}
function save() {
  dirty = true; ls.set('dash-state', JSON.stringify(state)); setSync('busy', 'Saving…');
  clearTimeout(saveTimer); saveTimer = setTimeout(flush, 400);
}
async function flush() { // saves right now; the server only sees changes (e.g. new calendar links) after this finishes
  clearTimeout(saveTimer);
  if (APP) return flushCloud();
  try { rev = (await (await fetch('/api/data', { method: 'PUT', body: JSON.stringify(state) })).json()).rev; dirty = false; setSync('', 'Synced'); }
  catch { setSync('off', 'Offline'); saveTimer = setTimeout(flush, 5000); }
}
const commit = () => { save(); render(); };

/* ================= rendering ================= */
const tab = () => state.tabs.find(t => t.id === curTab) || state.tabs[0];
function applyLook() {
  const s = state.settings, r = document.documentElement;
  r.dataset.theme = s.mode === 'dark' || (s.mode === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  r.dataset.wall = s.wall; r.style.setProperty('--accent', s.accent); r.lang = lang();
}
function header() {
  const n = new Date(), h = n.getHours(), name = state?.settings.name;
  $('#greeting').textContent = T(h < 6 ? 'Good night' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening') + (name ? `, ${name}` : '') + ' 👋';
  $('#date').textContent = n.toLocaleDateString(loc(), { weekday: 'long', day: 'numeric', month: 'long' }) + ' · ' + n.toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' });
}
let wasPhone = false;
let colF = 1; // on medium-width screens widgets take 1.5x their columns so they stay readable
const span = w => Math.min(12, Math.max(2, Math.round((w.w || 4) * colF)));
const ROW = 8, GAP = 16;
// Small screens (phone) have their own widget order per tab and can hide widgets; the computer layout stays untouched.
const phone = () => innerWidth <= 700;
function order(t, withHidden) {
  if (!phone()) return t.widgets;
  const p = t.phone || {}, mine = (p.order || []).filter(id => t.widgets.includes(id));
  const ids = [...mine, ...t.widgets.filter(id => !mine.includes(id))];
  return withHidden ? ids : ids.filter(id => !(p.hide || []).includes(id));
}
function orderArr(t) { if (!phone()) return t.widgets; t.phone ||= {}; t.phone.order = order(t, true); return t.phone.order; }
const hiddenOnPhone = id => phone() && (tab().phone?.hide || []).includes(id);
const ro = new ResizeObserver(es => es.forEach(e => { e.target.style.gridRowEnd = 'span ' + Math.ceil((e.target.offsetHeight + GAP) / ROW); }));

function widgetHtml(id) {
  const w = state.widgets[id], d = w && WIDGETS[w.type]; if (!d) return '';
  const hid = hiddenOnPhone(id);
  return `<section class="card t-${w.type} ${w.h ? 'fixed' : 'auto'}${hid ? ' phhid' : ''}" data-wid="${id}" style="grid-column:span ${span(w)};${w.h ? `grid-row:span ${w.h}` : ''}">
    <header class="wh">${edit ? `<span class="grip" title="${T('Drag to move')}">⠿</span>` : ''}<span class="wi">${d.icon}</span>${edit ? `<input class="wt-in" data-chg="w.title" value="${esc(T(w.title))}">` : `<h2>${esc(T(w.title))}</h2>`}</header>
    ${edit ? `<div class="tb"><button class="ghost small" data-act="w.move" data-n="-1" title="${T('Move earlier')}">${phone() ? '▲' : '◀'}</button><button class="ghost small" data-act="w.move" data-n="1" title="${T('Move later')}">${phone() ? '▼' : '▶'}</button>
      ${phone() ? `<button class="ghost small${hid ? ' on' : ''}" data-act="w.phhide">${T(hid ? '👁 Show on phone' : '🙈 Hide on phone')}</button>` : ''}
      ${w.h && !phone() ? `<button class="ghost small" data-act="w.auto" title="${T('Let the height follow the content again')}">${T('↕ Auto height')}</button>` : ''}
      ${state.tabs.length > 1 ? `<select data-chg="w.tab" title="${T('Move to tab')}">${state.tabs.map(t => `<option value="${t.id}" ${t.id === tab().id ? 'selected' : ''}>${t.icon} ${esc(T(t.name))}</option>`).join('')}</select>` : ''}
      <button class="ghost small" data-act="w.del">${T('🗑 Remove')}</button></div>` : ''}
    <div class="wb">${d.render(w, id)}</div>${edit ? `<span class="rz" title="${T('Drag to resize')}"></span>` : ''}</section>`;
}
function redraw(id) {
  const el = $(`[data-wid="${id}"] .wb`), w = state.widgets[id];
  if (el && w) { el.innerHTML = WIDGETS[w.type].render(w, id); if (w.type === 'pomodoro') drawPomo(id); }
}
function render() {
  if (!state) return;
  applyLook(); header();
  const t = tab();
  $('#nav').innerHTML = state.tabs.map(x => `<button class="tab ${x.id === t.id ? 'on' : ''}" data-act="tab.go" data-tab="${x.id}"><span class="ti">${x.icon}</span><span class="tn">${esc(T(x.name))}</span>${edit && x.id === t.id ? `<span class="pen" data-act="tab.edit" data-tab="${x.id}">✎</span>` : ''}</button>`).join('')
    + (edit ? `<button class="tab add" data-act="tab.new"><span class="ti">＋</span><span class="tn">${T('New tab')}</span></button>` : '');
  $('#editBtn').textContent = T(edit ? '✓ Done' : '✨ Customize');
  $('[data-act="ui.settings"]').title = T('Settings');
  const g = $('#grid'); g.classList.toggle('editing', edit); colF = g.clientWidth < 1000 ? 1.5 : 1; wasPhone = phone();
  const ids = order(t, edit);
  g.innerHTML = (edit && phone() ? `<div class="phnote">📱 ${T('You are arranging the phone layout. Your computer layout stays as it is.')}</div>` : '')
    + ids.map(widgetHtml).join('')
    + (edit ? `<button class="addtile" data-act="w.gallery">${T('＋ Add widget')}</button>`
      : ids.length ? '' : `<div class="welcome"><b>🧩</b>${T(t.widgets.length ? 'All widgets of this tab are hidden on your phone.' : 'This tab is empty.')}<br>${T('Press {0} to add widgets.', T('✨ Customize'))}</div>`);
  ids.forEach(id => state.widgets[id]?.type === 'pomodoro' && drawPomo(id));
  ro.disconnect(); g.querySelectorAll('.card.auto').forEach(c => ro.observe(c));
  if (refocus) { $(`[data-wid="${refocus[0]}"] [data-form="${refocus[1]}"] input`)?.focus(); refocus = null; }
}

/* ================= modals ================= */
function openModal(html) { $('#sheet').innerHTML = html; $('#modal').classList.remove('hidden'); }
function closeModal() { $('#modal').classList.add('hidden'); if (state) render(); } // also shows anything that changed while the dialog was open
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
function galleryModal() {
  openModal(`<h2>${T('Add a widget')}</h2><div class="sub">${T('Pick one to add it to “{0}”. You can add the same widget more than once.', esc(T(tab().name)))}</div>
    <div class="gal">${Object.entries(WIDGETS).map(([k, d]) => `<button data-act="w.add" data-type="${k}"><span class="wi">${d.icon}</span><span><b>${T(d.name)}</b><small>${T(d.desc)}</small></span></button>`).join('')}</div>
    <div class="mfoot"><span></span><button class="ghost" data-act="modal.close">${T('Close')}</button></div>`);
}
const PROVIDERS = [['google', 'Google'], ['icloud', 'iPhone / iCloud'], ['outlook', 'Outlook'], ['samsung', 'Samsung'], ['other', 'Other']];
const STEPS = {
  google: 'Open Google Calendar on a computer → Settings → click the calendar → “Integrate calendar” → copy the “Secret address in iCal format”.',
  icloud: 'On your iPhone: Calendar app → Calendars → (i) next to the calendar → turn on “Public Calendar” → Share Link → copy. Note: anyone with this link can see that calendar.',
  outlook: 'Outlook.com → Settings → Calendar → Shared calendars → Publish a calendar → choose the calendar → Publish → copy the ICS link.',
  samsung: 'Samsung Calendar has no link of its own: it shows the calendars of the Google or Microsoft account on your phone. Use the Google or Outlook steps for that account. Events saved only on the phone or in a Samsung account can’t be linked.',
  other: 'Paste any calendar link that ends in .ics or starts with webcal://. Many school and work timetable systems offer one.',
};
const CAL_ERR = {
  invalid: 'This isn’t a calendar link, or it has expired. Use the secret iCal / .ics link.', blocked: 'This link isn’t allowed. Use a public https link.',
  timeout: 'The calendar took too long to respond.', http: 'The calendar site refused the link.', big: 'This calendar is too large.', fail: 'Could not load this calendar.',
};
/* ---- Google Calendar (two-way) ---- */
const G_ERR = {
  login: 'Your Google login expired. Log in again in Settings.', api_disabled: 'The Google Calendar API is switched off in your Google project. Enable it (step 2 in Settings), then try again.',
  forbidden: 'Google says you can’t change this calendar.', bad: 'Check the date and time.', timeout: 'Google took too long to respond.', fail: 'Could not reach Google. Try again.',
};
const G_STEPS = [
  'Go to console.cloud.google.com and create a project (call it “Dashboard”).',
  'Open “APIs & Services” → “Library”, search for “Google Calendar API” and press Enable.',
  'Open “OAuth consent screen” (or “Google Auth Platform”). Choose External, fill in an app name and your own email address.',
  'Press “Publish app” so the status is “In production”. Otherwise Google logs you out every 7 days. At login you will see an “unverified app” warning: choose Advanced → continue.',
  'Open “Credentials” → Create credentials → OAuth client ID → type “Desktop app”. Copy the Client ID and Client secret into the boxes below.',
];
let gCals = [];
function toast(msg) { const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.append(t); setTimeout(() => t.remove(), 4500); }
async function gWrite(method, payload) { // changes an event in Google, then reloads the calendars
  setSync('busy', 'Saving…');
  let ok = false;
  try {
    const r = await fetch('/api/google/event', { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...payload, tz: TZ }) });
    if (!r.ok) { const code = (await r.json().catch(() => ({}))).error || 'fail'; throw Object.assign(new Error(code), { code }); }
    await loadExt(true); ok = true;
  } catch (e) { toast(T(G_ERR[e.code] || G_ERR.fail)); if (e.code === 'login') loadExt(true); }
  setSync(dirty ? 'busy' : '', dirty ? 'Saving…' : 'Synced'); render(); return ok;
}
function gTarget() { return ext.g?.connected ? (state.settings.google?.def || ext.g.primary || '') : ''; }
async function addEvent(ev, form) { // new events go to Google when it is connected, otherwise they stay in the dashboard
  const cal = gTarget();
  if (!cal) { state.events.push({ id: uid(), ...ev }); return commit(); }
  form?.reset(); await gWrite('POST', { cal, ...ev });
}
function eventModal(e) {
  const g = !!e.g, allDay = g ? !!e.allDay : false;
  openModal(`<h2>${T('Edit event')}</h2><form data-form="ev.save">
    <input type="hidden" name="src" value="${g ? 'g' : 'l'}"><input type="hidden" name="id" value="${esc(e.id)}"><input type="hidden" name="gcal" value="${esc(e.gcal || '')}">
    <h3>${T('Title')}</h3><input name="title" value="${esc(e.title)}" required style="width:100%" autocomplete="off">
    <h3>${T('Date')}</h3><div class="row">${dateIn('date', allDay ? e.startDate : e.date, { req: true })}${allDay ? `<label class="fl">${T('until')} ${dateIn('endDate', e.endDate || '')}</label>` : ''}</div>
    ${allDay ? '' : `<h3>${T('Time')}</h3><div class="row">${timeIn('time', e.time || '', { ph: 'Start' })}<label class="fl">–${timeIn('end', e.end || '', { ph: 'End' })}</label></div>`}
    ${g ? `<div class="sub">${esc(e.calName)}${e.recurring ? ' · ' + T('Repeating event: only this one changes.') : ''}</div>` : ''}
    <div class="mfoot"><button type="button" class="ghost" data-act="modal.close">${T('Cancel')}</button><button>${T('Save')}</button></div></form>`);
}
async function loadGoogleBox() {
  const box = $('#gBox'); if (!box) return;
  let st, calErr = '';
  try {
    st = await (await fetch('/api/google/status', { cache: 'no-store' })).json(); gCals = [];
    if (st.connected) gCals = (await (await fetch('/api/google/calendars', { cache: 'no-store' })).json()).calendars || [];
  } catch { box.innerHTML = `<div class="sub err">${T('Could not reach the dashboard server.')}</div>`; return; }
  const gs = state.settings.google || {}, primary = gCals.find(c => c.primary)?.id, def = gs.def || primary;
  if (ext.g?.error) calErr = `<div class="sub err" style="margin-top:6px">${T(G_ERR[ext.g.error] || G_ERR.fail)}</div>`;
  let h = '';
  if (!st.configured) {
    h = st.local ? `<details><summary>${T('How do I get these keys? (about 10 minutes, once)')}</summary><ol class="gsteps">${G_STEPS.map(s => `<li>${T(s)}</li>`).join('')}</ol></details>
      <form class="row" data-form="g.save" style="margin-top:8px"><input name="clientId" placeholder="Client ID" required autocomplete="off"><input name="clientSecret" type="password" placeholder="Client secret" required autocomplete="off"><button>${T('Save')}</button></form>`
      : `<div class="sub">${T('Set this up on the laptop that runs the dashboard.')}</div>`;
  } else if (!st.connected) {
    h = `${st.needsLogin ? `<div class="sub err">${T(G_ERR.login)}</div>` : ''}` + (st.local
      ? `<div class="row"><button data-act="g.login">${T('Log in with Google')}</button><button class="ghost" data-act="g.clear">${T('Remove saved keys')}</button></div>`
      : `<div class="sub">${T('Set this up on the laptop that runs the dashboard.')}</div>`);
  } else {
    h = `<div class="sub">✓ ${T('Connected to Google. Changes you make here show up in your Google Calendar (and on your phone), and the other way round.')}</div>
      <ul class="list">${gCals.map(c => `<li><span class="dot" style="background:${esc(c.color)}"></span>
        <label class="t"><input type="checkbox" data-chg="g.show" data-id="${esc(c.id)}" ${(gs.show ? gs.show[c.id] : c.selected) ? 'checked' : ''}> ${esc(c.name)}</label>
        ${c.writable ? `<label class="fl"><input type="radio" name="gdef" data-chg="g.def" data-id="${esc(c.id)}" ${def === c.id ? 'checked' : ''}> ${T('new events')}</label>` : `<span class="sub">${T('read-only')}</span>`}</li>`).join('')}</ul>${calErr}
      <div class="row" style="margin-top:8px"><button class="ghost small" data-act="g.refresh">↻ ${T('Refresh now')}</button>${st.local ? `<button class="ghost small" data-act="g.logout">${T('Disconnect')}</button>` : ''}</div>`;
  }
  box.innerHTML = h;
}
function calListHtml() {
  const cals = state.settings.calendars || [];
  return cals.length ? `<ul class="list">${cals.map(c => {
    const s = ext.status[c.id];
    const msg = !s ? T('Syncing…') : s.ok ? T('Synced at {0} · {1} events', new Date(s.t).toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' }), s.n) : T(CAL_ERR[s.error] || CAL_ERR.fail);
    return `<li><span class="dot" style="background:${esc(c.color)}"></span><span class="t">${esc(c.name)}<br><span class="sub ${s && !s.ok ? 'err' : ''}">${msg}</span></span>
      <button class="x" data-act="calsrc.del" data-id="${c.id}" title="${T('Remove')}">×</button></li>`;
  }).join('')}</ul><button class="ghost small" data-act="calsrc.refresh">↻ ${T('Refresh now')}</button>` : '';
}
function settingsModal() {
  const s = state.settings, opt = (k, cur, list) => list.map(([v, l]) => `<button class="txt ${cur === v ? 'on' : ''}" data-act="set" data-k="${k}" data-v="${v}">${T(l)}</button>`).join('');
  openModal(`<h2>${T('Make it yours')}</h2>
    <h3>${T('Language')}</h3><div class="sw">${opt('lang', lang(), [['nl', 'Nederlands'], ['en', 'English']])}</div>
    <h3>${T('Your name')}</h3><input data-inp="set.name" value="${esc(s.name)}" placeholder="${T('For the greeting')}" style="width:100%">
    <h3>${T('Appearance')}</h3><div class="sw">${opt('mode', s.mode, [['auto', 'Auto'], ['light', 'Light'], ['dark', 'Dark']])}</div>
    <h3>${T('Accent colour')}</h3><div class="sw">${ACCENTS.map(c => `<button class="${s.accent === c ? 'on' : ''}" style="background:${c}" data-act="set" data-k="accent" data-v="${c}"></button>`).join('')}</div>
    <h3>${T('Background')}</h3><div class="sw">${opt('wall', s.wall, WALLS)}</div>
    ${APP ? appAccountHtml() : `<h3>${T('Sync with your phone')}</h3><div id="cloudBox"><div class="sub">…</div></div>
    <h3>${T('Google Calendar (two-way)')}</h3><div id="gBox"><div class="sub">…</div></div>
    <h3>${T('Link other calendars (read-only)')}</h3>`}
    <div class="sub">${T('Show events from Google, iPhone, Outlook… on your dashboard. They are read-only and refresh automatically.')}</div>
    ${APP ? '' : `<div class="chips" style="margin:10px 0 6px">${chips('prov', view.prov || 'google', PROVIDERS)}</div>
    <div class="steps" id="provSteps">${T(STEPS[view.prov || 'google'])}</div>
    <form class="row" data-form="calsrc.add" style="margin-top:10px"><input name="name" placeholder="${T('Calendar name')}" required autocomplete="off" style="flex:0 1 150px"><input name="url" placeholder="${T('Paste the calendar link')}" required autocomplete="off"><button>${T('Link')}</button></form>
    <div class="sub err" id="calMsg"></div>
    <div id="calList">${calListHtml()}</div>
    <div class="sub" style="margin-top:8px">${T('Sync is one-way: changes made here are not sent back to your calendar. The link is saved in this dashboard’s data file on this computer.')}</div>`}
    <div class="mfoot"><span></span><button data-act="modal.close">${T('Done')}</button></div>`);
  if (!APP) { loadGoogleBox(); loadCloudBox(); }
}
function appAccountHtml() {
  const t = ext.t ? new Date(ext.t).toLocaleString(loc(), { weekday: 'short', hour: '2-digit', minute: '2-digit' }) : '';
  return `<h3>${T('Account')}</h3><div class="sub">✓ ${T('Signed in as {0}. Changes sync with your laptop.', esc(cloud.auth?.email || ''))}</div>
    <div class="sub" style="margin-top:6px">${T('Calendar appointments come from your laptop and are read-only here. Add appointments in your phone’s calendar app.')}${t ? ' ' + T('Last update: {0}.', t) : ''}</div>
    <div class="row" style="margin-top:8px"><button class="ghost small" data-act="app.logout">${T('Sign out')}</button></div>`;
}
async function loadCloudBox() {
  const box = $('#cloudBox'); if (!box) return;
  let s; try { s = await (await fetch('/api/cloud', { cache: 'no-store' })).json(); } catch { box.innerHTML = ''; return; }
  if (!s.configured) { box.innerHTML = `<div class="sub">${T('Not set up yet.')}</div>`; return; }
  const when = s.last ? new Date(s.last).toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' }) : '';
  box.innerHTML = s.linked
    ? `<div class="sub">✓ ${T('Synced with the phone app ({0}).', esc(s.email))}${when ? ' ' + T('Last change: {0}.', when) : ''}${s.error === 'net' ? ` <span class="err">${T('No connection right now.')}</span>` : ''}</div>
      <div class="row" style="margin-top:8px"><button class="ghost small" data-act="cloud.sync">↻ ${T('Sync now')}</button><button class="ghost small" data-act="cloud.unlink">${T('Stop syncing')}</button></div>`
    : (s.error === 'scope' || s.error === 'link'
      ? `<div class="sub err">${T('Log in with Google again (once) to switch on sync with your phone.')}</div><div class="row" style="margin-top:8px"><button data-act="g.login">${T('Log in with Google')}</button></div>`
      : `<div class="sub">${T('Log in with Google below to switch on sync with your phone. It uses the same account.')}</div>`);
}
function tabModal(id) {
  const t = state.tabs.find(x => x.id === id) || { id: '', name: '', icon: '⭐' };
  openModal(`<h2>${T(id ? 'Edit tab' : 'New tab')}</h2><form data-form="tab.save"><input type="hidden" name="id" value="${t.id}">
    <h3>${T('Name')}</h3><input name="name" value="${esc(T(t.name))}" placeholder="${T('School, Work, Gym…')}" required maxlength="18" style="width:100%" autocomplete="off">
    <h3>${T('Icon')}</h3><div class="emo">${EMOJI.map(e => `<label><input type="radio" name="icon" value="${e}" ${e === t.icon ? 'checked' : ''}><span>${e}</span></label>`).join('')}</div>
    <div class="mfoot">${id && state.tabs.length > 1 ? `<button type="button" class="ghost" data-act="tab.del" data-tab="${id}">${T('🗑 Delete tab')}</button>` : '<span></span>'}<button>${T('Save')}</button></div></form>`);
}

/* ================= focus timer ================= */
function timer(id) { return timers[id] ||= { mins: 25, left: 1500, running: false, end: 0, brk: false }; }
function drawPomo(id) {
  const el = $(`[data-wid="${id}"]`), t = timer(id); if (!el || !$('.pt', el)) return;
  $('.pt', el).textContent = `${pad(Math.floor(t.left / 60))}:${pad(t.left % 60)}`;
  $('.pm', el).textContent = T(t.brk ? 'Break' : 'Focus');
  $('.pgo', el).textContent = T(t.running ? 'Pause' : 'Start');
  $('.pr', el).style.strokeDashoffset = 452.4 * (1 - t.left / (t.mins * 60));
}
function pomoSet(id, mins, brk) { Object.assign(timer(id), { mins, brk, left: mins * 60, running: false }); }
function beep() {
  try { navigator.vibrate?.([200, 100, 200]); } catch {}
  try { const a = new (window.AudioContext || window.webkitAudioContext)(), o = a.createOscillator(), g = a.createGain(); o.frequency.value = 660; g.gain.value = .15; o.connect(g).connect(a.destination); o.start(); o.stop(a.currentTime + .5); } catch {}
}
setInterval(() => {
  let title = T('My Dashboard');
  for (const id in timers) {
    const t = timers[id]; if (!t.running) continue;
    t.left = Math.max(0, Math.round((t.end - Date.now()) / 1000)); drawPomo(id);
    title = `${pad(Math.floor(t.left / 60))}:${pad(t.left % 60)} · ${T(t.brk ? 'Break' : 'Focus')}`;
    if (!t.left) {
      beep(); const w = state.widgets[id], was = t.brk; pomoSet(id, was ? 25 : 5, !was);
      if (w && !was) { (w.data.log ||= {})[todayStr()] = (w.data.log[todayStr()] || 0) + 1; confetti(innerWidth / 2, innerHeight / 3, 40); commit(); } else render();
    }
  }
  document.title = title;
}, 500);

function confetti(x, y, n = 14) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  for (let i = 0; i < n; i++) {
    const p = document.createElement('i'); p.className = 'cf';
    p.style.cssText = `left:${x}px;top:${y}px;background:hsl(${Math.random() * 360} 90% 60%);--dx:${(Math.random() - .5) * 240}px;--dy:${-Math.random() * 170 - 30}px;--r:${Math.random() * 720}deg`;
    document.body.append(p); setTimeout(() => p.remove(), 900);
  }
}

/* ================= actions ================= */
const rm = (arr, id) => arr.filter(x => x.id !== id);
const ACT = {
  'ui.edit': () => { edit = !edit; render(); },
  'ui.settings': settingsModal,
  'modal.close': closeModal,
  'ev.edit': ({ d }) => { const e = d.gid ? ext.events.find(x => x.g && x.gcal === d.gcal && x.id === d.gid) : state.events.find(x => x.id === d.id); if (e) eventModal(e); },
  'gev.del': ({ d }) => { if (confirm(T('Delete this event from Google Calendar? It disappears on your phone too.'))) gWrite('DELETE', { cal: d.gcal, id: d.gid }); },
  'g.login': async () => {
    await flush();
    const r = await fetch('/api/google/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    const j = await r.json().catch(() => ({}));
    if (!j.url) return toast(T(G_ERR.fail));
    if (!/Electron/.test(navigator.userAgent)) { location.href = j.url; return; }
    window.open(j.url); // desktop app: Google sign-in opens in the normal browser; wait here until it is done
    for (let i = 0; i < 150; i++) {
      await new Promise(r => setTimeout(r, 2000));
      const s = await fetch('/api/google/status').then(r => r.json()).catch(() => ({}));
      if (s.connected) { settingsModal(); loadExt(true); return toast(T('Google connected!')); }
    }
  },
  'g.logout': async () => { if (!confirm(T('Disconnect Google Calendar? Your events stay in Google.'))) return; await fetch('/api/google/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); await loadExt(true); render(); loadGoogleBox(); },
  'app.logout': () => { if (confirm(T('Sign out on this phone? Your data stays safe in your account.'))) { closeModal(); cloudSignOut(); } },
  'cloud.sync': async () => { await fetch('/api/cloud/sync', { method: 'POST' }).catch(() => {}); loadCloudBox(); },
  'cloud.unlink': async () => { if (!confirm(T('Stop syncing this computer with your phone? Nothing is deleted.'))) return; await fetch('/api/cloud/unlink', { method: 'POST' }).catch(() => {}); loadCloudBox(); },
  'g.clear': async () => { await fetch('/api/google/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); loadGoogleBox(); },
  'g.refresh': async () => { await loadExt(true); loadGoogleBox(); },
  'prov': ({ d }) => { view.prov = d.v; $('#provSteps').textContent = T(STEPS[d.v]); document.querySelectorAll('[data-act="prov"]').forEach(b => b.classList.toggle('on', b.dataset.v === d.v)); },
  'calsrc.del': ({ d }) => {
    if (!confirm(T('Remove this calendar link?'))) return;
    state.settings.calendars = rm(state.settings.calendars || [], d.id); save(); flush().then(() => loadExt()); $('#calList').innerHTML = calListHtml(); render();
  },
  'calsrc.refresh': () => { loadExt(true); },
  'set': ({ d }) => { state.settings[d.k] = d.v; save(); render(); setSync('busy', 'Saving…'); settingsModal(); },
  'tab.go': ({ d }) => { curTab = d.tab; ls.set('dash-tab', curTab); render(); $('.main').scrollTop = 0; },
  'tab.new': () => tabModal(),
  'tab.edit': ({ d, e }) => { e.stopPropagation(); tabModal(d.tab); },
  'tab.del': ({ d }) => {
    const t = state.tabs.find(x => x.id === d.tab);
    if (!confirm(T('Delete the tab “{0}” and its {1} widget(s)?', T(t.name), t.widgets.length))) return;
    t.widgets.forEach(id => delete state.widgets[id]); state.tabs = rm(state.tabs, t.id); curTab = state.tabs[0].id; closeModal(); commit();
  },
  'w.gallery': galleryModal,
  'w.add': ({ d }) => { const id = uid(); state.widgets[id] = mk(d.type); tab().widgets.push(id); closeModal(); commit(); $(`[data-wid="${id}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }); },
  'note.new': ({ w, id }) => { const n = { id: uid(), text: '', t: Date.now() }; notesOf(w).push(n); view[id].note = n.id; save(); redraw(id); $(`[data-wid="${id}"] .ntext`)?.focus(); },
  'note.open': ({ id, d }) => { view[id].note = d.id; redraw(id); const ta = $(`[data-wid="${id}"] .ntext`); if (ta && !phone()) { ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); } },
  'note.back': ({ w, id }) => { // an empty note is not kept
    const n = notesOf(w).find(x => x.id === view[id].note); view[id].note = null;
    if (n && !n.text.trim()) { w.data.notes = w.data.notes.filter(x => x !== n); save(); } redraw(id);
  },
  'note.pin': ({ w, id }) => { const n = notesOf(w).find(x => x.id === view[id].note); if (n) { n.pin = !n.pin; save(); redraw(id); } },
  'note.del': ({ w, id }) => {
    const n = notesOf(w).find(x => x.id === view[id].note); if (!n) return;
    if (n.text.trim() && !confirm(T('Delete the note “{0}”?', noteTitle(n)))) return;
    w.data.notes = w.data.notes.filter(x => x !== n); view[id].note = null; save(); redraw(id);
  },
  'w.phhide':({ id }) => { const t = tab(), p = t.phone ||= {}, h = p.hide ||= []; p.hide = h.includes(id) ? h.filter(x => x !== id) : [...h, id]; commit(); },
  'w.move': ({ id, d }) => { const a = orderArr(tab()), i = a.indexOf(id), j = i + +d.n; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; commit(); },
  'w.auto': ({ w }) => { delete w.h; commit(); },
  'w.del': ({ w, id }) => { if (!confirm(T('Remove “{0}”? Its contents will be deleted.', T(w.title)))) return; const t = tab(); t.widgets = t.widgets.filter(x => x !== id); delete state.widgets[id]; commit(); },

  'todo.toggle': ({ w, d, el }) => {
    const x = w.data.items.find(i => i.id === d.id); x.done = !x.done;
    if (x.done) { const r = el.getBoundingClientRect(); confetti(r.x + 11, r.y + 11, w.data.items.every(i => i.done) ? 40 : 12); }
    commit();
  },
  'todo.del': ({ w, d }) => { w.data.items = rm(w.data.items, d.id); commit(); },
  'todo.clear': ({ w }) => { w.data.items = w.data.items.filter(x => !x.done); commit(); },
  'ev.del': ({ d }) => { state.events = rm(state.events, d.id); commit(); },
  'dl.del': ({ d }) => { state.deadlines = rm(state.deadlines, d.id); commit(); },
  'cal.mode': ({ w, d }) => { w.data.mode = d.v; commit(); },
  'cal.sel': ({ id, d }) => { view[id].sel = d.day; redraw(id); },
  'cal.nav': ({ id, d }) => { const [y, m] = view[id].ym.split('-').map(Number), x = new Date(y, m - 1 + +d.n, 1); view[id].ym = iso(x).slice(0, 7); redraw(id); },
  'tt.mode': ({ w, d }) => { w.data.mode = d.v; commit(); },
  'tt.new': ({ id }) => slotModal(id),
  'tt.open': ({ id, d }) => slotModal(id, d.id),
  'tt.rm': ({ w, d }) => { if (!confirm(T('Delete this class?'))) return; w.data.slots = rm(w.data.slots, d.id); refocus = null; closeModal(); commit(); },
  'pal.add': () => {
    const c = hsl2hex(+$('.hue').value), p = state.settings.palette ||= [];
    if (!palette().includes(c)) { p.push(c); if (p.length > 10) p.shift(); save(); }
    $('#cpal').innerHTML = palHtml(c);
  },
  'pal.del': ({ d, e }) => {
    e.preventDefault(); state.settings.palette = (state.settings.palette || []).filter(c => c !== d.c); save();
    const cur = $('#cpal input:checked')?.value; $('#cpal').innerHTML = palHtml(cur === d.c ? PALETTE[0] : cur);
  },
  'link.edit': ({ id }) => { (view[id] ||= {}).edit = !view[id].edit; redraw(id); },
  'link.del': ({ w, d, e }) => { e.preventDefault(); w.data.links = rm(w.data.links, d.id); commit(); },
  'habit.tick': ({ w, d, el }) => {
    const h = w.data.habits.find(x => x.id === d.id);
    if (h.days[d.day]) delete h.days[d.day]; else { h.days[d.day] = true; const r = el.getBoundingClientRect(); confetti(r.x + 13, r.y + 13, 8); }
    commit();
  },
  'habit.del': ({ w, d }) => { w.data.habits = rm(w.data.habits, d.id); commit(); },
  'cd.edit': ({ id }) => { (view[id] ||= {}).edit = true; redraw(id); },
  'wx.clear': ({ w, id }) => { w.data = {}; delete wx[id]; commit(); },
  'wx.retry': ({ id }) => { delete wx[id]; redraw(id); },
  'quote.next': ({ id }) => { const v = view[id] ||= {}; v.i = ((v.i ?? Math.floor(Date.now() / 864e5)) + 1) % QUOTES.length; redraw(id); },
  'pomo.go': ({ id }) => { const t = timer(id); t.running = !t.running; if (t.running) t.end = Date.now() + t.left * 1000; drawPomo(id); },
  'pomo.reset': ({ id }) => { const t = timer(id); pomoSet(id, t.mins, t.brk); drawPomo(id); },
  'pomo.set': ({ id, d }) => { pomoSet(id, +d.m, d.b === '1'); redraw(id); },
};
const FORM = {
  'todo.add': ({ w, v }) => { w.data.items.push({ id: uid(), text: v.text, done: false, prio: +v.prio, due: v.due }); commit(); },
  'ev.add': ({ el, v }) => addEvent({ title: v.title, date: v.date, time: v.time }, el),
  'cal.add': ({ el, id, v }) => addEvent({ title: v.title, date: view[id].sel, time: v.time }, el),
  'ev.save': async ({ v }) => {
    refocus = null; closeModal();
    if (v.src === 'l') { const e = state.events.find(x => x.id === v.id); if (e) Object.assign(e, { title: v.title, date: v.date, time: v.time || '', end: v.end || '' }); return commit(); }
    await gWrite('PATCH', { cal: v.gcal, id: v.id, title: v.title, date: v.date, time: v.time, end: v.end, endDate: v.endDate, allDay: !('time' in v) });
  },
  'g.save': async ({ el, v }) => {
    refocus = null;
    const r = await fetch('/api/google/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ clientId: v.clientId, clientSecret: v.clientSecret }) });
    if (!r.ok) toast(T(G_ERR.fail)); el.reset(); loadGoogleBox();
  },
  'dl.add': ({ v }) => { state.deadlines.push({ id: uid(), title: v.title, date: v.date }); commit(); },
  'tt.save': ({ w, id, el, v }) => {
    const ds = new FormData(el).getAll('day').map(Number);
    if (!ds.length) return toast(T('Pick at least one day.'));
    const base = { title: v.title, start: v.start, end: v.end > v.start ? v.end : '', room: v.room, color: v.color || '' };
    const s = w.data.slots.find(x => x.id === v.sid);
    if (s) Object.assign(s, base, { day: ds[0] });
    (s ? ds.slice(1) : ds).forEach(day => w.data.slots.push({ id: uid(), day, ...base }));
    if (v.same && v.color) w.data.slots.forEach(x => { if (x.title.toLowerCase() === v.title.toLowerCase()) x.color = v.color; });
    (view[id] ||= {}).day = ds[0]; refocus = null; closeModal(); commit();
  },
  'link.add': ({ w, v }) => { w.data.links.push({ id: uid(), name: v.name, url: /^https?:\/\//i.test(v.url) ? v.url : 'https://' + v.url }); commit(); },
  'habit.add': ({ w, v }) => { w.data.habits.push({ id: uid(), name: v.name, days: {} }); commit(); },
  'cd.set': ({ w, id, v }) => { w.data = { title: v.title, date: v.date }; (view[id] ||= {}).edit = false; refocus = null; commit(); },
  'wx.set': async ({ w, id, v }) => {
    refocus = null; const vw = view[id] ||= {};
    try {
      const r = (await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?count=1&language=${lang()}&name=${encodeURIComponent(v.city)}`)).json()).results?.[0];
      if (!r) { vw.msg = T("Couldn't find “{0}”.", v.city); return redraw(id); }
      w.data = { city: r.name, lat: r.latitude, lon: r.longitude }; delete wx[id]; commit();
    } catch { vw.msg = T('No internet connection.'); redraw(id); }
  },
  'calsrc.add': ({ el, v }) => {
    refocus = null; const cals = state.settings.calendars ||= [], msg = $('#calMsg');
    if (!/^(https?|webcal):\/\//i.test(v.url)) { msg.textContent = T(CAL_ERR.invalid); return; }
    if (cals.some(c => c.url === v.url)) { msg.textContent = ''; return; }
    if (ext.g?.connected && /calendar\.google\.com/i.test(v.url)) { msg.textContent = T('Google is already connected, so this calendar would show twice. Use the Google connection above.'); return; }
    if (cals.length >= 12) { msg.textContent = T('Up to 12 calendars.'); return; }
    msg.textContent = ''; cals.push({ id: uid(), name: v.name, url: v.url, color: CAL_COLORS[cals.length % CAL_COLORS.length] });
    save(); el.reset(); $('#calList').innerHTML = calListHtml(); flush().then(() => loadExt(true));
  },
  'tab.save': ({ v }) => {
    let t = state.tabs.find(x => x.id === v.id);
    if (!t) { t = { id: uid(), widgets: [] }; state.tabs.push(t); curTab = t.id; ls.set('dash-tab', curTab); }
    if (v.name !== T(t.name ?? '')) t.name = v.name; // keep the stored default when the shown name wasn't changed
    t.icon = v.icon || '⭐'; refocus = null; closeModal(); commit();
  },
};
const CHG = {
  'g.show': ({ d, el }) => {
    const gs = state.settings.google ||= {}; gs.show ||= Object.fromEntries(gCals.map(c => [c.id, c.selected]));
    gs.show[d.id] = el.checked; save(); flush().then(() => loadExt(true));
  },
  'g.def': ({ d }) => { (state.settings.google ||= {}).def = d.id; save(); },
  'w.title': ({ w, el }) => { const def = WIDGETS[w.type].name, val = el.value.trim(); w.title = !val || val === T(def) ? def : val; save(); },
  'w.tab': ({ id, el }) => { const from = tab(), to = state.tabs.find(t => t.id === el.value); if (to === from) return; from.widgets = from.widgets.filter(x => x !== id); to.widgets.push(id); commit(); },
};
const INP = {
  'pal.hue': ({ el }) => { $('#huePrev').style.background = hsl2hex(+el.value); },
  'tt.title': ({ el }) => { // a name you used before picks the colour it already has
    const w = state.widgets[el.closest('form').dataset.wid], s = w?.data.slots.find(x => x.title.toLowerCase() === el.value.trim().toLowerCase());
    if (s) $('#cpal').innerHTML = palHtml(slotColor(s));
  },
  'note': ({ w, el }) => {
    const n = notesOf(w).find(x => x.id === el.dataset.id); if (!n) return;
    n.text = el.value; n.t = Date.now(); save();
    const s = el.closest('.wb')?.querySelector('.nbar .sub'); if (s) s.textContent = `${T('Saved')} · ${T('just now')}`;
  },
  'note.q': ({ id, el }) => { view[id].q = el.value; const pos = el.selectionStart; redraw(id); const i = $(`[data-wid="${id}"] [data-inp="note.q"]`); if (i) { i.focus(); i.setSelectionRange(pos, pos); } },
  'set.name': ({ el }) => { state.settings.name = el.value.trim(); save(); header(); },
};
const ctx = (el, e) => { const id = el.closest('[data-wid]')?.dataset.wid; return { id, w: state.widgets[id], d: el.dataset, el, e }; };
document.addEventListener('click', e => { const b = e.target.closest('[data-act]'); if (b && state) ACT[b.dataset.act]?.(ctx(b, e)); });
document.addEventListener('change', e => { const k = e.target.dataset?.chg; if (k) CHG[k](ctx(e.target, e)); });
document.addEventListener('input', e => { const k = e.target.dataset?.inp; if (k) INP[k](ctx(e.target, e)); });
document.addEventListener('submit', e => {
  const f = e.target.closest('[data-form]'); if (!f) return;
  e.preventDefault();
  const miss = [...f.querySelectorAll('.pk[data-req]')].find(x => !x.querySelector('input').value);
  if (miss) return pickOpen(miss); // a required date/time is still empty: open its picker
  pickClose();
  const c = ctx(f, e); c.v = Object.fromEntries([...new FormData(f)].map(([k, v]) => [k, String(v).trim()]));
  refocus = [c.id, f.dataset.form]; FORM[f.dataset.form](c);
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') { if (pk) pickClose(); else closeModal(); } });

/* ================= drag to move / resize (Customize mode) ================= */
let drag = null;
document.addEventListener('pointerdown', e => {
  if (!edit) return;
  const card = e.target.closest('.card'), id = card?.dataset.wid; if (!id) return;
  if (e.target.closest('.grip')) { drag = { move: true, card, id }; card.classList.add('dragging'); }
  else if (e.target.closest('.rz')) drag = { card, id, r: card.getBoundingClientRect(), x: e.clientX, y: e.clientY };
  else return;
  e.preventDefault();
});
document.addEventListener('pointermove', e => {
  if (!drag) return;
  if (drag.move) {
    const over = document.elementFromPoint(e.clientX, e.clientY)?.closest('.card[data-wid]');
    if (!over || over === drag.card) { drag.last = null; return; }
    if (over === drag.last) return; drag.last = over;
    const a = orderArr(tab()), i = a.indexOf(drag.id), j = a.indexOf(over.dataset.wid);
    a.splice(i, 1); a.splice(j, 0, drag.id);
    j > i ? over.after(drag.card) : over.before(drag.card);
  } else {
    const w = state.widgets[drag.id], cw = ($('#grid').clientWidth - 11 * GAP) / 12;
    w.w = Math.min(12, Math.max(2, Math.round((drag.r.width + e.clientX - drag.x + GAP) / (cw + GAP) / colF)));
    w.h = Math.max(12, Math.round((drag.r.height + e.clientY - drag.y + GAP) / ROW));
    ro.unobserve(drag.card); drag.card.classList.replace('auto', 'fixed');
    drag.card.style.gridColumn = 'span ' + span(w); drag.card.style.gridRow = 'span ' + w.h;
  }
});
const dragEnd = () => { if (!drag) return; drag.card.classList.remove('dragging'); drag = null; commit(); };
document.addEventListener('pointerup', dragEnd); document.addEventListener('pointercancel', dragEnd);
addEventListener('resize', () => { if (state && !drag && (($('#grid').clientWidth < 1000 ? 1.5 : 1) !== colF || phone() !== wasPhone)) render(); });

/* ================= init ================= */
setInterval(header, 15000);
load(); setInterval(() => { if (!APP || !document.hidden) load(); }, APP ? 20000 : 5000); // the phone reads the cloud less often (free quota)
setInterval(() => loadExt(), 2 * 60e3);
// Phone app updates: new screens/features download by themselves and are used from the next start;
// a new .apk (rare) is offered as a download that you install with one tap.
async function appUpdates() {
  const U = window.Capacitor.Plugins.CapacitorUpdater; U?.notifyAppReady().catch(() => {});
  try {
    const [mine, latest] = await Promise.all([fetch('build.json').then(r => r.json()), fetch('https://gerbenarnalsteen.github.io/Productivity-dashboard/app-update/latest.json', { cache: 'no-store' }).then(r => r.json())]);
    const info = await window.Capacitor.Plugins.App.getInfo().catch(() => ({ build: '0' }));
    if (latest.apk > +info.build) {
      if (ls.get('dash-apk-asked') !== String(latest.apk) && confirm(T('A new version of the app is available. Download it now? (Then tap Install.)'))) window.open(latest.apkUrl, '_system');
      ls.set('dash-apk-asked', String(latest.apk));
    } else if (U && latest.web > mine.web) {
      const b = await U.download({ url: latest.zip, version: String(latest.web) }); await U.next({ id: b.id });
      toast(T('An update is ready. It will be used the next time you open the app.'));
    }
  } catch {}
}
if (APP) { document.documentElement.classList.add('app'); setTimeout(appUpdates, 4000); }
{ // back from the Google sign-in page
  const gp = new URLSearchParams(location.search).get('google');
  if (gp) { history.replaceState(null, '', '/'); const t = setInterval(() => { if (!state) return; clearInterval(t); settingsModal(); loadExt(true); toast(T(gp === 'ok' ? 'Google connected!' : 'Google login failed. Try again.')); }, 200); }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) { load(); loadExt(); } });
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => state && applyLook());
if (!APP && 'serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
