'use strict';
/* ================= Extras: a task from a mail, searching everything (Ctrl+K) and reminders =================
   Loaded after app.js and mail-ui.js. Nothing here sends mail data anywhere: a task you make from a mail is an ordinary task
   (it syncs like every task), but the mail itself, its sender and its id stay on the computer. */

/* ---------- guessing a date in a text (Dutch and English) ---------- */
const MONTHS = { jan: 1, januari: 1, january: 1, feb: 2, februari: 2, february: 2, mrt: 3, mar: 3, maart: 3, march: 3, apr: 4, april: 4, mei: 5, may: 5, jun: 6, juni: 6, june: 6,
  jul: 7, juli: 7, july: 7, aug: 8, augustus: 8, august: 8, sep: 9, sept: 9, september: 9, okt: 10, oct: 10, oktober: 10, october: 10, nov: 11, november: 11, dec: 12, december: 12 };
const WDAYS = { zondag: 0, sunday: 0, maandag: 1, monday: 1, dinsdag: 2, tuesday: 2, woensdag: 3, wednesday: 3, donderdag: 4, thursday: 4, vrijdag: 5, friday: 5, zaterdag: 6, saturday: 6 };
const addDays = (ds, n) => { const d = new Date(ds + 'T00:00'); d.setDate(d.getDate() + n); return iso(d); };
// Returns 'YYYY-MM-DD' or ''. A written date wins over "tomorrow" or a weekday; the first one in the text wins.
// Without a year, a date more than 60 days in the past means next year (a mail from November about "5 januari").
function guessDate(text, base = new Date()) {
  const s = String(text || '').toLowerCase(), t0 = new Date(base.getFullYear(), base.getMonth(), base.getDate());
  const mk = (y, m, d) => { const x = new Date(y, m - 1, d); return x.getMonth() === m - 1 && x.getDate() === d ? x : null; };
  const fix = (m, d, y) => {
    if (y) { y = +y; if (y < 100) y += 2000; return y > 2000 && y < 2100 ? mk(y, m, d) : null; }
    let x = mk(t0.getFullYear(), m, d); if (x && x < new Date(t0.getTime() - 60 * 864e5)) x = mk(t0.getFullYear() + 1, m, d); return x;
  };
  let best = null, at = Infinity; const take = (x, i) => { if (x && i < at) { best = x; at = i; } };
  for (const r of s.matchAll(/\b(\d{1,2})(?:ste|de|e|st|nd|rd|th)?\s+(januari|februari|maart|april|mei|juni|juli|augustus|september|oktober|november|december|january|february|march|may|june|july|august|october|jan|feb|mrt|mar|apr|jun|jul|aug|sept|sep|okt|oct|nov|dec)\b\.?(?:\s+(\d{4}))?/g)) take(fix(MONTHS[r[2]], +r[1], r[3]), r.index);
  for (const r of s.matchAll(/\b(20\d\d)-(\d\d)-(\d\d)\b/g)) take(mk(+r[1], +r[2], +r[3]), r.index);
  for (const r of s.matchAll(/\b(\d{1,2})([/.-])(\d{1,2})(?:\2(\d{2,4}))?\b/g)) if (r[2] !== '.' || r[4]) take(fix(+r[3], +r[1], r[4]), r.index); // "14.30" is a time, not a date
  if (best) return iso(best);
  const rel = [[/\bovermorgen\b|\bday after tomorrow\b/, 2], [/\bmorgen\b|\btomorrow\b/, 1], [/\bvandaag\b|\btoday\b|\bvanavond\b|\btonight\b/, 0]];
  for (const [re, n] of rel) { const m = re.exec(s); if (m) take(new Date(t0.getFullYear(), t0.getMonth(), t0.getDate() + n), m.index); }
  for (const r of s.matchAll(/\b(maandag|dinsdag|woensdag|donderdag|vrijdag|zaterdag|zondag|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/g)) {
    take(new Date(t0.getFullYear(), t0.getMonth(), t0.getDate() + ((WDAYS[r[1]] - t0.getDay() + 7) % 7)), r.index);
  }
  return best ? iso(best) : '';
}

/* ---------- a task or deadline (also from a mail) ---------- */
const todoWidgets = () => Object.entries(state.widgets).filter(([, w]) => w.type === 'todo');
const tabOf = wid => state.tabs.find(t => t.widgets.includes(wid));
function taskModal(o) { // o: { kind: 'todo'|'dl', title, date, fromMail }
  const lists = todoWidgets(), kind = o.kind === 'dl' ? 'dl' : 'todo';
  openModal(`<h2>${kind === 'dl' ? '⏰ ' + T('New deadline') : '☑ ' + T('New task')}</h2>
    <form data-form="x.task"><input type="hidden" name="kind" value="${kind}">
    <h3>${T('What')}</h3><input name="title" value="${esc(o.title || '')}" required maxlength="200" style="width:100%" autocomplete="off">
    <h3>${T(kind === 'dl' ? 'Due on' : 'Due on (optional)')}</h3>${dateIn('date', o.date || '', kind === 'dl' ? { req: true } : { ph: 'Optional' })}
    ${o.date ? `<div class="sub">✨ ${T('Date found in the mail. Check it.')}</div>` : o.fromMail ? `<div class="sub">${T('No date found in the mail.')}</div>` : ''}
    ${kind === 'todo' ? (lists.length > 1 ? `<h3>${T('In which list?')}</h3><select name="list" style="width:100%">${lists.map(([id, w]) => `<option value="${id}">${esc(w.title || T('To-do'))} · ${esc(T(tabOf(id)?.name || ''))}</option>`).join('')}</select>`
      : lists.length ? `<input type="hidden" name="list" value="${lists[0][0]}">` : `<div class="sub" style="margin-top:8px">${T('You have no to-do list yet: one is added to your first tab.')}</div>`)
      + `<h3>${T('Priority')}</h3><select name="prio"><option value="2">${T('Normal priority')}</option><option value="1">${T('High priority')}</option><option value="3">${T('Low priority')}</option></select>` : ''}
    ${o.fromMail ? `<div class="sub" style="margin-top:10px">🔒 ${T('Only this text and date are saved (and synced to your phone like every task). The mail itself stays on this computer.')}</div>` : ''}
    <div class="mfoot"><button type="button" class="ghost" data-act="modal.close">${T('Cancel')}</button><button>${T('Add')}</button></div></form>`);
}
function addTask(title, due, prio = 2, list) { // returns the widget id
  let id = list && state.widgets[list]?.type === 'todo' ? list : todoWidgets()[0]?.[0];
  if (!id) { id = uid(); state.widgets[id] = mk('todo'); state.tabs[0].widgets.unshift(id); }
  state.widgets[id].data.items.push({ id: uid(), text: String(title).slice(0, 200), done: false, prio: [1, 2, 3].includes(+prio) ? +prio : 2, due: due || '' });
  return id;
}
function mailToTask(kind, acc, mid) {
  const m = MAIL.msgs.find(x => x.acc === acc && x.id === mid); if (!m) return;
  const s = AI.sums.get(acc + '|' + mid), d = MAIL.bodies.get(acc + '|' + mid)?.d;
  const kern = s?.s === 'done' && s.text && s.task !== 'suspect' ? s.text : '';
  const text = (d?.text || m.snippet || '').split('\n').filter(l => !/^\s*>/.test(l)).join('\n').slice(0, 4000);
  taskModal({ kind, title: (kern || m.subject || '').slice(0, 200), date: guessDate([kern, m.subject, text].join('\n'), new Date(m.date || Date.now())), fromMail: true });
}

/* ---------- jump to a widget (from search or a reminder) ---------- */
function goWidget(wid, before) {
  const t = tabOf(wid); if (!t) return;
  curTab = t.id; ls.set('dash-tab', curTab); before?.();
  if (!$('#modal').classList.contains('hidden')) closeModal(); else render();
  requestAnimationFrame(() => { const el = $(`[data-wid="${wid}"]`); if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1600); } });
}
const firstWidget = type => Object.keys(state.widgets).find(id => state.widgets[id].type === type && tabOf(id));

/* ---------- searching everything (Ctrl+K or 🔎) ---------- */
const fold = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const SK = { cmd: ['⚡', 'Actions'], tab: ['🗂', 'Tabs'], todo: ['☑', 'Tasks'], dl: ['⏰', 'Deadlines'], ev: ['📅', 'Calendar'], tt: ['🏫', 'Timetable'], note: ['📝', 'Notes'], mail: ['✉️', 'Mail'] };
let SRCH = null; // { q, sel, items }
function searchIndex() {
  const out = [], D = days(), t = todayStr();
  for (const tb of state.tabs) out.push({ k: 'tab', title: T(tb.name), sub: '', go: () => { curTab = tb.id; ls.set('dash-tab', curTab); closeModal(); } });
  for (const [id, w] of Object.entries(state.widgets)) {
    if (!tabOf(id)) continue;
    if (w.type === 'todo') w.data.items.forEach(x => out.push({ k: 'todo', title: x.text, sub: (x.done ? '✓ ' : '') + (x.due ? niceDay(x.due) : '') + ' · ' + (w.title || ''), done: x.done, go: () => goWidget(id) }));
    if (w.type === 'notes') notesOf(w).forEach(n => out.push({ k: 'note', title: noteTitle(n), sub: n.text.trim().split('\n').slice(1).join(' ').slice(0, 90), body: n.text, go: () => goWidget(id, () => { (view[id] ||= {}).note = n.id; }) }));
    if (w.type === 'timetable') (w.data.slots || []).forEach(s => out.push({ k: 'tt', title: s.title, sub: `${D[s.day]} ${s.start}${s.room ? ' · ' + s.room : ''}`, go: () => goWidget(id) }));
  }
  const dlw = firstWidget('deadlines') || firstWidget('calendar');
  state.deadlines.forEach(d => out.push({ k: 'dl', title: d.title, sub: niceDay(d.date), go: () => dlw && goWidget(dlw) }));
  const cw = firstWidget('calendar'), from = addDays(t, -30);
  allEvents().filter(e => e.date >= from).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 400).forEach(e => out.push({ k: 'ev', title: e.title || T('(no title)'), sub: niceDay(e.date) + (e.time ? ' ' + e.time : '') + (e.loc ? ' · ' + e.loc : ''),
    go: () => cw && goWidget(cw, () => { const v = view[cw] ||= {}; v.ym = e.date.slice(0, 7); v.sel = e.date; }) }));
  if (!APP && typeof MAIL !== 'undefined') {
    const mw = firstWidget('mail');
    MAIL.msgs.slice(0, 300).forEach(m => { const a = mailAcc(m.acc); if (a) out.push({ k: 'mail', title: m.subject || T('(no subject)'), sub: (m.from?.name || m.from?.address || '') + ' · ' + a.name, body: m.snippet, go: () => mw && goWidget(mw, () => setTimeout(() => mailOpen(mw, m.acc, m.id), 60)) }); });
  }
  return out;
}
function searchCommands(q) { // "taak: …", "notitie: …", "deadline: …" and a few fixed actions
  const out = [], m = /^\s*(taak|todo|task|notitie|note|deadline)\s*:\s*(.+)$/i.exec(q);
  if (m) {
    const kind = /^(notitie|note)$/i.test(m[1]) ? 'note' : /^deadline$/i.test(m[1]) ? 'dl' : 'todo', text = m[2].trim(), date = guessDate(text);
    if (kind === 'todo') out.push({ k: 'cmd', title: T('Add task: {0}', text), sub: date ? T('due {0}', niceDay(date)) : '', go: () => { const id = addTask(text, date); closeModal(); commit(); toast(T('Task added ✓')); goWidget(id); } });
    if (kind === 'note') out.push({ k: 'cmd', title: T('New note: {0}', text), sub: '', go: () => {
      let id = firstWidget('notes'); if (!id) { id = uid(); state.widgets[id] = mk('notes'); state.tabs[0].widgets.push(id); }
      const n = { id: uid(), text, t: Date.now() }; notesOf(state.widgets[id]).unshift(n); save(); goWidget(id, () => { (view[id] ||= {}).note = n.id; }); } });
    if (kind === 'dl') out.push({ k: 'cmd', title: T('New deadline: {0}', text), sub: date ? niceDay(date) : T('pick a date'), go: () => taskModal({ kind: 'dl', title: text, date }) });
    return out;
  }
  const fixed = [[T('New task'), () => taskModal({ kind: 'todo' })], [T('New deadline'), () => taskModal({ kind: 'dl' })], [T('Settings'), () => settingsModal()]];
  if (!APP) fixed.push([T('Reminders'), () => settingsModal('notify')]);
  if (!APP && typeof MAIL !== 'undefined' && MAIL.accounts.some(a => a.canSend)) fixed.splice(2, 0, [T('New mail'), () => { closeModal(); setTimeout(() => composeOpen({}), 0); }]);
  const f = fold(q); fixed.filter(([l]) => !f || fold(l).includes(f)).forEach(([l, go]) => out.push({ k: 'cmd', title: l, sub: '', go }));
  return out;
}
function searchRun(q) {
  const words = fold(q).split(/\s+/).filter(Boolean), cmds = searchCommands(q);
  let hits = [];
  if (words.length && !/^\s*\w+\s*:/.test(q)) {
    hits = searchIndex().map(x => { const tt = fold(x.title), all = tt + ' ' + fold(x.sub) + ' ' + fold(x.body); if (!words.every(w => all.includes(w))) return null;
      return { ...x, score: (tt.startsWith(words[0]) ? 0 : tt.includes(words[0]) ? 1 : 2) + (x.done ? 3 : 0) }; }).filter(Boolean)
      .sort((a, b) => a.score - b.score).slice(0, 40);
  }
  const order = Object.keys(SK); hits.sort((a, b) => order.indexOf(a.k) - order.indexOf(b.k) || a.score - b.score);
  return [...cmds.slice(0, words.length ? 3 : 8), ...hits];
}
function searchDraw() {
  const box = $('#ckres'); if (!box || !SRCH) return;
  let last = '', i = 0;
  box.innerHTML = SRCH.items.map(x => { const head = x.k !== last ? `<div class="ckh">${SK[x.k][0]} ${T(SK[x.k][1])}</div>` : ''; last = x.k;
    return head + `<button class="ckrow ${i === SRCH.sel ? 'on' : ''} ${x.done ? 'done' : ''}" data-act="ck.go" data-i="${i++}"><b>${esc(x.title)}</b>${x.sub ? `<small>${esc(x.sub)}</small>` : ''}</button>`; }).join('')
    || `<div class="empty">${T('Nothing found.')} <span class="sub">${T('Tip: type “taak: buy milk tomorrow” to add a task.')}</span></div>`;
  box.querySelector('.ckrow.on')?.scrollIntoView({ block: 'nearest' });
}
function searchOpen() {
  if (!state || !$('#modal').classList.contains('hidden')) return; // never over another window (an unsent mail would be lost)
  SRCH = { q: '', sel: 0, items: searchRun('') };
  openModal(`<div class="cmdk"><input id="ckq" data-inp="ck.q" placeholder="${T('Search everything, or type “taak: …”')}" autocomplete="off" spellcheck="false"><div id="ckres"></div>
    <div class="ckfoot sub">↑↓ ${T('choose')} · Enter ${T('open')} · Esc ${T('close')} · <b>taak:</b> · <b>notitie:</b> · <b>deadline:</b></div></div>`);
  searchDraw(); $('#ckq')?.focus();
}
const searchPick = i => { const x = SRCH?.items[i]; if (!x) return; SRCH = null; x.go(); };
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key.toLowerCase() === 'k') { e.preventDefault(); searchOpen(); return; }
  if (e.target?.id !== 'ckq' || !SRCH) return;
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const n = SRCH.items.length; if (n) { SRCH.sel = (SRCH.sel + (e.key === 'ArrowDown' ? 1 : n - 1)) % n; searchDraw(); } }
  else if (e.key === 'Enter') { e.preventDefault(); searchPick(SRCH.sel); }
});

/* ---------- reminders (Windows notifications, on the computer only) ---------- */
const NOTIFYDEF = { on: false, dl: true, task: true, ev: true, tt: true, mail: false, mins: 10, bg: true };
const notifyCfg = () => ({ ...NOTIFYDEF, ...(state?.settings?.notify || {}) });
// Every moment that has a reminder: deadlines (18:00 the day before and 08:00 on the day), tasks due today (08:00), events and lessons (N minutes before).
function reminderList(now = new Date()) {
  const n = notifyCfg(), out = [], day = iso(now), tom = addDays(day, 1), at = (ds, hm) => new Date(ds + 'T' + hm).getTime(), before = Math.max(0, +n.mins || 0) * 60e3;
  if (n.dl) for (const d of state.deadlines) if (d.date >= day && d.date <= tom) {
    out.push({ key: `dl1|${d.id}|${d.date}`, t: at(addDays(d.date, -1), '18:00'), title: '⏰ ' + T('Tomorrow') + ': ' + d.title, body: T('Deadline'), wid: firstWidget('deadlines') });
    out.push({ key: `dl0|${d.id}|${d.date}`, t: at(d.date, '08:00'), title: '⏰ ' + T('Today') + ': ' + d.title, body: T('Deadline'), wid: firstWidget('deadlines') });
  }
  if (n.task) for (const [id, w] of todoWidgets()) for (const x of w.data.items) if (!x.done && x.due === day) out.push({ key: `td|${x.id}|${x.due}`, t: at(x.due, '08:00'), title: '☑ ' + x.text, body: T('Task for today'), wid: id });
  if (n.ev) for (const e of allEvents()) if (e.time && (e.date === day || e.date === tom))
    out.push({ key: `ev|${e.id || e.title}|${e.date}|${e.time}`, t: at(e.date, e.time) - before, title: '📅 ' + (e.title || T('(no title)')), body: e.time + (e.end ? '–' + e.end : '') + (e.loc ? ' · ' + e.loc : ''), wid: firstWidget('calendar') });
  if (n.tt) for (const [id, w] of Object.entries(state.widgets)) if (w.type === 'timetable' && tabOf(id)) for (const s of w.data.slots || []) for (const ds of [day, tom]) if (dow(new Date(ds + 'T00:00')) === s.day)
    out.push({ key: `tt|${s.id}|${ds}`, t: at(ds, s.start) - before, title: '🏫 ' + s.title, body: s.start + (s.end ? '–' + s.end : '') + (s.room ? ' · ' + s.room : ''), wid: id });
  return out;
}
// What fires between two checks; anything more than 15 minutes late is skipped (so starting the app or waking the laptop does not flood you).
const remindersDue = (list, from, to) => list.filter(x => x.t > from && x.t <= to && to - x.t < 15 * 60e3);
const fired = (() => { let s; try { s = new Set(JSON.parse(localStorage.getItem('dash-fired') || '[]')); } catch { s = new Set(); }
  return { has: k => s.has(k), add: k => { s.add(k); const a = [...s].slice(-400); s = new Set(a); try { localStorage.setItem('dash-fired', JSON.stringify(a)); } catch {} } }; })();
function notify(title, body, wid, key) {
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return false;
  try {
    const n = new Notification(title, { body, tag: key, silent: false });
    n.onclick = () => { fetch('/api/app/show', { method: 'POST' }).catch(() => {}); window.focus(); if (wid && $('#modal').classList.contains('hidden')) goWidget(wid); };
    return true;
  } catch { return false; }
}
let remLast = Date.now() - 3 * 60e3, mailKnown = null, mailPoll = 0;
function reminderTick(nowMs = Date.now()) {
  if (APP || !state) return;
  const n = notifyCfg();
  if (n.on) for (const x of remindersDue(reminderList(new Date(nowMs)), remLast, nowMs)) if (!fired.has(x.key) && notify(x.title, x.body, x.wid, x.key)) fired.add(x.key);
  remLast = nowMs;
  if (n.on && n.mail && typeof MAIL !== 'undefined') { // new unread mail since the app started (only mailboxes shown in a Mail widget)
    if (nowMs - mailPoll > 2 * 60e3 && !MAIL.loading) { mailPoll = nowMs; mailLoad(false, true); }
    if (MAIL.loaded) {
      const unread = MAIL.msgs.filter(m => m.unread), keys = unread.map(m => m.acc + '|' + m.id);
      if (mailKnown) { const fresh = unread.filter(m => !mailKnown.has(m.acc + '|' + m.id));
        if (fresh.length) notify(fresh.length === 1 ? '✉️ ' + (fresh[0].from?.name || fresh[0].from?.address || T('New mail')) : '✉️ ' + T('{0} new mails', fresh.length),
          fresh.length === 1 ? fresh[0].subject || '' : fresh.slice(0, 3).map(m => m.from?.name || m.from?.address).join(', '), firstWidget('mail'), 'mail|' + keys.join(',').slice(0, 60)); }
      mailKnown = new Set([...(mailKnown || []), ...keys]);
    }
  }
}
setInterval(() => reminderTick(), 30e3);

function notifyHtml() {
  const n = notifyCfg(), ok = typeof Notification !== 'undefined', ck = (k, l) => `<label class="fl ntrow"><input type="checkbox" data-chg="nt.opt" data-k="${k}" ${n[k] ? 'checked' : ''} ${n.on ? '' : 'disabled'}> ${T(l)}</label>`;
  return `<div class="sub">${T('Reminders appear as a Windows notification. Only on this computer, and only while the app is running.')}</div>
    ${ok ? '' : `<div class="sub err">${T('Notifications are not available here.')}</div>`}
    <label class="fl ntrow" style="margin-top:10px"><input type="checkbox" data-chg="nt.opt" data-k="on" ${n.on ? 'checked' : ''}> <b>${T('Reminders on')}</b></label>
    <h3>${T('Remind me of')}</h3>
    ${ck('dl', 'Deadlines (the evening before at 18:00 and on the day at 08:00)')}${ck('task', 'Tasks due today (08:00)')}
    ${ck('ev', 'Calendar events')}${ck('tt', 'Lessons from your timetable')}${ck('mail', 'New mail (only mailboxes shown in Mail)')}
    <h3>${T('How long before an event or lesson?')}</h3>
    <select data-chg="nt.mins" ${n.on ? '' : 'disabled'}>${[5, 10, 15, 30, 60].map(m => `<option value="${m}" ${+n.mins === m ? 'selected' : ''}>${T('{0} minutes', m)}</option>`).join('')}</select>
    <h3>${T('When you close the window')}</h3>
    <label class="fl ntrow"><input type="checkbox" data-chg="nt.opt" data-k="bg" ${n.bg ? 'checked' : ''} ${n.on ? '' : 'disabled'}> ${T('Keep running in the system tray (bottom right), so reminders still come. Quit via the tray icon.')}</label>
    <div class="row" style="margin-top:12px"><button class="ghost small" data-act="nt.test" ${n.on ? '' : 'disabled'}>🔔 ${T('Send a test notification')}</button></div>
    <div class="sub" style="margin-top:10px">${T('The phone app does not show reminders yet.')}</div>`;
}
const notifySet = patch => { state.settings.notify = { ...notifyCfg(), ...patch }; save(); };

Object.assign(ACT, {
  'ui.search': () => searchOpen(),
  'ck.go': ({ d }) => searchPick(+d.i),
  'mail.totask': ({ d }) => mailToTask(d.k, d.acc, d.id),
  'nt.test': () => { if (!notify('🔔 ' + T('Reminders work'), T('This is how a reminder looks.'), null, 'test' + Date.now())) toast(T('Windows did not allow the notification. Check Settings → System → Notifications.')); },
});
Object.assign(INP, { 'ck.q': ({ el }) => { if (!SRCH) return; SRCH.q = el.value; SRCH.sel = 0; SRCH.items = searchRun(el.value); searchDraw(); } });
Object.assign(CHG, {
  'nt.opt': async ({ d, el }) => {
    if (d.k === 'on' && el.checked && typeof Notification !== 'undefined' && Notification.permission === 'default') await Notification.requestPermission().catch(() => {});
    notifySet({ [d.k]: el.checked }); if (d.k === 'on') { remLast = Date.now(); settingsModal('notify'); }
  },
  'nt.mins': ({ el }) => notifySet({ mins: +el.value }),
});
Object.assign(FORM, {
  'x.task': ({ v }) => {
    refocus = null; if (!v.title) return;
    if (v.kind === 'dl') { if (!v.date) return; state.deadlines.push({ id: uid(), title: v.title.slice(0, 200), date: v.date }); closeModal(); commit(); toast(T('Deadline added ✓')); }
    else { addTask(v.title, v.date, v.prio, v.list); closeModal(); commit(); toast(T('Task added ✓')); }
  },
});

Object.assign(NL, {
  'New deadline': 'Nieuwe deadline', 'New task': 'Nieuwe taak', 'What': 'Wat', 'Due on (optional)': 'Tegen (optioneel)', 'Date found in the mail. Check it.': 'Datum uit de mail gehaald. Controleer hem even.',
  'No date found in the mail.': 'Geen datum gevonden in de mail.', 'In which list?': 'In welke lijst?', 'Priority': 'Prioriteit', 'Add': 'Toevoegen',
  'You have no to-do list yet: one is added to your first tab.': 'Je hebt nog geen to-do-lijst: er komt er een op je eerste tabblad.',
  'Only this text and date are saved (and synced to your phone like every task). The mail itself stays on this computer.': 'Alleen deze tekst en datum worden bewaard (en net als elke taak naar je gsm gesynchroniseerd). De mail zelf blijft op deze computer.',
  'Task added ✓': 'Taak toegevoegd ✓', 'Deadline added ✓': 'Deadline toegevoegd ✓', 'Actions': 'Acties', 'Tabs': 'Tabbladen', 'Tasks': 'Taken', 'Deadlines': 'Deadlines', 'Calendar': 'Agenda', 'Timetable': 'Rooster', 'Notes': 'Notities',
  'Add task: {0}': 'Taak toevoegen: {0}', 'due {0}': 'tegen {0}', 'New note: {0}': 'Nieuwe notitie: {0}', 'New deadline: {0}': 'Nieuwe deadline: {0}', 'pick a date': 'kies een datum',
  'Reminders': 'Meldingen', 'Nothing found.': 'Niets gevonden.', 'Tip: type “taak: buy milk tomorrow” to add a task.': 'Tip: typ “taak: melk kopen morgen” om een taak toe te voegen.',
  'Search everything, or type “taak: …”': 'Zoek in alles, of typ “taak: …”', 'choose': 'kiezen', 'open': 'openen', 'close': 'sluiten', 'Deadline': 'Deadline', 'Task for today': 'Taak voor vandaag',
  '{0} new mails': '{0} nieuwe mails', 'Reminders appear as a Windows notification. Only on this computer, and only while the app is running.': 'Meldingen verschijnen als Windows-melding. Alleen op deze computer, en alleen terwijl de app draait.',
  'Notifications are not available here.': 'Meldingen zijn hier niet beschikbaar.', 'Reminders on': 'Meldingen aan', 'Remind me of': 'Herinner me aan',
  'Deadlines (the evening before at 18:00 and on the day at 08:00)': 'Deadlines (de avond ervoor om 18:00 en op de dag zelf om 08:00)', 'Tasks due today (08:00)': 'Taken voor vandaag (08:00)',
  'Calendar events': 'Afspraken in je agenda', 'Lessons from your timetable': 'Lessen uit je rooster', 'New mail (only mailboxes shown in Mail)': 'Nieuwe mail (alleen postvakken die in Mail getoond worden)',
  'How long before an event or lesson?': 'Hoe lang voor een afspraak of les?', '{0} minutes': '{0} minuten', 'When you close the window': 'Als je het venster sluit',
  'Keep running in the system tray (bottom right), so reminders still come. Quit via the tray icon.': 'Blijf draaien in het systeemvak (rechtsonder), zodat meldingen nog komen. Afsluiten via dat pictogram.',
  'Send a test notification': 'Testmelding sturen', 'The phone app does not show reminders yet.': 'De gsm-app toont nog geen meldingen.', 'Reminders work': 'Meldingen werken',
  'This is how a reminder looks.': 'Zo ziet een melding eruit.', 'Windows did not allow the notification. Check Settings → System → Notifications.': 'Windows liet de melding niet toe. Kijk bij Instellingen → Systeem → Meldingen.',
  'OK': 'OK', 'Delete': 'Verwijderen', 'Disconnect': 'Ontkoppelen', 'Sign out': 'Afmelden', 'Stop syncing': 'Stoppen met synchroniseren', 'Download': 'Downloaden', 'Restart': 'Herstarten',
  'Open': 'Openen', 'Throw away': 'Weggooien', 'Keep writing': 'Verder schrijven', 'Replace': 'Vervangen', 'Reply anyway': 'Toch antwoorden', 'Save anyway': 'Toch opslaan', 'Continue': 'Doorgaan',
  'Search (Ctrl+K)': 'Zoeken (Ctrl+K)', 'Task': 'Taak', 'Search, reminders and more': 'Zoeken, meldingen en meer',
});
