'use strict';
/* ================= Mail (on the computer only) =================
   One list for all your mailboxes. The account list, passwords and messages stay on the computer (see mail.js); only the layout choices of a
   Mail widget (w.data: layout, density, hidden mailbox ids, ...) are part of the synced dashboard data. */
const MAILDEF = { layout: 'split', density: 'cozy', font: 'm', preview: true, avatars: true, group: true, count: 50, sort: 'new', unreadOnly: false, markRead: false, hidden: [] };
const mailOpts = w => ({ ...MAILDEF, ...(w?.data || {}) });
const MAIL = { accounts: [], status: {}, msgs: [], gmailReady: false, loaded: false, loading: false, err: '', t: 0, bodies: new Map() };
// AI (summaries from a model on this computer): short summaries per mail, kept in memory only
const AI = { sums: new Map(), warm: false, setup: '' }; // sums: "acc|id" -> { s: 'loading'|'done'|'err', text, task, err }
const aiCfg = () => ({ on: false, model: 'gemma3:4b', gpu: true, auto: true, ...(state?.settings?.ai || {}) });
const aiOn = () => !APP && !!aiCfg().on;
const TASKS = { action: ['🔶', 'Needs action'], suspect: ['⚠️', 'Suspicious'], info: ['ℹ️', 'Information'] };
const mailAcc = id => MAIL.accounts.find(a => a.id === id);
const MAIL_ERR = {
  auth: 'Sign-in refused. Check the address and use an app password, not your normal password.', host: 'This server does not exist. Check the server name.',
  connect: 'Cannot reach the mail server. Check your internet connection or the server and port.', tls: 'The secure connection to the server is not right, so the app does not trust it.',
  login: 'This mailbox needs you to sign in again.', readonly: 'This mailbox is set to read only.', noarchive: 'This mailbox has no Archive folder.', notrash: 'This mailbox has no Trash folder, so nothing was deleted.',
  big: 'This mail is too large to show here. Open it in your mail app.', gone: 'This mail no longer exists.', api_disabled: 'The Gmail API is switched off in your Google project. Enable it, then try again.',
  forbidden: 'Google did not allow this. Sign in again for this mailbox.', busy: 'The mail server is busy. Try again in a minute.', timeout: 'The mail server took too long to answer.',
  config: 'Set up the Google connection first: Settings → Calendars → Google.', bad: 'Fill in all fields.', fail: 'Something went wrong. Try again.',
  header: 'A subject or address cannot contain a line break.', address: 'One of the addresses is not a valid e-mail address.', noto: 'Fill in who the mail is for.',
  toomany: 'Too many recipients (at most 50).', empty: 'The mail is empty.', rate: 'You sent a lot of mail in a short time. Wait a few minutes.', smtpport: 'Use port 465 or 587 (secure connections only).',
  nosmtp: 'Sending is not set up for this mailbox yet: Change mailbox → Sending.',
};
const mailErr = c => T(MAIL_ERR[c] || MAIL_ERR.fail);
const PROVIDERS_MAIL = {
  gmail: { name: 'Gmail', icon: '📧', desc: 'Recommended: sign in with Google, no password needed' },
  icloud: { name: 'iCloud Mail', icon: '☁️', desc: 'iPhone / Apple mail, with an app-specific password', host: 'imap.mail.me.com', help: 'https://support.apple.com/nl-nl/102654' },
  yahoo: { name: 'Yahoo Mail', icon: '🟣', desc: 'With an app password', host: 'imap.mail.yahoo.com', help: 'https://help.yahoo.com/kb/SLN15241.html',
    note: 'Don’t see “Create app password” in Yahoo’s account security? Turn on two-step verification there first (it needs a phone number); the option appears afterwards. Make sure your account has a password.' },
  other: { name: 'Other (IMAP)', icon: '✉️', desc: 'GMX, school, work, your own domain…', host: '' },
  gmailimap: { name: 'Gmail with an app password', icon: '🔑', desc: 'Only if signing in with Google does not work', host: 'imap.gmail.com', help: 'https://myaccount.google.com/apppasswords' },
  outlook: { name: 'Outlook / Hotmail', icon: '🚫', desc: 'Not available (see why)' },
};

/* ---------- loading ---------- */
const mailWidgetsHere = () => (state && !APP) ? tab().widgets.filter(id => state.widgets[id]?.type === 'mail') : [];
async function mailLoad(force) {
  if (APP || MAIL.loading) return;
  MAIL.loading = true; mailRedraw();
  try {
    const a = await (await fetch('/api/mail/accounts', { cache: 'no-store' })).json();
    MAIL.accounts = a.accounts || []; MAIL.gmailReady = !!a.gmailReady;
    const ws = Object.values(state?.widgets || {}).filter(w => w.type === 'mail').map(mailOpts);
    const limit = Math.max(25, ...ws.map(o => +o.count || 50));
    // only fetch mailboxes that are visible in at least one Mail widget
    const ids = MAIL.accounts.filter(x => !ws.length || ws.some(o => !o.hidden.includes(x.id))).map(x => x.id);
    if (ids.length) {
      const r = await (await fetch(`/api/mail/messages?limit=${limit}&ids=${ids.join(',')}${force ? '&refresh=1' : ''}`, { cache: 'no-store' })).json();
      MAIL.status = Object.fromEntries((r.accounts || []).map(x => [x.id, x])); MAIL.msgs = r.messages || [];
    } else { MAIL.status = {}; MAIL.msgs = []; }
    MAIL.err = ''; MAIL.loaded = true; MAIL.t = Date.now();
    if (aiOn() && !AI.warm) { AI.warm = true; fetch('/api/mail/ai/warm', { method: 'POST' }).catch(() => {}); } // load the model in the background
  } catch { MAIL.err = 'offline'; MAIL.loaded = true; }
  MAIL.loading = false; mailRedraw();
}
function mailRedraw() { // only the Mail widgets, keeping their scroll positions
  for (const id of mailWidgetsHere()) {
    const el = $(`[data-wid="${id}"] .wb`); if (!el) continue;
    const keep = ['.mrows', '.mread', '.mside'].map(s => [s, el.querySelector(s)?.scrollTop || 0]);
    const f = document.activeElement, focusQ = f?.dataset?.inp === 'mail.q' && el.contains(f), pos = focusQ ? f.selectionStart : 0;
    el.innerHTML = mailRender(state.widgets[id], id);
    keep.forEach(([s, t]) => { const x = el.querySelector(s); if (x) x.scrollTop = t; });
    if (focusQ) { const i = el.querySelector('[data-inp="mail.q"]'); if (i) { i.focus(); i.setSelectionRange(pos, pos); } }
  }
  const mm = $('#sheet .mail-modal'); // a reading pane or overview open in a window
  if (mm && state?.widgets[mm.dataset.wid]) { const id = mm.dataset.wid, pane = mm.querySelector('.mread'); if (pane) { const top = pane.scrollTop; pane.innerHTML = mailPane(view[id]?.sel, mailOpts(state.widgets[id]), id); pane.scrollTop = top; } }
}
setInterval(() => { if (!document.hidden && mailWidgetsHere().length) mailLoad(); }, 2 * 60e3);
document.addEventListener('visibilitychange', () => { if (!document.hidden && mailWidgetsHere().length && Date.now() - MAIL.t > 60e3) mailLoad(); });

/* ---------- helpers ---------- */
const initials = m => { const s = (m.from?.name || m.from?.address || '?').replace(/["']/g, '').trim(); const p = s.split(/[\s.@_-]+/).filter(Boolean); return ((p[0]?.[0] || '?') + (p.length > 1 && !/@/.test(s.split(' ')[0]) ? p[1][0] : '')).toUpperCase(); };
const sender = m => m.from?.name || m.from?.address || T('(unknown sender)');
function mailWhen(ts, full) {
  if (!ts) return '';
  const d = new Date(ts), today = dayDiff(iso(d)) === 0;
  if (full) return d.toLocaleString(loc(), { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  if (today) return d.toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' });
  return d.getFullYear() === new Date().getFullYear() ? d.toLocaleDateString(loc(), { day: 'numeric', month: 'short' }) : d.toLocaleDateString(loc(), { day: '2-digit', month: '2-digit', year: 'numeric' });
}
function mailDay(ts) { const s = iso(new Date(ts)), n = dayDiff(s); return n === 0 ? T('Today') : n === -1 ? T('Yesterday') : new Date(ts).toLocaleDateString(loc(), { weekday: 'long', day: 'numeric', month: 'long' }); }
const size = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' kB';
// Mail text: escaped, links shown as their real address and only opened after you confirm.
function mailText(t) {
  const out = []; let last = 0; const re = /https?:\/\/[^\s<>"'()]+[^\s<>"'().,;:!?]/g; let m;
  while ((m = re.exec(t))) { out.push(esc(t.slice(last, m.index))); out.push(`<button class="mlink" data-act="mail.link" data-u="${esc(m[0])}" title="${esc(m[0])}">${esc(m[0])}</button>`); last = m.index + m[0].length; }
  out.push(esc(t.slice(last))); return out.join('');
}

/* ---------- the widget ---------- */
function mailRender(w, id) {
  if (APP) return `<div class="mempty"><b>📱</b>${T('Mail is only on your computer, so your mailboxes and passwords never leave it.')}</div>`;
  const o = mailOpts(w), v = view[id] ||= {}, hidden = new Set(o.hidden);
  if (!MAIL.loaded) { if (!MAIL.loading) setTimeout(() => mailLoad(), 0); return `<div class="mempty"><span class="spin"></span>${T('Loading your mail…')}</div>`; }
  if (!MAIL.accounts.length) return `<div class="mempty"><b>✉️</b><div>${T('Link your mailboxes and read all your mail in one place.')}</div><div class="sub">${T('As many as you like: Gmail, iCloud, Yahoo, school or work.')}</div><button data-act="mail.add">＋ ${T('Link a mailbox')}</button></div>`;
  const nHidden = MAIL.accounts.filter(a => hidden.has(a.id)).length;
  let list = MAIL.msgs.filter(m => !hidden.has(m.acc) && mailAcc(m.acc));
  const unreadOnly = v.unreadOnly ?? o.unreadOnly; if (unreadOnly) list = list.filter(m => m.unread);
  const q = (v.q || '').trim().toLowerCase();
  if (q) list = list.filter(m => (m.subject + ' ' + sender(m) + ' ' + (m.from?.address || '') + ' ' + m.snippet).toLowerCase().includes(q));
  if (o.sort === 'old') list = [...list].reverse();
  const sel = v.sel && MAIL.msgs.find(m => m.acc === v.sel.acc && m.id === v.sel.id) ? v.sel : null;

  const side = `<aside class="mside">
    <div class="mshead"><b>${T('Mailboxes')}</b><button class="mswitch ${nHidden ? '' : 'on'}" data-act="mail.allvis" role="switch" aria-checked="${!nHidden}" title="${T(nHidden ? 'Show all mailboxes' : 'Hide all mailboxes')}"><i></i></button></div>
    ${MAIL.accounts.map(a => { const st = MAIL.status[a.id], off = hidden.has(a.id);
      return `<div class="mbox ${off ? 'off' : ''}" style="--c:${esc(a.color)}">
        <button class="mswitch ${off ? '' : 'on'}" data-act="mail.vis" data-acc="${a.id}" role="switch" aria-checked="${!off}" title="${T(off ? 'Show this mailbox' : 'Hide this mailbox')}"><i></i></button>
        <span class="mbname" title="${esc(a.email)}"><b><i class="mdot"></i>${esc(a.name)}</b>${a.name !== a.email ? `<small>${esc(a.email)}</small>` : ''}<small class="mmode">${a.mode === 'write' ? '✎ ' + T('read & write') : '🔒 ' + T('read only')}</small>
        ${st && !st.ok && !off ? `<small class="err">⚠ ${mailErr(st.error)}</small>` : ''}${a.needsLogin ? `<small class="err">⚠ ${mailErr('login')}</small>` : ''}</span>
        ${!off && st?.ok && st.unread ? `<span class="mcount">${st.unread > 999 ? '999+' : st.unread}</span>` : ''}</div>`; }).join('')}
    <div class="msfoot"><button class="ghost small" data-act="mail.add">＋ ${T('Link a mailbox')}</button><button class="ghost small" data-act="mail.look">⚙ ${T('Layout')}</button></div></aside>`;

  let rows = '', lastDay = '';
  for (const m of list) {
    const a = mailAcc(m.acc), day = o.group ? mailDay(m.date) : '';
    if (o.group && day !== lastDay) { rows += `<div class="mday">${esc(day)}</div>`; lastDay = day; }
    const isSel = sel && sel.acc === m.acc && sel.id === m.id;
    rows += `<div class="mrow ${m.unread ? 'unread' : ''} ${isSel ? 'sel' : ''}" data-act="mail.open" data-acc="${m.acc}" data-id="${esc(m.id)}" style="--c:${esc(a.color)}" title="${esc(a.name)}">
      <i class="mbar"></i>${o.avatars ? `<span class="mav">${esc(initials(m))}</span>` : ''}
      <span class="mfrom">${esc(sender(m))}</span>
      <span class="msub"><b>${esc(m.subject || T('(no subject)'))}</b>${o.preview && m.snippet ? `<span class="msn">${esc(m.snippet)}</span>` : ''}</span>
      <span class="mmeta">${aiTag(m)}${m.flagged ? '<span title="★">★</span>' : ''}${m.att ? '📎' : ''}<time>${esc(mailWhen(m.date))}</time></span></div>`;
  }
  const shownAccs = MAIL.accounts.filter(a => !hidden.has(a.id));
  const empty = !shownAccs.length ? `<div class="mempty small"><b>🙈</b>${T('All mailboxes are hidden.')}<button class="ghost small" data-act="mail.allvis">${T('Show all mailboxes')}</button></div>`
    : `<div class="mempty small">${T(q ? 'No mail matches your search.' : unreadOnly ? 'No unread mail. 🎉' : 'No mail.')}</div>`;
  const listCol = `<section class="mlist">
    <div class="mtool"><input data-inp="mail.q" value="${esc(v.q || '')}" placeholder="🔎 ${T('Search mail')}" autocomplete="off" spellcheck="false">
      <div class="chips">${[['all', 'All'], ['unread', 'Unread']].map(([k, l]) => `<button class="${(k === 'unread') === !!unreadOnly ? 'on' : ''}" data-act="mail.filter" data-v="${k}">${T(l)}</button>`).join('')}</div>
      ${aiOn() ? `<button class="small mai ${v.ov ? 'on' : ''}" data-act="mail.ov" title="${T('Summarise your mail of today or the mail you missed')}">✨ ${T('Overview')}</button>`
        : `<button class="ghost small mai" data-act="mail.aihelp" title="${T('Turn on AI summaries')}">✨</button>`}
      ${MAIL.accounts.some(a => a.canSend) ? `<button class="small" data-act="mail.new" title="${T('Write a new mail')}">✎ ${T('New')}</button>` : ''}
      <button class="ghost small mref ${MAIL.loading ? 'busy' : ''}" data-act="mail.refresh" title="${T('Refresh now')}">↻</button></div>
    <div class="mnote">${nHidden ? `<span>🙈 ${T(nHidden === 1 ? '1 mailbox hidden' : '{0} mailboxes hidden', nHidden)} · <button class="linkbtn" data-act="mail.allvis">${T('show all')}</button></span>` : `<span>${T(shownAccs.length === 1 ? '1 mailbox' : '{0} mailboxes', shownAccs.length)}</span>`}${MAIL.t ? `<span>${T('Updated {0}', new Date(MAIL.t).toLocaleTimeString(loc(), { hour: '2-digit', minute: '2-digit' }))}</span>` : ''}${MAIL.err ? `<span class="err">${T('No connection right now.')}</span>` : ''}</div>
    <div class="mrows">${rows || empty}</div></section>`;
  const pane = o.layout === 'list' ? '' : `<section class="mread">${mailPane(sel, o, id)}</section>`;
  return `<div class="mail lay-${o.layout} den-${o.density} fs-${o.font} ${o.avatars ? '' : 'noav'}">${side}${listCol}${pane}</div>`;
}
function aiTag(m) { const s = AI.sums.get(m.acc + '|' + m.id); return s?.s === 'done' && TASKS[s.task] && s.task !== 'info' ? `<span class="mtask t-${s.task}" title="${T(TASKS[s.task][1])}">${TASKS[s.task][0]}</span>` : ''; }
function aiBox(acc, mid) { // the summary above the mail text
  if (!aiOn()) return '';
  const s = AI.sums.get(acc + '|' + mid);
  if (!s) return aiCfg().auto ? '' : `<div class="aibox"><button class="ghost small" data-act="mail.sum" data-acc="${acc}" data-id="${esc(mid)}">✨ ${T('Summarise this mail')}</button></div>`;
  if (s.s === 'err') return `<div class="aibox err">✨ ${T(AI_ERR[s.err] || AI_ERR.fail)}${['noollama', 'nomodel', 'off', 'start'].includes(s.err) ? ` <button class="linkbtn" data-act="mail.aihelp">${T('Set up AI')}</button>` : ` <button class="linkbtn" data-act="mail.sum" data-acc="${acc}" data-id="${esc(mid)}">${T('Try again')}</button>`}</div>`;
  const t = TASKS[s.task] || TASKS.info;
  return `<div class="aibox ${s.s === 'done' ? 't-' + s.task : ''}"><span class="aihead">✨ ${T('Summary')}${s.s === 'done' ? ` <span class="aichip t-${s.task}">${t[0]} ${T(t[1])}</span>` : ''}</span>
    <div class="aitext">${s.s === 'loading' && !s.text ? `<span class="spin"></span> ${T('Reading the mail…')}` : esc(s.text)}${s.s === 'loading' && s.text ? '<span class="aicaret"></span>' : ''}</div>
    <small class="sub">${T('Made by an AI on your computer. It can be wrong: check the mail itself before you act.')}</small></div>`;
}
const AI_ERR = {
  off: 'AI summaries are switched off.', noollama: 'Ollama (the program that runs the AI) is not installed on this computer.', nomodel: 'The AI model is not downloaded yet.', start: 'The AI could not be started.',
  bad: 'This mail cannot be summarised.', gone: 'This mail no longer exists.', fail: 'The summary did not work. Try again.', login: 'This mailbox needs you to sign in again.',
};
async function aiSummarize(acc, mid) {
  const key = acc + '|' + mid, cur = AI.sums.get(key); if (cur && cur.s !== 'err') return;
  AI.sums.set(key, { s: 'loading', text: '' }); mailRedraw();
  let raf = 0; const upd = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; mailRedraw(); }); };
  try {
    const r = await fetch('/api/mail/ai/summary', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ acc, id: mid }) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); AI.sums.set(key, { s: 'err', err: j.error || 'fail' }); return mailRedraw(); }
    await aiStream(r, ev => {
      if (ev.t === 'tok') { AI.sums.get(key).text = ev.v; upd(); }
      else if (ev.t === 'done') { AI.sums.set(key, { s: 'done', text: ev.kern, task: ev.task }); mailRedraw(); }
      else if (ev.t === 'err') { AI.sums.set(key, { s: 'err', err: ev.c }); mailRedraw(); }
    });
    if (AI.sums.get(key)?.s === 'loading') AI.sums.set(key, { s: 'err', err: 'fail' }), mailRedraw();
  } catch { AI.sums.set(key, { s: 'err', err: 'fail' }); mailRedraw(); }
}
async function aiStream(r, on) { // the server answers with one JSON object per line
  const dec = new TextDecoder(); let buf = '';
  for await (const chunk of r.body) { buf += dec.decode(chunk, { stream: true }); let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); if (line.trim()) { try { on(JSON.parse(line)); } catch {} } } }
}
/* the overview of a day: every mail gets a short summary, then they are grouped into "to do", "suspicious" and "information" */
const OV_RANGES = [['today', 'Today'], ['missed', 'Missed'], ['unread', 'All unread']];
function ovItems(id, range) {
  const hidden = new Set(mailOpts(state.widgets[id]).hidden), today = todayStr(), seen = MAIL.msgs.filter(m => !hidden.has(m.acc) && mailAcc(m.acc));
  const pick = range === 'today' ? seen.filter(m => iso(new Date(m.date)) === today) : range === 'missed' ? seen.filter(m => m.unread && iso(new Date(m.date)) < today && dayDiff(iso(new Date(m.date))) >= -7) : seen.filter(m => m.unread);
  return pick.slice(0, 25);
}
function overviewHtml(id) {
  const v = view[id], ov = v.ov, items = ov.items || [];
  const chips = `<div class="chips">${OV_RANGES.map(([k, l]) => `<button class="${ov.range === k ? 'on' : ''}" data-act="mail.ovrange" data-v="${k}">${T(l)}</button>`).join('')}<button class="ghost small" data-act="mail.ovclose" style="margin-left:auto">✕ ${T('Close')}</button></div>`;
  const row = i => { const m = MAIL.msgs.find(x => x.acc === i.acc && x.id === i.id), a = mailAcc(i.acc); if (!m || !a) return '';
    return `<button class="ovrow t-${i.task}" data-act="mail.ovopen" data-acc="${i.acc}" data-id="${esc(i.id)}" style="--c:${esc(a.color)}"><i class="mbar"></i><span class="ovtxt"><span class="ovtop"><b>${esc(sender(m))}</b><small>${esc(mailWhen(m.date))}</small></span><span class="ovsubj">${esc(m.subject || T('(no subject)'))}</span><span class="ovkern">${esc(i.kern || '')}</span></span></button>`; };
  let body;
  if (ov.s === 'idle') body = `<div class="mempty small"><b>✨</b>${T('Choose a period. The AI reads those mails here on your computer and sorts them.')}</div>`;
  else if (ov.s === 'err') body = `<div class="aibox err">✨ ${T(AI_ERR[ov.err] || AI_ERR.fail)} <button class="linkbtn" data-act="mail.aihelp">${T('Set up AI')}</button></div>`;
  else if (!items.length && ov.s === 'done') body = `<div class="mempty small"><b>🎉</b>${T('No mail in this period.')}</div>`;
  else {
    const done = ov.res || [], todo = done.filter(i => i.task === 'action'), sus = done.filter(i => i.task === 'suspect'), info = done.filter(i => i.task === 'info' || i.failed);
    body = `${ov.s === 'loading' ? `<div class="ovprog"><div><i style="width:${Math.round((done.length / Math.max(1, ov.total || 1)) * 100)}%"></i></div><small>${T('Reading mail {0} of {1}…', done.length, ov.total || items.length)}</small></div>` : `<div class="ovsum">${T('{0} mails: {1} to do, {2} suspicious, {3} information.', done.length, todo.length, sus.length, info.length)}</div>`}
      ${todo.length ? `<h4>🔶 ${T('To do')} (${todo.length})</h4>${todo.map(row).join('')}` : ''}
      ${sus.length ? `<h4>⚠️ ${T('Suspicious')} (${sus.length})</h4>${sus.map(row).join('')}` : ''}
      ${info.length ? `<details ${!todo.length && !sus.length ? 'open' : ''}><summary>ℹ️ ${T('Information')} (${info.length})</summary>${info.map(row).join('')}</details>` : ''}
      <small class="sub" style="display:block;margin-top:10px">${T('Made by an AI on your computer. It can be wrong: check the mail itself before you act.')}</small>`;
  }
  return `<div class="mhead"><h3>✨ ${T('Overview')}</h3>${chips}</div><div class="ovbody">${body}</div>`;
}
async function aiOverview(id, range) {
  const v = view[id]; const items = ovItems(id, range);
  v.ov = { range, s: items.length ? 'loading' : 'done', items, total: items.length, res: [] }; mailRedraw();
  if (!items.length) return;
  let raf = 0; const upd = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; mailRedraw(); }); };
  try {
    const r = await fetch('/api/mail/ai/overview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: items.map(m => ({ acc: m.acc, id: m.id })) }) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); v.ov = { ...v.ov, s: 'err', err: j.error || 'fail' }; return mailRedraw(); }
    const mine = v.ov;
    await aiStream(r, ev => {
      if (v.ov !== mine) return; // the person picked another period meanwhile
      if (ev.t === 'prog') { mine.res.push(ev.item); if (ev.item.kern) AI.sums.set(ev.item.acc + '|' + ev.item.id, { s: 'done', text: ev.item.kern, task: ev.item.task }); upd(); }
      else if (ev.t === 'done') { mine.s = 'done'; mailRedraw(); }
      else if (ev.t === 'err') { mine.s = 'err'; mine.err = ev.c; mailRedraw(); }
    });
    if (v.ov === mine && mine.s === 'loading') { mine.s = 'done'; mailRedraw(); }
  } catch { v.ov = { ...v.ov, s: 'err', err: 'fail' }; mailRedraw(); }
}
function mailPane(sel, o, id) {
  if (id && view[id]?.ov) return overviewHtml(id);
  if (!sel) return `<div class="mempty small"><b>📨</b>${T('Choose a mail to read it here.')}</div>`;
  const m = MAIL.msgs.find(x => x.acc === sel.acc && x.id === sel.id), a = mailAcc(sel.acc), st = MAIL.status[sel.acc] || {}, b = MAIL.bodies.get(sel.acc + '|' + sel.id);
  if (!m || !a) return '';
  const write = a.mode === 'write';
  const reply = write && a.canSend ? `<button class="small" data-act="mail.reply" data-acc="${a.id}" data-id="${esc(m.id)}">↩ ${T('Reply')}</button><button class="ghost small" data-act="mail.reply" data-all="1" data-acc="${a.id}" data-id="${esc(m.id)}">↩↩ ${T('Reply all')}</button>`
    : write ? `<button class="ghost small" data-act="mail.edit" data-acc="${a.id}">✉️ ${T('Set up sending')}</button>` : '';
  const acts = write ? `<div class="macts">${reply}
      <button class="ghost small" data-act="mail.do" data-v="${m.unread ? 'read' : 'unread'}">${m.unread ? '✓ ' + T('Mark as read') : '● ' + T('Mark as unread')}</button>
      ${st.canArchive !== false ? `<button class="ghost small" data-act="mail.do" data-v="archive">🗄 ${T('Archive')}</button>` : ''}
      ${st.canTrash !== false ? `<button class="ghost small" data-act="mail.do" data-v="trash">🗑 ${T('To Trash')}</button>` : ''}</div>`
    : `<div class="macts"><span class="mro">🔒 ${T('Read only: nothing changes in this mailbox.')} <button class="linkbtn" data-act="mail.edit" data-acc="${a.id}">${T('To reply from the app, set it to read & write.')}</button></span></div>`;
  const d = b?.d;
  const to = d ? [...d.to, ...d.cc].map(x => x.name || x.address).filter(Boolean).slice(0, 6).join(', ') : '';
  return `<div class="mhead"><h3>${esc(m.subject || T('(no subject)'))}</h3>
    <div class="mfromline"><span class="mav big" style="--c:${esc(a.color)}">${esc(initials(m))}</span>
      <div><b>${esc(sender(m))}</b> <span class="sub">${esc(m.from?.address ? '<' + m.from.address + '>' : '')}</span><br>
      <small class="sub">${to ? T('To') + ': ' + esc(to) + ' · ' : ''}${esc(mailWhen(m.date, true))}</small></div>
      <span class="mchip" style="--c:${esc(a.color)}"><i class="mdot"></i>${esc(a.name)}</span></div>${acts}</div>
    ${aiBox(sel.acc, sel.id)}
    ${d?.attachments?.length ? `<div class="matt">${d.attachments.map(x => `<span class="tag">📎 ${esc(x.name)} · ${size(x.size)}</span>`).join('')}<small class="sub">${T('Attachments are only listed here. Open the mail in your mail app to save them.')}</small></div>` : ''}
    <div class="mtext">${!b || b.s === 'loading' ? `<span class="spin"></span> ${T('Loading…')}` : b.s === 'err' ? `<span class="err">${mailErr(b.err)}</span>` : mailText(d.text || T('(This mail has no text.)'))}</div>`;
}
async function mailOpen(id, acc, mid) {
  const v = view[id] ||= {}; v.sel = { acc, id: mid };
  const key = acc + '|' + mid, o = mailOpts(state.widgets[id]);
  if (!MAIL.bodies.has(key) || MAIL.bodies.get(key).s === 'err') {
    MAIL.bodies.set(key, { s: 'loading' }); mailRedraw();
    try {
      const r = await fetch(`/api/mail/message?acc=${encodeURIComponent(acc)}&id=${encodeURIComponent(mid)}`); const j = await r.json();
      MAIL.bodies.set(key, r.ok ? { s: 'ok', d: j } : { s: 'err', err: j.error });
      if (MAIL.bodies.size > 40) MAIL.bodies.delete(MAIL.bodies.keys().next().value); // keep only recent mails in memory
    } catch { MAIL.bodies.set(key, { s: 'err', err: 'fail' }); }
  }
  const m = MAIL.msgs.find(x => x.acc === acc && x.id === mid);
  if (o.markRead && m?.unread && mailAcc(acc)?.mode === 'write') return mailDo(id, 'read');
  if (aiOn() && aiCfg().auto) aiSummarize(acc, mid);
  if (o.layout === 'list' || $(`[data-wid="${id}"] .mread`)?.offsetParent === null) mailModal(id); else mailRedraw();
}
function mailModal(id) { // the reading pane as a window (layout "list only", or a narrow widget)
  const v = view[id], sel = v?.sel; if (!sel && !v?.ov) return;
  openModal(`<div class="mail mail-modal" data-wid="${id}"><section class="mread">${mailPane(sel, mailOpts(state.widgets[id]), id)}</section></div>
    <div class="mfoot"><span></span><button data-act="modal.close">${T('Close')}</button></div>`);
  $('#sheet').classList.add('wide');
}
async function mailDo(id, what) {
  const sel = view[id]?.sel; if (!sel) return;
  if (what === 'trash' && !confirm(T('Move this mail to the Trash? You can still get it back from there.'))) return;
  const m = MAIL.msgs.find(x => x.acc === sel.acc && x.id === sel.id);
  const r = await fetch('/api/mail/action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ acc: sel.acc, ids: [sel.id], action: what }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) return toast(mailErr(j.error));
  if (what === 'read' || what === 'unread') { if (m) m.unread = what === 'unread'; const st = MAIL.status[sel.acc]; if (st && typeof st.unread === 'number') st.unread += what === 'unread' ? 1 : -1; }
  else { MAIL.msgs = MAIL.msgs.filter(x => x !== m); view[id].sel = null; toast(T(what === 'archive' ? 'Archived.' : 'Moved to the Trash.')); if (!$('#modal').classList.contains('hidden') && $('#sheet .mail-modal')) closeModal(); }
  mailRedraw(); if ($('#sheet .mail-modal')) mailModal(id);
}

/* ---------- layout options (per Mail widget, synced) ---------- */
function mailLookModal(id) {
  const w = state.widgets[id], o = mailOpts(w);
  const opt = (k, list) => `<div class="sw">${list.map(([v, l]) => `<button class="txt ${String(o[k]) === String(v) ? 'on' : ''}" data-act="mail.set" data-wid2="${id}" data-k="${k}" data-v="${v}">${T(l)}</button>`).join('')}</div>`;
  const tick = (k, l) => `<label class="fl mtick"><input type="checkbox" data-chg="mail.opt" data-wid2="${id}" data-k="${k}" ${o[k] ? 'checked' : ''}> ${T(l)}</label>`;
  openModal(`<h2>${T('Mail layout')}</h2><div class="sub">${T('These choices are for this Mail widget. Your mailboxes and passwords are not changed.')}</div>
    <h3>${T('Layout')}</h3>${opt('layout', [['split', 'List with reading pane next to it'], ['stacked', 'Reading pane under the list'], ['list', 'List only (mail opens in a window)']])}
    <h3>${T('Spacing')}</h3>${opt('density', [['cozy', 'Roomy (two lines)'], ['compact', 'Compact (one line)']])}
    <h3>${T('Text size')}</h3>${opt('font', [['s', 'Small'], ['m', 'Normal'], ['l', 'Large']])}
    <h3>${T('Show')}</h3><div class="mticks">${tick('preview', 'Preview text')}${tick('avatars', 'Initials of the sender')}${tick('group', 'Group by day')}</div>
    <h3>${T('Mails per mailbox')}</h3>${opt('count', [[25, '25'], [50, '50'], [100, '100']])}
    <h3>${T('Order')}</h3>${opt('sort', [['new', 'Newest first'], ['old', 'Oldest first']])}
    <h3>${T('When the widget opens')}</h3>${opt('unreadOnly', [[false, 'All mail'], [true, 'Unread only']])}
    <h3>${T('Reading')}</h3><div class="mticks">${tick('markRead', 'Mark as read when I open a mail (only mailboxes set to read & write)')}</div>
    <h3>${T('Mailboxes in this widget')}</h3><div class="mlookboxes">${MAIL.accounts.map(a => `<label class="fl mtick"><input type="checkbox" data-chg="mail.boxvis" data-wid2="${id}" data-acc="${a.id}" ${o.hidden.includes(a.id) ? '' : 'checked'}> <i class="mdot" style="--c:${esc(a.color)}"></i> ${esc(a.name)} <span class="sub">${esc(a.email)}</span></label>`).join('') || `<div class="sub">${T('No mailboxes linked yet.')}</div>`}</div>
    <div class="mfoot"><button class="ghost" data-act="mail.manage">✉️ ${T('Manage mailboxes')}</button><button data-act="modal.close">${T('Done')}</button></div>`);
}
function mailSet(id, k, v) {
  const w = state.widgets[id]; if (!w) return;
  w.data = { ...mailOpts(w), [k]: v }; save();
  if (k === 'count') mailLoad(); else mailRedraw();
}

/* ---------- Settings: managing mailboxes ---------- */
async function loadMailBox() {
  const box = $('#mailBox'); if (!box) return;
  try { const a = await (await fetch('/api/mail/accounts', { cache: 'no-store' })).json(); MAIL.accounts = a.accounts || []; MAIL.gmailReady = !!a.gmailReady; }
  catch { box.innerHTML = `<div class="sub err">${T('Could not reach the dashboard server.')}</div>`; return; }
  box.innerHTML = `<div class="sub">${T('Your mailboxes and passwords stay on this computer, encrypted. They are never sent to your phone or to the cloud.')}</div>
    ${MAIL.accounts.length ? `<ul class="list">${MAIL.accounts.map((a, i) => `<li><span class="dot" style="background:${esc(a.color)}"></span>
      <span class="t">${esc(a.name)}<br><span class="sub">${esc(a.email)} · ${a.kind === 'gmail' ? 'Gmail' : esc(a.host)} · ${a.mode === 'write' ? '✎ ' + T('read & write') : '🔒 ' + T('read only')}</span>${a.needsLogin ? `<br><span class="sub err">${mailErr('login')}</span>` : ''}</span>
      <button class="x" data-act="mail.up" data-acc="${a.id}" title="${T('Move up')}" ${i ? '' : 'disabled'}>↑</button><button class="ghost small" data-act="mail.edit" data-acc="${a.id}">${T('Change')}</button></li>`).join('')}</ul>` : ''}
    <div class="row" style="margin-top:8px"><button data-act="mail.add">＋ ${T('Link a mailbox')}</button><button class="ghost small" data-act="help.open" data-doc="docs/mail.md">📖 ${T('Guide')}</button></div>`;
}
function mailAddModal(prov) {
  if (!prov) return openModal(`<h2>${T('Link a mailbox')}</h2><div class="sub">${T('You can link as many mailboxes as you like. Pick where this one is.')}</div>
    <div class="gal mprov">${Object.entries(PROVIDERS_MAIL).map(([k, p]) => `<button data-act="mail.prov" data-v="${k}" class="${k === 'outlook' ? 'dim' : ''}"><span class="wi">${p.icon}</span><span><b>${T(p.name)}</b><small>${T(p.desc)}</small></span></button>`).join('')}</div>
    <div class="mfoot"><span></span><button class="ghost" data-act="modal.close">${T('Cancel')}</button></div>`);
  const p = PROVIDERS_MAIL[prov];
  const modes = (pw) => `<h3>${T('What may the app do?')}</h3><div class="mmodes">
      <label><input type="radio" name="mode" value="read" checked><span><b>🔒 ${T('Read only')}</b><small>${T('The app can only look at your mail. Nothing changes in your mailbox, not even whether a mail was read.')}${pw ? ' ' + T('With an app password the app itself guards this.') : ''}</small></span></label>
      <label><input type="radio" name="mode" value="write"><span><b>✎ ${T('Read & write')}</b><small>${T('The app can also mark mail as read, archive it, move it to the Trash and send mail you write yourself (only when you press Send).')}</small></span></label></div>`;
  if (prov === 'outlook') return openModal(`<h2>${T('Outlook / Hotmail')}</h2><div class="sub">${T('Microsoft only lets apps read Outlook.com mail after the maker registers the app with Microsoft, which needs an Azure account. That is not set up.')}</div>
    <h3>${T('What you can do')}</h3><ol class="gsteps"><li>${T('In Outlook.com: Settings → Mail → Forwarding → forward your mail to a Gmail address.')}</li><li>${T('Link that Gmail address here.')}</li></ol>
    <div class="mfoot"><button class="ghost" data-act="mail.add">← ${T('Back')}</button><button data-act="modal.close">${T('Close')}</button></div>`);
  if (prov === 'gmail') return openModal(`<h2>📧 Gmail</h2><div class="sub">${T('You sign in with Google in your browser. The app never sees your Google password, and you can withdraw its access at any time in your Google account.')}</div>
    ${MAIL.gmailReady ? '' : `<div class="sub err" style="margin-top:8px">${mailErr('config')}</div>`}
    <form data-form="mail.gmail">${modes(false)}
    <div class="sub" style="margin-top:8px">${T('Google will warn that the app is not verified: choose Advanced → continue. Tick the box for Gmail, otherwise the link fails.')}</div>
    <div class="mfoot"><button type="button" class="ghost" data-act="mail.add">← ${T('Back')}</button><button ${MAIL.gmailReady ? '' : 'disabled'}>${T('Sign in with Google')}</button></div></form>`);
  openModal(`<h2>${p.icon} ${T(p.name)}</h2>
    <form data-form="mail.imap" autocomplete="off"><input type="hidden" name="provider" value="${prov}">
    <h3>${T('E-mail address')}</h3><input name="email" type="email" required style="width:100%" autocomplete="off" spellcheck="false" placeholder="naam@voorbeeld.nl">
    <h3>${T('App password')}</h3><input name="pass" type="password" required style="width:100%" autocomplete="new-password" spellcheck="false">
    <div class="sub">${T('Use an app password, not your normal password. It only works for mail and you can withdraw it at any time.')}${p.help ? ` <button type="button" class="linkbtn" data-act="mail.ext" data-u="${p.help}">${T('How do I make one?')}</button>` : ''}</div>
    ${p.note ? `<div class="sub" style="margin-top:6px">ℹ️ ${T(p.note)}</div>` : ''}
    <details ${p.host ? '' : 'open'}><summary>${T('Server (advanced)')}</summary><div class="row" style="margin-top:8px"><input name="host" value="${esc(p.host || '')}" placeholder="imap.voorbeeld.nl" ${p.host ? '' : 'required'} spellcheck="false" style="flex:1 1 200px"><input name="port" value="993" inputmode="numeric" style="flex:0 1 80px" title="${T('Port')}"></div>
      <div class="sub">${T('Only secure connections (TLS, usually port 993) are used.')}</div></details>
    <h3>${T('Name (optional)')}</h3><input name="name" style="width:100%" placeholder="${T('For example: School')}" autocomplete="off">
    ${modes(true)}
    <div class="sub err" id="mailAddMsg"></div>
    <div class="mfoot"><button type="button" class="ghost" data-act="mail.add">← ${T('Back')}</button><button id="mailAddBtn">${T('Test and link')}</button></div></form>`);
}
const SMTP_GUESS = { 'imap.mail.me.com': ['smtp.mail.me.com', 587], 'imap.mail.yahoo.com': ['smtp.mail.yahoo.com', 465], 'imap.gmail.com': ['smtp.gmail.com', 465] };
function smtpHtml(a) { // the outgoing server: the same app password is used
  const g = SMTP_GUESS[a.host] || [a.host.replace(/^(imap|mail)\./, 'smtp.'), 465], h = a.smtp?.host || g[0], port = a.smtp?.port || g[1];
  return `<div class="sub">${a.smtp ? '✓ ' + T('Sending works through {0}.', esc(a.smtp.host + ':' + a.smtp.port)) : T('Not set up yet. Check the outgoing server (SMTP) and press Test.')}${a.mode === 'write' ? '' : ' ' + T('Sending only works when the mailbox is set to read & write.')}</div>
    <div class="row" style="margin-top:8px"><input name="smtpHost" value="${esc(h)}" placeholder="smtp.voorbeeld.nl" spellcheck="false" style="flex:1 1 200px">
      <select name="smtpPort" style="flex:0 1 150px">${[[465, '465 (SSL/TLS)'], [587, '587 (STARTTLS)']].map(([v, l]) => `<option value="${v}" ${+port === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <label class="fl" style="margin-top:6px"><input type="checkbox" name="saveSent" ${(a.smtp ? a.smtp.saveSent : h !== 'smtp.gmail.com') ? 'checked' : ''}> ${T('Put a copy in “Sent” (turn off if you see every sent mail twice)')}</label>
    <div class="row" style="margin-top:8px"><button type="button" class="ghost small" data-act="mail.smtp" data-acc="${a.id}">${T('Test and save')}</button>${a.smtp ? `<button type="button" class="ghost small" data-act="mail.smtpoff" data-acc="${a.id}">${T('Turn sending off')}</button>` : ''}<span class="sub" id="smtpMsg"></span></div>`;
}
function mailEditModal(accId) {
  const a = mailAcc(accId); if (!a) return;
  const cols = ['#ea4335', '#4285f4', '#34a853', '#a142f4', '#f29900', '#12b5cb', '#e8710a', '#e52592', '#64748b'];
  openModal(`<h2>${T('Change mailbox')}</h2><div class="sub">${esc(a.email)}</div>
    <form data-form="mail.save"><input type="hidden" name="id" value="${a.id}">
    <h3>${T('Name')}</h3><input name="name" value="${esc(a.name)}" style="width:100%" autocomplete="off">
    <h3>${T('Colour')}</h3><div class="cpal">${cols.concat(cols.includes(a.color) ? [] : [a.color]).map(c => `<label><input type="radio" name="color" value="${c}" ${c === a.color ? 'checked' : ''}><span style="background:${c}"></span></label>`).join('')}</div>
    ${a.kind === 'gmail' ? `<h3>${T('Which Gmail tabs do you want to see?')}</h3>
      <div class="mticks">${[['primary', 'Primary'], ['social', 'Social'], ['promotions', 'Promotions'], ['updates', 'Updates'], ['forums', 'Forums']].map(([k, l]) => `<label class="fl mtick"><input type="checkbox" name="cats" value="${k}" ${(a.cats || ['primary']).includes(k) ? 'checked' : ''}> ${T(l)}</label>`).join('')}</div>
      <div class="sub">${T('By default only Primary is shown, so promotions and updates do not bury your real mail. If you switched Gmail’s tabs off, tick everything.')}</div>` : ''}
    <h3>${T('What may the app do?')}</h3>
    ${a.kind === 'gmail'
      ? `<div class="sub">${a.mode === 'write' ? '✎ ' + T('read & write') : '🔒 ' + T('read only')}. ${T('For Gmail this is a permission at Google, so changing it means signing in again.')}</div>
         <div class="row" style="margin-top:8px"><button type="button" class="ghost small" data-act="mail.relogin" data-acc="${a.id}" data-v="${a.mode === 'write' ? 'read' : 'write'}">${T(a.mode === 'write' ? 'Sign in again with read only' : 'Sign in again with read & write')}</button></div>`
      : `<div class="mmodes"><label><input type="radio" name="mode" value="read" ${a.mode === 'read' ? 'checked' : ''}><span><b>🔒 ${T('Read only')}</b></span></label><label><input type="radio" name="mode" value="write" ${a.mode === 'write' ? 'checked' : ''}><span><b>✎ ${T('Read & write')}</b></span></label></div>
      <h3>✉️ ${T('Sending')}</h3>${smtpHtml(a)}`}
    <div class="mfoot"><button type="button" class="danger" data-act="mail.remove" data-acc="${a.id}">${T('Remove')}</button><span style="display:flex;gap:8px"><button type="button" class="ghost" data-act="mail.manage">${T('Cancel')}</button><button>${T('Save')}</button></span></div></form>`);
}
async function mailGmailLogin(mode, account) {
  const before = JSON.stringify(MAIL.accounts.map(a => [a.id, a.mode, a.needsLogin]));
  const r = await fetch('/api/mail/gmail/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode, account }) });
  const j = await r.json().catch(() => ({}));
  if (!j.url) return toast(mailErr(j.error));
  if (!/Electron/.test(navigator.userAgent)) { location.href = j.url; return; }
  window.open(j.url); toast(T('Finish signing in in your browser…'));
  for (let i = 0; i < 150; i++) { // wait until the mailbox appears (or changes)
    await new Promise(r => setTimeout(r, 2000));
    const a = await fetch('/api/mail/accounts').then(r => r.json()).catch(() => null);
    if (a && JSON.stringify(a.accounts.map(x => [x.id, x.mode, x.needsLogin])) !== before) { MAIL.accounts = a.accounts; toast(T('Mailbox linked!')); if (view.setSec === 'mail' && !$('#modal').classList.contains('hidden')) settingsModal('mail'); else closeModal(); mailLoad(true); return; }
  }
}

/* ---------- handlers ---------- */
/* ---------- Settings: the AI box ---------- */
let aiPoll = 0;
async function loadAiBox() {
  clearTimeout(aiPoll); const box = $('#aiBox'); if (!box) return;
  const c = aiCfg(); let st = null;
  try { st = await (await fetch('/api/mail/ai/status' + (c.on ? '?probe=1' : ''), { cache: 'no-store' })).json(); } catch {}
  if (!$('#aiBox')) return;
  const pull = st?.pulling, pct = pull?.total ? Math.round(pull.completed / pull.total * 100) : 0;
  let status = '';
  if (c.on && st) {
    if (!st.installed) status = `<div class="aibox err">${T(AI_ERR.noollama)} <button class="linkbtn" data-act="help.open" data-doc="docs/mail.md">${T('How do I install it?')}</button></div>`;
    else if (pull) status = `<div class="ovprog"><div><i style="width:${pct}%"></i></div><small>${T('Downloading the model… {0}%', pct)}</small></div>`;
    else if (st.error && !st.modelReady) status = `<div class="aibox err">${T(AI_ERR[st.error] || AI_ERR.fail)}</div>`;
    else if (st.modelReady === false) status = `<div class="aibox">${T('The model “{0}” is not downloaded yet (about 3.4 GB).', c.model)} <button class="small" data-act="ai.pull">${T('Download the model')}</button></div>`;
    else if (st.modelReady) status = `<div class="aibox ok">✓ ${T('Ready.')} ${st.processor === 'gpu' ? T('Running on the graphics chip.') : st.processor === 'cpu' ? T('Running on the processor.') : ''}</div>`;
  }
  box.innerHTML = `<div class="aisw"><button class="mswitch ${c.on ? 'on' : ''}" data-act="ai.toggle" role="switch" aria-checked="${!!c.on}"><i></i></button>
      <span><b>${T('Summarise my mail with AI')}</b><small>${T('A small AI model runs on this computer. Your mail is never sent to the internet or a cloud service, and nothing is kept on disk.')}</small></span></div>
    ${c.on ? `${status}
      <div class="mticks" style="margin-top:8px">
        <label class="fl mtick"><input type="checkbox" data-chg="ai.opt" data-k="auto" ${c.auto ? 'checked' : ''}> ${T('Summarise a mail automatically when I open it')}</label>
        <label class="fl mtick"><input type="checkbox" data-chg="ai.opt" data-k="gpu" ${c.gpu ? 'checked' : ''}> ${T('Use the graphics chip (faster, experimental; falls back to the processor)')}</label></div>
      <div class="row" style="margin-top:8px;align-items:center"><span class="sub">${T('Model')}</span><input data-chg="ai.model" value="${esc(c.model)}" style="flex:0 1 180px" spellcheck="false" autocomplete="off">
        <button class="ghost small" data-act="ai.test">↻ ${T('Check')}</button><button class="ghost small" data-act="ai.forget">${T('Forget summaries')}</button><button class="ghost small" data-act="ai.stop">${T('Stop the AI')}</button></div>` : ''}`;
  if (pull) aiPoll = setTimeout(loadAiBox, 1500);
}
const aiSet = patch => { state.settings.ai = { ...aiCfg(), ...patch }; save(); };
Object.assign(ACT, {
  'ai.toggle': () => { aiSet({ on: !aiCfg().on }); AI.warm = false; AI.sums.clear(); loadAiBox(); mailRedraw(); if (aiOn()) mailLoad(); },
  'ai.pull': async () => { if (!confirm(T('Download the AI model now? It is about 3.4 GB and is stored on this computer.'))) return; await fetch('/api/mail/ai/pull', { method: 'POST' }); loadAiBox(); },
  'ai.test': () => loadAiBox(),
  'ai.forget': async () => { await fetch('/api/mail/ai/forget', { method: 'POST' }); AI.sums.clear(); mailRedraw(); toast(T('Summaries forgotten.')); },
  'ai.stop': async () => { await fetch('/api/mail/ai/stop', { method: 'POST' }); AI.warm = false; toast(T('The AI has been stopped. It starts again when it is needed.')); loadAiBox(); },
  'mail.aihelp': () => settingsModal('ai'),
  'mail.sum': ({ d }) => { AI.sums.delete(d.acc + '|' + d.id); aiSummarize(d.acc, d.id); },
  'mail.ov': ({ id }) => {
    const v = view[id] ||= {}; if (v.ov) { delete v.ov; return mailRedraw(); }
    aiOverview(id, 'today'); if ($(`[data-wid="${id}"] .mread`)?.offsetParent === null) mailModal(id);
  },
  'mail.ovrange': ({ id, d }) => aiOverview(id, d.v),
  'mail.ovclose': ({ id }) => { delete view[id].ov; if ($('#sheet .mail-modal')) closeModal(); else mailRedraw(); },
  'mail.ovopen': ({ id, d }) => { delete view[id].ov; if ($('#sheet .mail-modal')) closeModal(); mailOpen(id, d.acc, d.id); },
  'mail.add': () => { refocus = null; mailAddModal(); },
  'mail.prov': ({ d }) => mailAddModal(d.v),
  'mail.ext': ({ d }) => { if (/^https:\/\//.test(d.u)) window.open(d.u, '_blank'); },
  'mail.look': ({ id }) => mailLookModal(id),
  'mail.manage': () => settingsModal('mail'),
  'mail.refresh': () => mailLoad(true),
  'mail.filter': ({ id, d }) => { (view[id] ||= {}).unreadOnly = d.v === 'unread'; mailRedraw(); },
  'mail.vis': ({ id, d }) => { const w = state.widgets[id], o = mailOpts(w), h = new Set(o.hidden); h.has(d.acc) ? h.delete(d.acc) : h.add(d.acc); mailSet(id, 'hidden', [...h]); if (!h.has(d.acc)) mailLoad(); },
  'mail.allvis': ({ id }) => { const o = mailOpts(state.widgets[id]); mailSet(id, 'hidden', o.hidden.length ? [] : MAIL.accounts.map(a => a.id)); mailLoad(); },
  'mail.open': ({ id, d }) => mailOpen(id, d.acc, d.id),
  'mail.do': ({ d, el }) => { const id = el.closest('[data-wid]')?.dataset.wid; if (id) mailDo(id, d.v); },
  'mail.link': ({ d }) => { const u = d.u; if (/^https?:\/\//i.test(u) && confirm(T('Open this link in your browser?') + '\n\n' + u)) window.open(u, '_blank'); },
  'mail.set': ({ d }) => { mailSet(d.wid2, d.k, d.k === 'count' ? +d.v : d.v === 'true' ? true : d.v === 'false' ? false : d.v); mailLookModal(d.wid2); },
  'mail.edit': ({ d }) => mailEditModal(d.acc),
  'mail.relogin': ({ d }) => mailGmailLogin(d.v, d.acc),
  'mail.up': async ({ d }) => { const ids = MAIL.accounts.map(a => a.id), i = ids.indexOf(d.acc); if (i < 1) return; [ids[i - 1], ids[i]] = [ids[i], ids[i - 1]];
    await fetch('/api/mail/order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids }) }); loadMailBox(); mailLoad(); },
  'mail.remove': async ({ d }) => {
    const a = mailAcc(d.acc); if (!a || !confirm(T('Remove the mailbox “{0}” from the app? Your mail itself stays in your mailbox; nothing is deleted there.', a.name))) return;
    await fetch('/api/mail/account', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: a.id }) });
    for (const w of Object.values(state.widgets)) if (w.type === 'mail' && w.data?.hidden?.includes(a.id)) w.data.hidden = w.data.hidden.filter(x => x !== a.id);
    save(); MAIL.msgs = MAIL.msgs.filter(m => m.acc !== a.id); toast(T('Mailbox removed.')); settingsModal('mail'); mailLoad();
  },
});
Object.assign(CHG, {
  'ai.opt': ({ d, el }) => { aiSet({ [d.k]: el.checked }); if (d.k === 'gpu') { fetch('/api/mail/ai/stop', { method: 'POST' }).catch(() => {}); AI.warm = false; } },
  'ai.model': ({ el }) => { const m = el.value.trim(); if (/^[a-z0-9][a-z0-9._-]{0,60}(:[a-z0-9._-]{1,40})?$/i.test(m)) { aiSet({ model: m }); AI.sums.clear(); AI.warm = false; loadAiBox(); } else { toast(T('That is not a model name like gemma3:4b.')); el.value = aiCfg().model; } },
  'mail.opt': ({ d, el }) => mailSet(d.wid2, d.k, el.checked),
  'mail.boxvis': ({ d, el }) => { const o = mailOpts(state.widgets[d.wid2]), h = new Set(o.hidden); el.checked ? h.delete(d.acc) : h.add(d.acc); mailSet(d.wid2, 'hidden', [...h]); mailLoad(); },
});
Object.assign(INP, { 'mail.q': ({ id, el }) => { (view[id] ||= {}).q = el.value; mailRedraw(); } });
Object.assign(FORM, {
  'mail.imap': async ({ el, v }) => {
    refocus = null; const btn = $('#mailAddBtn'), msg = $('#mailAddMsg'); msg.textContent = ''; btn.disabled = true; btn.textContent = T('Testing the connection…');
    const body = { provider: v.provider, email: v.email, pass: v.pass, host: v.host, port: v.port, name: v.name, mode: v.mode };
    el.elements.pass.value = ''; // the password does not stay in the page
    try {
      const r = await fetch('/api/mail/imap', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); const j = await r.json().catch(() => ({}));
      if (!r.ok) { msg.textContent = mailErr(j.error); return; }
      toast(T('Mailbox linked!')); closeModal(); mailLoad(true);
    } catch { msg.textContent = mailErr('fail'); }
    finally { if (btn.isConnected) { btn.disabled = false; btn.textContent = T('Test and link'); } }
  },
  'mail.gmail': ({ v }) => { refocus = null; mailGmailLogin(v.mode); },
  'mail.save': async ({ el, v }) => {
    refocus = null;
    const cats = el.querySelector('[name="cats"]') ? new FormData(el).getAll('cats') : undefined; // a checkbox group: the generic form reader keeps only one value
    const r = await fetch('/api/mail/account', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: v.id, name: v.name, color: v.color, mode: v.mode, cats }) });
    if (!r.ok) toast(mailErr((await r.json().catch(() => ({}))).error)); settingsModal('mail'); mailLoad();
  },
});

/* ---------- writing and answering mail ----------
   The app never sends by itself. You see who it goes to and the text, you press Send and then confirm. An AI draft only fills in the text box.
   The draft only lives in this window (not in the synced dashboard data, not on disk). */
let CMP = null; // { acc, reply: id | null, all, confirm, ai }
const cmpVal = () => { const f = $('#sheet form[data-form="mail.send"]'); return f ? Object.fromEntries([...new FormData(f)].map(([k, v]) => [k, String(v)])) : null; };
function composeLeave() { // asked before the window closes
  if (!CMP || !$('#sheet .compose')) { CMP = null; return true; }
  const v = cmpVal() || {}, typed = (v.text || '').trim() || (!CMP.reply && ((v.to || '').trim() || (v.subject || '').trim()));
  if (typed && !confirm(T('Throw away this mail? It has not been sent.'))) return false;
  CMP = null; return true;
}
function composeOpen(o) { // o: { acc, reply, all, to, cc, subject }
  const senders = MAIL.accounts.filter(a => a.canSend); if (!senders.length) return toast(mailErr('nosmtp'));
  CMP = { acc: o.acc || senders[0].id, reply: o.reply || null, all: !!o.all, confirm: false, ai: false };
  const a = mailAcc(CMP.acc), sus = o.reply && AI.sums.get(CMP.acc + '|' + o.reply)?.task === 'suspect';
  const from = o.reply ? `<b>${esc(a.name)}</b> <span class="sub">&lt;${esc(a.email)}&gt;</span>`
    : `<select name="acc" data-chg="mail.cmpfrom">${senders.map(x => `<option value="${x.id}" ${x.id === CMP.acc ? 'selected' : ''}>${esc(x.name === x.email ? x.email : x.name + ' <' + x.email + '>')}</option>`).join('')}</select>`;
  const row = (l, inner) => `<label class="cmprow"><span>${T(l)}</span>${inner}</label>`;
  const inp = (n, val, ph = '') => `<input name="${n}" value="${esc(val || '')}" placeholder="${esc(ph)}" autocomplete="off" spellcheck="false" data-inp="mail.cmpedit">`;
  openModal(`<div class="compose"><h2>${o.reply ? '↩ ' + T(o.all ? 'Reply all' : 'Reply') : '✎ ' + T('New mail')}</h2>
    ${sus ? `<div class="aibox t-suspect">⚠️ ${T('The AI thinks this mail is suspicious (possibly phishing). Never send passwords, codes or bank details, and check the address you reply to.')}</div>` : ''}
    <form data-form="mail.send" autocomplete="off">
    <div class="cmprow"><span>${T('From')}</span><span class="cmpfrom">${from}</span></div>
    ${row('To', inp('to', o.to, 'naam@voorbeeld.nl, …'))}
    ${row('Cc', inp('cc', o.cc))}
    <details class="cmpbcc"><summary>${T('Bcc (hidden copy)')}</summary>${row('Bcc', inp('bcc', ''))}</details>
    ${row('Subject', inp('subject', o.subject))}
    ${o.reply && aiOn() ? `<div class="cmpai"><input id="cmpWish" placeholder="${T('What do you want to answer? E.g. “yes, I’ll come” or “ask for one more week”')}" autocomplete="off" maxlength="300"><button type="button" class="small mai" data-act="mail.draft" id="cmpAiBtn">✨ ${T('Write a draft')}</button></div><div class="sub" id="cmpAiMsg"></div>` : ''}
    <textarea name="text" id="cmpText" rows="12" placeholder="${T('Your message…')}" data-inp="mail.cmpedit"></textarea>
    ${o.reply ? `<label class="fl"><input type="checkbox" name="quote" checked data-chg="mail.cmpedit2"> ${T('Add the original mail underneath')}</label>` : ''}
    <div class="sub" style="margin-top:4px">🔒 ${T('Sent from {0}. Attachments are not possible yet.', esc(a.email))}</div>
    <div id="cmpConfirm"></div><div class="sub err" id="cmpMsg"></div>
    <div class="mfoot"><button type="button" class="ghost" data-act="modal.close">${T('Cancel')}</button><button id="cmpSend">${T('Send…')}</button></div></form></div>`);
  $('#sheet').classList.add('wide');
  setTimeout(() => $(o.to ? (o.reply && aiOn() ? '#cmpWish' : '#cmpText') : '#sheet [name="to"]')?.focus(), 50);
}
const cmpUnconfirm = () => { if (CMP?.confirm) { CMP.confirm = false; $('#cmpConfirm').innerHTML = ''; $('#cmpSend').hidden = false; } };
async function composeSend() {
  const v = cmpVal(); if (!v || !CMP || CMP.busy) return;
  const btn = $('#cmpGo'), msg = $('#cmpMsg'); CMP.busy = true; btn.disabled = true; btn.textContent = T('Sending…'); msg.textContent = '';
  try {
    const body = { acc: CMP.reply ? CMP.acc : v.acc || CMP.acc, to: v.to, cc: v.cc, bcc: v.bcc, subject: v.subject, text: v.text, reply: CMP.reply ? { id: CMP.reply, quote: v.quote === 'on' } : null };
    const r = await fetch('/api/mail/send', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); const j = await r.json().catch(() => ({}));
    if (!r.ok) { msg.textContent = mailErr(j.error); cmpUnconfirm(); return; }
    CMP = null; closeModal(true); toast(j.copy === 'no' ? T('Sent ✓ (no “Sent” folder was found for a copy)') : T('Sent ✓')); mailLoad(true);
  } catch { msg.textContent = mailErr('fail'); cmpUnconfirm(); }
  finally { if (CMP) CMP.busy = false; if (btn.isConnected) { btn.disabled = false; btn.textContent = T('Yes, send'); } }
}
async function composeDraft() {
  if (!CMP?.reply || CMP.ai) return; const ta = $('#cmpText'), msg = $('#cmpAiMsg'), btn = $('#cmpAiBtn');
  if (ta.value.trim() && !confirm(T('Replace your text with a draft from the AI?'))) return;
  CMP.ai = true; btn.disabled = true; ta.readOnly = true; ta.value = ''; msg.innerHTML = `<span class="spin"></span> ${T('The AI is writing a draft…')}`; cmpUnconfirm();
  try {
    const r = await fetch('/api/mail/ai/draft', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ acc: CMP.acc, id: CMP.reply, intent: $('#cmpWish')?.value || '' }) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); msg.textContent = T(AI_ERR[j.error] || AI_ERR.fail); return; }
    let err = '';
    await aiStream(r, ev => { if (!ta.isConnected) return; if (ev.t === 'tok' || ev.t === 'done') ta.value = ev.t === 'done' ? ev.text : ev.v; else if (ev.t === 'err') err = ev.c; });
    if (msg.isConnected) msg.textContent = err ? T(AI_ERR[err] || AI_ERR.fail) : '✨ ' + T('AI draft: read it and change what is not right before you send it.');
  } catch { if (msg.isConnected) msg.textContent = T(AI_ERR.fail); }
  finally { if (CMP) CMP.ai = false; if (ta.isConnected) { ta.readOnly = false; ta.focus(); } if (btn?.isConnected) btn.disabled = false; }
}
Object.assign(ACT, {
  'mail.new': () => { refocus = null; composeOpen({}); },
  'mail.reply': async ({ d }) => {
    refocus = null;
    if (AI.sums.get(d.acc + '|' + d.id)?.task === 'suspect' && !confirm(T('The AI thinks this mail is suspicious (possibly phishing). Reply anyway?'))) return;
    try {
      const r = await fetch(`/api/mail/reply-info?acc=${encodeURIComponent(d.acc)}&id=${encodeURIComponent(d.id)}&all=${d.all ? 1 : 0}`); const j = await r.json().catch(() => ({}));
      if (!r.ok) return toast(mailErr(j.error));
      composeOpen({ acc: d.acc, reply: d.id, all: !!d.all, to: j.to, cc: j.cc, subject: j.subject });
    } catch { toast(mailErr('fail')); }
  },
  'mail.draft': () => composeDraft(),
  'mail.sendgo': () => composeSend(),
  'mail.sendback': () => cmpUnconfirm(),
  'mail.smtp': async ({ d, el }) => {
    const f = el.closest('form'), msg = $('#smtpMsg'); msg.textContent = T('Testing the connection…'); el.disabled = true;
    try {
      const r = await fetch('/api/mail/smtp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: d.acc, smtp: { host: f.elements.smtpHost.value.trim(), port: +f.elements.smtpPort.value, saveSent: f.elements.saveSent.checked } }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { msg.textContent = mailErr(j.error); return; }
      MAIL.accounts = MAIL.accounts.map(x => x.id === j.account.id ? j.account : x); toast(T('Sending works ✓')); mailEditModal(d.acc); mailRedraw();
    } catch { msg.textContent = mailErr('fail'); } finally { if (el.isConnected) el.disabled = false; }
  },
  'mail.smtpoff': async ({ d }) => {
    const r = await fetch('/api/mail/smtp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: d.acc, smtp: null }) }); const j = await r.json().catch(() => ({}));
    if (r.ok) { MAIL.accounts = MAIL.accounts.map(x => x.id === j.account.id ? j.account : x); mailEditModal(d.acc); mailRedraw(); }
  },
});
Object.assign(INP, { 'mail.cmpedit': () => cmpUnconfirm() });
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches?.('.compose input')) e.preventDefault(); }); // Enter in a field never starts sending
Object.assign(CHG, { 'mail.cmpedit2': () => cmpUnconfirm(), 'mail.cmpfrom': ({ el }) => { if (CMP) CMP.acc = el.value; cmpUnconfirm(); } });
Object.assign(FORM, {
  'mail.send': ({ v }) => { // step 1: show exactly what will be sent; step 2 (the button in that box) sends
    refocus = null; if (!CMP) return;
    const a = mailAcc(CMP.reply ? CMP.acc : v.acc || CMP.acc), list = s => (s || '').split(',').map(x => x.trim()).filter(Boolean);
    const to = list(v.to), cc = list(v.cc), bcc = list(v.bcc);
    if (!to.length) { $('#cmpMsg').textContent = mailErr('noto'); return; }
    if (!v.text.trim() && !confirm(T('The mail has no text. Send it anyway?'))) return;
    CMP.confirm = true; $('#cmpMsg').textContent = ''; $('#cmpSend').hidden = true;
    $('#cmpConfirm').innerHTML = `<div class="cmpok"><b>${T('Check before you send')}</b>
      <div>${T('From')}: <b>${esc(a.email)}</b></div><div>${T('To')}: ${to.map(esc).join(', ')}</div>${cc.length ? `<div>Cc: ${cc.map(esc).join(', ')}</div>` : ''}${bcc.length ? `<div>Bcc: ${bcc.map(esc).join(', ')}</div>` : ''}
      <div>${T('Subject')}: ${esc(v.subject || T('(no subject)'))}</div>
      <div class="row" style="margin-top:8px;justify-content:flex-end"><button type="button" class="ghost" data-act="mail.sendback">${T('Back')}</button><button type="button" id="cmpGo" data-act="mail.sendgo">${T('Yes, send')}</button></div></div>`;
  },
});

/* ---------- the widget type, the Mail tab (added once) and the Settings section ---------- */
WIDGETS.mail = { name: 'Mail', icon: '✉️', desc: 'All your mailboxes in one list (on your computer)', w: 12, h: 82, init: () => ({ ...MAILDEF }), render: mailRender };
function mailMigrate() { // a "Mail" tab is added once on the computer; if you delete it, it does not come back
  if (APP || !state || state.settings.mailTab) return false;
  const t = { id: uid(), name: 'Mail', icon: '✉️', widgets: [] }, wid = uid();
  state.widgets[wid] = { ...mk('mail'), w: 12, h: 82 }; t.widgets.push(wid); state.tabs.push(t); state.settings.mailTab = true;
  return true;
}
{ // back from the Gmail sign-in in a normal browser (not the desktop app)
  const p = new URLSearchParams(location.search).get('mail');
  if (p) { history.replaceState(null, '', '/'); const t = setInterval(() => { if (!state) return; clearInterval(t); toast(T(p === 'ok' ? 'Mailbox linked!' : p === 'scope' ? 'Not all permissions were given. Try again and tick the box for Gmail.' : 'Linking the mailbox failed. Try again.')); mailLoad(true); }, 200); }
}

Object.assign(NL, {
  'Mail': 'Mail', 'All your mailboxes in one list (on your computer)': 'Al je postvakken in één lijst (op je computer)',
  'Sign-in refused. Check the address and use an app password, not your normal password.': 'Inloggen geweigerd. Controleer het adres en gebruik een app-wachtwoord, niet je gewone wachtwoord.',
  'This server does not exist. Check the server name.': 'Deze server bestaat niet. Controleer de servernaam.',
  'Cannot reach the mail server. Check your internet connection or the server and port.': 'De mailserver is niet bereikbaar. Controleer je internet, of de server en poort.',
  'The secure connection to the server is not right, so the app does not trust it.': 'De beveiligde verbinding met de server klopt niet, dus de app vertrouwt hem niet.',
  'This mailbox needs you to sign in again.': 'Voor dit postvak moet je opnieuw inloggen.', 'This mailbox is set to read only.': 'Dit postvak staat op alleen lezen.',
  'This mailbox has no Archive folder.': 'Dit postvak heeft geen archiefmap.', 'This mailbox has no Trash folder, so nothing was deleted.': 'Dit postvak heeft geen prullenbak, dus er is niets verwijderd.',
  'This mail is too large to show here. Open it in your mail app.': 'Deze mail is te groot om hier te tonen. Open hem in je mail-app.', 'This mail no longer exists.': 'Deze mail bestaat niet meer.',
  'The Gmail API is switched off in your Google project. Enable it, then try again.': 'De Gmail API staat uit in je Google-project. Zet hem aan en probeer het opnieuw.',
  'Google did not allow this. Sign in again for this mailbox.': 'Google stond dit niet toe. Log opnieuw in voor dit postvak.', 'The mail server is busy. Try again in a minute.': 'De mailserver is druk. Probeer het over een minuut opnieuw.',
  'The mail server took too long to answer.': 'De mailserver antwoordde te traag.', 'Set up the Google connection first: Settings → Calendars → Google.': 'Stel eerst de Google-koppeling in: Instellingen → Agenda’s → Google.',
  'Fill in all fields.': 'Vul alle velden in.', 'Something went wrong. Try again.': 'Er ging iets mis. Probeer het opnieuw.',
  'Recommended: sign in with Google, no password needed': 'Aanbevolen: inloggen met Google, geen wachtwoord nodig', 'iCloud Mail': 'iCloud Mail',
  'iPhone / Apple mail, with an app-specific password': 'iPhone- / Apple-mail, met een app-specifiek wachtwoord', 'Yahoo Mail': 'Yahoo Mail', 'With an app password': 'Met een app-wachtwoord',
  'Other (IMAP)': 'Andere (IMAP)', 'GMX, school, work, your own domain…': 'GMX, school, werk, je eigen domein…', 'Gmail with an app password': 'Gmail met een app-wachtwoord',
  'Only if signing in with Google does not work': 'Alleen als inloggen met Google niet lukt', 'Outlook / Hotmail': 'Outlook / Hotmail', 'Not available (see why)': 'Niet beschikbaar (lees waarom)',
  '(unknown sender)': '(onbekende afzender)', 'Mail is only on your computer, so your mailboxes and passwords never leave it.': 'Mail staat alleen op je computer, zodat je postvakken en wachtwoorden die nooit verlaten.',
  'Loading your mail…': 'Je mail wordt geladen…', 'Link your mailboxes and read all your mail in one place.': 'Koppel je postvakken en lees al je mail op één plek.',
  'As many as you like: Gmail, iCloud, Yahoo, school or work.': 'Zoveel als je wilt: Gmail, iCloud, Yahoo, school of werk.', 'Link a mailbox': 'Postvak koppelen',
  'Mailboxes': 'Postvakken', 'Show all mailboxes': 'Alle postvakken tonen', 'Hide all mailboxes': 'Alle postvakken verbergen', 'Show this mailbox': 'Dit postvak tonen', 'Hide this mailbox': 'Dit postvak verbergen',
  'read & write': 'lezen en schrijven', 'read only': 'alleen lezen', 'Layout': 'Weergave', 'All mailboxes are hidden.': 'Alle postvakken zijn verborgen.',
  'No mail matches your search.': 'Geen mail gevonden.', 'No unread mail. 🎉': 'Geen ongelezen mail. 🎉', 'No mail.': 'Geen mail.', 'Search mail': 'Zoek in mail', 'All': 'Alles', 'Unread': 'Ongelezen',
  '1 mailbox hidden': '1 postvak verborgen', '{0} mailboxes hidden': '{0} postvakken verborgen', 'show all': 'alles tonen', '1 mailbox': '1 postvak', '{0} mailboxes': '{0} postvakken',
  'Updated {0}': 'Bijgewerkt {0}', 'Choose a mail to read it here.': 'Kies een mail om hem hier te lezen.', 'Mark as read': 'Markeer als gelezen', 'Mark as unread': 'Markeer als ongelezen',
  'Archive': 'Archiveren', 'To Trash': 'Naar prullenbak', 'Read only: nothing changes in this mailbox.': 'Alleen lezen: er verandert niets in dit postvak.', '(no subject)': '(geen onderwerp)', 'To': 'Aan',
  'Attachments are only listed here. Open the mail in your mail app to save them.': 'Bijlagen worden hier alleen getoond. Open de mail in je mail-app om ze op te slaan.',
  'A subject or address cannot contain a line break.': 'Een onderwerp of adres mag geen regeleinde bevatten.', 'One of the addresses is not a valid e-mail address.': 'Een van de adressen is geen geldig e-mailadres.',
  'Fill in who the mail is for.': 'Vul in voor wie de mail is.', 'Too many recipients (at most 50).': 'Te veel ontvangers (maximaal 50).', 'The mail is empty.': 'De mail is leeg.',
  'You sent a lot of mail in a short time. Wait a few minutes.': 'Je hebt veel mail verstuurd in korte tijd. Wacht een paar minuten.', 'Use port 465 or 587 (secure connections only).': 'Gebruik poort 465 of 587 (alleen beveiligde verbindingen).',
  'Sending is not set up for this mailbox yet: Change mailbox → Sending.': 'Versturen is nog niet ingesteld voor dit postvak: Postvak wijzigen → Versturen.',
  'Reply': 'Beantwoorden', 'Reply all': 'Allen beantwoorden', 'Set up sending': 'Versturen instellen', 'To reply from the app, set it to read & write.': 'Om vanuit de app te antwoorden, zet je het op lezen en schrijven.',
  'Write a new mail': 'Een nieuwe mail schrijven', 'New': 'Nieuw', 'New mail': 'Nieuwe mail', 'From': 'Van', 'Cc': 'Cc', 'Bcc': 'Bcc', 'Bcc (hidden copy)': 'Bcc (verborgen kopie)', 'Subject': 'Onderwerp',
  'The app can also mark mail as read, archive it, move it to the Trash and send mail you write yourself (only when you press Send).': 'De app kan ook mail als gelezen markeren, archiveren, naar de prullenbak verplaatsen en mail versturen die je zelf schrijft (alleen als jij op Versturen drukt).',
  'Sending': 'Versturen', 'Sending works through {0}.': 'Versturen gaat via {0}.', 'Not set up yet. Check the outgoing server (SMTP) and press Test.': 'Nog niet ingesteld. Controleer de uitgaande server (SMTP) en druk op Testen.',
  'Sending only works when the mailbox is set to read & write.': 'Versturen werkt alleen als het postvak op lezen en schrijven staat.', 'Put a copy in “Sent” (turn off if you see every sent mail twice)': 'Een kopie in “Verzonden” zetten (zet uit als je elke verzonden mail dubbel ziet)',
  'Test and save': 'Testen en opslaan', 'Turn sending off': 'Versturen uitzetten', 'Sending works ✓': 'Versturen werkt ✓',
  'Throw away this mail? It has not been sent.': 'Deze mail weggooien? Hij is niet verstuurd.',
  'The AI thinks this mail is suspicious (possibly phishing). Never send passwords, codes or bank details, and check the address you reply to.': 'De AI vindt deze mail verdacht (mogelijk phishing). Stuur nooit wachtwoorden, codes of bankgegevens, en controleer het adres waarop je antwoordt.',
  'The AI thinks this mail is suspicious (possibly phishing). Reply anyway?': 'De AI vindt deze mail verdacht (mogelijk phishing). Toch antwoorden?',
  'What do you want to answer? E.g. “yes, I’ll come” or “ask for one more week”': 'Wat wil je antwoorden? Bijv. “ja, ik kom” of “vraag een week uitstel”', 'Write a draft': 'Concept schrijven',
  'Your message…': 'Je bericht…', 'Add the original mail underneath': 'De originele mail eronder zetten', 'Sent from {0}. Attachments are not possible yet.': 'Verstuurd vanaf {0}. Bijlagen kunnen nog niet.',
  'Send…': 'Versturen…', 'Sending…': 'Versturen…', 'Yes, send': 'Ja, versturen', 'Check before you send': 'Controleer voor je verstuurt', 'Back': 'Terug',
  'Sent ✓': 'Verstuurd ✓', 'Sent ✓ (no “Sent” folder was found for a copy)': 'Verstuurd ✓ (geen map “Verzonden” gevonden voor een kopie)',
  'Replace your text with a draft from the AI?': 'Je tekst vervangen door een concept van de AI?', 'The AI is writing a draft…': 'De AI schrijft een concept…',
  'AI draft: read it and change what is not right before you send it.': 'AI-concept: lees het na en pas aan wat niet klopt voor je het verstuurt.', 'The mail has no text. Send it anyway?': 'De mail heeft geen tekst. Toch versturen?',
  'Loading…': 'Laden…', '(This mail has no text.)': '(Deze mail heeft geen tekst.)', 'Move this mail to the Trash? You can still get it back from there.': 'Deze mail naar de prullenbak verplaatsen? Je kunt hem daar nog terughalen.',
  'Archived.': 'Gearchiveerd.', 'Moved to the Trash.': 'Naar de prullenbak verplaatst.', 'Mail layout': 'Weergave van mail',
  'These choices are for this Mail widget. Your mailboxes and passwords are not changed.': 'Deze keuzes gelden voor deze mail-widget. Je postvakken en wachtwoorden veranderen niet.',
  'List with reading pane next to it': 'Lijst met leesvenster ernaast', 'Reading pane under the list': 'Leesvenster onder de lijst', 'List only (mail opens in a window)': 'Alleen lijst (mail opent in een venster)',
  'Spacing': 'Ruimte', 'Roomy (two lines)': 'Ruim (twee regels)', 'Compact (one line)': 'Compact (één regel)', 'Text size': 'Tekstgrootte', 'Small': 'Klein', 'Normal': 'Normaal', 'Large': 'Groot',
  'Show': 'Tonen', 'Preview text': 'Voorbeeldtekst', 'Initials of the sender': 'Initialen van de afzender', 'Group by day': 'Groeperen per dag', 'Mails per mailbox': 'Mails per postvak',
  'Order': 'Volgorde', 'Newest first': 'Nieuwste eerst', 'Oldest first': 'Oudste eerst', 'When the widget opens': 'Bij het openen', 'All mail': 'Alle mail', 'Unread only': 'Alleen ongelezen',
  'Reading': 'Lezen', 'Mark as read when I open a mail (only mailboxes set to read & write)': 'Markeer als gelezen wanneer ik een mail open (alleen postvakken met lezen en schrijven)',
  'Mailboxes in this widget': 'Postvakken in deze widget', 'No mailboxes linked yet.': 'Nog geen postvakken gekoppeld.', 'Manage mailboxes': 'Postvakken beheren',
  'Your mailboxes and passwords stay on this computer, encrypted. They are never sent to your phone or to the cloud.': 'Je postvakken en wachtwoorden blijven versleuteld op deze computer. Ze gaan nooit naar je gsm of naar de cloud.',
  'Move up': 'Omhoog', 'Guide': 'Handleiding', 'You can link as many mailboxes as you like. Pick where this one is.': 'Je kunt zoveel postvakken koppelen als je wilt. Kies waar dit postvak staat.',
  'What may the app do?': 'Wat mag de app doen?', 'Read only': 'Alleen lezen', 'Read & write': 'Lezen en schrijven',
  'The app can only look at your mail. Nothing changes in your mailbox, not even whether a mail was read.': 'De app kan je mail alleen bekijken. Er verandert niets in je postvak, ook niet of een mail gelezen is.',
  'With an app password the app itself guards this.': 'Bij een app-wachtwoord bewaakt de app dit zelf.',
  'The app can also mark mail as read, archive it and move it to the Trash. Sending mail comes in a later version.': 'De app kan ook mail als gelezen markeren, archiveren en naar de prullenbak verplaatsen. Mail versturen komt in een volgende versie.',
  'Microsoft only lets apps read Outlook.com mail after the maker registers the app with Microsoft, which needs an Azure account. That is not set up.': 'Microsoft laat apps alleen Outlook.com-mail lezen als de maker de app bij Microsoft registreert, en daarvoor is een Azure-account nodig. Dat is niet ingesteld.',
  'What you can do': 'Wat je wel kunt doen', 'In Outlook.com: Settings → Mail → Forwarding → forward your mail to a Gmail address.': 'In Outlook.com: Instellingen → E-mail → Doorsturen → stuur je mail door naar een Gmail-adres.',
  'Link that Gmail address here.': 'Koppel dat Gmail-adres hier.', 'Back': 'Terug',
  'You sign in with Google in your browser. The app never sees your Google password, and you can withdraw its access at any time in your Google account.': 'Je logt in bij Google in je browser. De app ziet je Google-wachtwoord nooit, en je kunt de toegang altijd intrekken in je Google-account.',
  'Google will warn that the app is not verified: choose Advanced → continue. Tick the box for Gmail, otherwise the link fails.': 'Google waarschuwt dat de app niet geverifieerd is: kies Geavanceerd → Doorgaan. Vink het vakje voor Gmail aan, anders lukt het koppelen niet.',
  'E-mail address': 'E-mailadres', 'App password': 'App-wachtwoord', 'Use an app password, not your normal password. It only works for mail and you can withdraw it at any time.': 'Gebruik een app-wachtwoord, niet je gewone wachtwoord. Het werkt alleen voor mail en je kunt het altijd intrekken.',
  'How do I make one?': 'Hoe maak ik er een?', 'Server (advanced)': 'Server (geavanceerd)', 'Port': 'Poort', 'Only secure connections (TLS, usually port 993) are used.': 'Alleen beveiligde verbindingen (TLS, meestal poort 993) worden gebruikt.',
  'Name (optional)': 'Naam (optioneel)', 'For example: School': 'Bijvoorbeeld: School', 'Test and link': 'Testen en koppelen', 'Testing the connection…': 'Verbinding testen…', 'Change mailbox': 'Postvak wijzigen',
  'For Gmail this is a permission at Google, so changing it means signing in again.': 'Bij Gmail is dit een toestemming bij Google, dus wijzigen betekent opnieuw inloggen.',
  'Sign in again with read only': 'Opnieuw inloggen met alleen lezen', 'Sign in again with read & write': 'Opnieuw inloggen met lezen en schrijven', 'Remove': 'Verwijderen',
  'Finish signing in in your browser…': 'Rond het inloggen af in je browser…', 'Mailbox linked!': 'Postvak gekoppeld!',
  'Remove the mailbox “{0}” from the app? Your mail itself stays in your mailbox; nothing is deleted there.': 'Het postvak “{0}” uit de app verwijderen? Je mail zelf blijft in je postvak; daar wordt niets verwijderd.',
  'Which Gmail tabs do you want to see?': 'Welke Gmail-tabbladen wil je zien?', 'Primary': 'Primair', 'Social': 'Sociaal', 'Promotions': 'Promoties', 'Updates': 'Updates', 'Forums': 'Forums',
  'By default only Primary is shown, so promotions and updates do not bury your real mail. If you switched Gmail’s tabs off, tick everything.': 'Standaard zie je alleen Primair, zodat promoties en updates je echte mail niet bedelven. Heb je de tabbladen van Gmail uitgezet, vink dan alles aan.',
  'Don’t see “Create app password” in Yahoo’s account security? Turn on two-step verification there first (it needs a phone number); the option appears afterwards. Make sure your account has a password.': 'Zie je “App-wachtwoord maken” niet bij de accountbeveiliging van Yahoo? Zet daar eerst tweestapsverificatie aan (daarvoor heb je een telefoonnummer nodig); daarna verschijnt de optie. Zorg dat je account een wachtwoord heeft.',
  'Mailbox removed.': 'Postvak verwijderd.', 'Open this link in your browser?': 'Deze link openen in je browser?',
  'Not all permissions were given. Try again and tick the box for Gmail.': 'Niet alle toestemmingen zijn gegeven. Probeer opnieuw en vink het vakje voor Gmail aan.', 'Linking the mailbox failed. Try again.': 'Het koppelen van het postvak is mislukt. Probeer het opnieuw.',
});
